#!/usr/bin/env python3
"""
Dashify — Dashboard Multi-Marketplace + Fuente Genérica
Mercado Libre  |  Tienda Nube  |  Cualquier Excel/CSV
Uso:  python app.py  →  http://127.0.0.1:7841
Deps: pip install flask pandas openpyxl requests odfpy
"""
import io, uuid, threading, webbrowser, traceback, re, math, csv
from pathlib import Path
from datetime import datetime
import pandas as pd
from flask import Flask, request, jsonify

PORT, HOST = 7841, "127.0.0.1"
app = Flask(__name__, static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = 150 * 1024 * 1024


# STORE: { sid: { name, source, df_raw, df, config } }
# source: "ml" | "tn" | "custom"
# config: { date_col, amount_col, qty_col, cat_col, cat2_col, label_col, ... }
STORE = {}

# ── Store persistente para Mercado Libre (upsert por id_venta) ──────────────
# Todas las planillas ML se fusionan en un único DataFrame acumulado.
# La clave de deduplicación es id_venta ("# de venta").
# Si la misma operación aparece en dos planillas, se conserva la fila más nueva.
ML_STORE = {
    "sid":     None,   # sid fijo reutilizado en STORE
    "df":      None,   # DataFrame acumulado con todas las planillas
    "config":  None,
    "col_info":None,
    "files":   [],     # historial de archivos cargados
}

MESES = {"enero":1,"febrero":2,"marzo":3,"abril":4,"mayo":5,"junio":6,
         "julio":7,"agosto":8,"septiembre":9,"octubre":10,"noviembre":11,"diciembre":12}

# ═══════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _str(v):
    if v is None: return None
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)): return None
    s = str(v).strip()
    return None if s in ("","nan","None","NaN","<NA>","none","-","N/A","n/a") else s

def _num(v):
    if v is None: return None
    if isinstance(v, float) and math.isnan(v): return None
    s = re.sub(r"[^\d.\-]", "", str(v))
    try:
        f = float(s) if s and s not in ("-",".") else None
        return None if (f is not None and math.isnan(f)) else f
    except: return None

def _safe(v):
    if v is None: return None
    if isinstance(v, float) and math.isnan(v): return None
    try:
        if pd.isna(v): return None
    except: pass
    return v

def _fecha_ml(s):
    if not isinstance(s, str): return None
    m = re.search(r"(\d{1,2})\s+de\s+(\w+)\s+de\s+(\d{4})", s.lower())
    if not m: return None
    d, mes, y = int(m.group(1)), m.group(2), int(m.group(3))
    mo = MESES.get(mes)
    if not mo: return None
    hm = re.search(r"(\d{1,2}):(\d{2})", s)
    h, mi = (int(hm.group(1)), int(hm.group(2))) if hm else (0,0)
    try: return datetime(y, mo, d, h, mi)
    except: return None

def _fecha_any(s):
    """Parsea fechas en múltiples formatos."""
    if not isinstance(s, str): return None
    # Español de ML
    r = _fecha_ml(s)
    if r: return r
    # Formatos estándar
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y %H:%M:%S",
                "%d/%m/%Y", "%d-%m-%Y", "%m/%d/%Y", "%Y/%m/%d",
                "%d %b %Y", "%b %d, %Y"):
        try: return datetime.strptime(s.strip(), fmt)
        except: pass
    return None

def _to_native(df):
    """Convierte DataFrame a tipos Python nativos (elimina StringDtype/NaN de pandas 3)."""
    rows = []
    for _, row in df.iterrows():
        rows.append({str(col): _safe(val) for col, val in row.items()})
    return pd.DataFrame(rows)

def _add_time_cols(df, dt_col="_fecha_dt"):
    df["_fecha_str"] = df[dt_col].dt.strftime("%Y-%m-%d")
    df["_mes"]       = df[dt_col].dt.strftime("%Y-%m")
    df["_mes_label"] = df[dt_col].dt.strftime("%b %Y")
    df["_anio"]      = df[dt_col].dt.year.astype(str)
    df["_sem"]       = df[dt_col].dt.isocalendar().week.astype(str)
    return df

# ═══════════════════════════════════════════════════════════════════════════
# PARSER GENÉRICO — cualquier Excel/CSV
# ═══════════════════════════════════════════════════════════════════════════

def smart_detect_header(df_raw):
    """Detecta la fila de encabezados en un DF sin headers."""
    best_row, best_score = 0, -999
    for i, row in df_raw.iterrows():
        if i > 20: break
        vals = [str(v).strip() for v in row if pd.notna(v) and str(v).strip()
                and str(v).strip() not in ("nan","None")]
        if not vals: continue
        fill = len(vals) / max(len(row), 1)
        if fill < 0.3: continue
        score = 0
        str_ratio = sum(1 for v in vals if not _num(v)) / len(vals)
        score += str_ratio * 40
        avg_len = sum(len(v) for v in vals) / len(vals)
        if avg_len < 25: score += 15
        if avg_len < 12: score += 10
        # Siguiente fila tiene números → buen indicador de header
        if i+1 < len(df_raw):
            nxt = [str(v).strip() for v in df_raw.iloc[i+1] if pd.notna(v)]
            if sum(1 for v in nxt if _num(v)) > len(nxt)*0.3: score += 20
        # "# de venta" o indicadores de ML/TN
        if any(v.lower() in ("# de venta","número de pedido","fecha","date","total","amount","monto") for v in vals):
            score += 30
        if len(vals) >= 15: score += 10
        if len(vals) == 1: score -= 25  # probable título
        if score > best_score:
            best_score, best_row = score, i
    return best_row

def read_raw_file(raw: bytes, filename: str) -> pd.DataFrame:
    """
    Lee cualquier archivo Excel o CSV y devuelve un DataFrame limpio.
    Detecta automáticamente headers, encoding y delimitador.
    """
    ext = Path(filename).suffix.lower()

    if ext in (".xlsx", ".xlsm"):
        buf = io.BytesIO(raw)
        df0 = pd.read_excel(buf, header=None, engine="openpyxl", dtype=str)
        hrow = smart_detect_header(df0)
        buf = io.BytesIO(raw)
        df = pd.read_excel(buf, header=hrow, engine="openpyxl")

    elif ext in (".xls",):
        buf = io.BytesIO(raw)
        df0 = pd.read_excel(buf, header=None, dtype=str)
        hrow = smart_detect_header(df0)
        buf = io.BytesIO(raw)
        df = pd.read_excel(buf, header=hrow)

    elif ext in (".ods",):
        buf = io.BytesIO(raw)
        df0 = pd.read_excel(buf, header=None, engine="odf", dtype=str)
        hrow = smart_detect_header(df0)
        buf = io.BytesIO(raw)
        df = pd.read_excel(buf, header=hrow, engine="odf")

    elif ext == ".csv":
        # Detectar encoding
        for enc in ("utf-8-sig", "utf-8", "latin-1", "cp1252"):
            try: text = raw.decode(enc); break
            except: pass
        else: text = raw.decode("latin-1", errors="replace")
        # Detectar delimitador
        try:
            sample = text[:4096]
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
            sep = dialect.delimiter
        except: sep = ","
        from io import StringIO
        df = pd.read_csv(StringIO(text), sep=sep)

    else:
        raise ValueError(f"Formato no soportado: {ext}. Usá .xlsx, .xls, .csv u .ods")

    df = df.dropna(how="all").reset_index(drop=True)
    df.columns = [str(c).strip() for c in df.columns]

    if df.empty:
        raise ValueError("El archivo no tiene datos.")

    return _to_native(df)

def infer_column_roles(df: pd.DataFrame) -> dict:
    """
    Infiere automáticamente el rol de cada columna.
    Retorna un dict { col_name: { type, role, sample } }
    """
    info = {}
    cols = list(df.columns)
    used_roles = set()

    for col in cols:
        if col.startswith("_"): continue
        sample = df[col].dropna().head(30)
        if sample.empty:
            info[col] = {"type":"empty","role":None,"sample":[]}
            continue

        # Detectar tipo
        vals = sample.tolist()
        str_vals = [str(v).strip() for v in vals]

        # ¿Fecha?
        date_hits = sum(1 for v in str_vals if _fecha_any(v))
        if date_hits / len(str_vals) > 0.6:
            ctype = "date"
        # ¿Número?
        elif sum(1 for v in vals if isinstance(v,(int,float)) and not (isinstance(v,float) and math.isnan(v))) / len(vals) > 0.7:
            ctype = "number"
        elif sum(1 for v in str_vals if _num(v) and v.strip()) / len(str_vals) > 0.6:
            ctype = "number"
        else:
            ctype = "text"

        # Inferir rol por nombre + tipo
        col_l = col.lower().strip()
        role = None

        if ctype == "date" and "date" not in used_roles:
            if any(x in col_l for x in ["fecha","date","cuando","time","día","dia"]):
                role = "date"; used_roles.add("date")

        if ctype == "number":
            if any(x in col_l for x in ["total","ingreso","monto","importe","precio","price","amount","revenue","venta","subtotal"]) and "amount" not in used_roles:
                role = "amount"; used_roles.add("amount")
            elif any(x in col_l for x in ["cantidad","qty","units","unidad","unidades","quantity","cant"]) and "qty" not in used_roles:
                role = "qty"; used_roles.add("qty")
            elif any(x in col_l for x in ["costo","cost","envio","shipping","descuento","discount"]) and "cost" not in used_roles:
                role = "cost"; used_roles.add("cost")

        if ctype == "text":
            if any(x in col_l for x in ["estado","status","estado del pago","payment"]) and "status" not in used_roles:
                role = "status"; used_roles.add("status")
            elif any(x in col_l for x in ["producto","product","publicacion","artículo","articulo","item","nombre del producto"]) and "product" not in used_roles:
                role = "product"; used_roles.add("product")
            elif any(x in col_l for x in ["categoria","category","tipo","type","canal","channel"]) and "category" not in used_roles:
                role = "category"; used_roles.add("category")
            elif any(x in col_l for x in ["provincia","provincia","city","ciudad","region","state","pais","country"]) and "geo" not in used_roles:
                role = "geo"; used_roles.add("geo")
            elif any(x in col_l for x in ["cliente","customer","comprador","buyer","nombre"]) and "customer" not in used_roles:
                role = "customer"; used_roles.add("customer")
            elif any(x in col_l for x in ["sku","código","code","id","número","numero","order"]) and "id" not in used_roles:
                role = "id"; used_roles.add("id")

        info[col] = {
            "type":   ctype,
            "role":   role,
            "sample": [str(v) for v in vals[:5]]
        }

    # Segunda pasada: asignar roles faltantes a columnas sin rol
    # (el usuario los puede cambiar en el modal)
    if "date" not in used_roles:
        for col, v in info.items():
            if v["type"] == "date" and not v["role"]:
                v["role"] = "date"; used_roles.add("date"); break
    if "amount" not in used_roles:
        for col, v in info.items():
            if v["type"] == "number" and not v["role"]:
                v["role"] = "amount"; used_roles.add("amount"); break
    if "product" not in used_roles:
        for col, v in info.items():
            if v["type"] == "text" and not v["role"]:
                v["role"] = "product"; used_roles.add("product"); break

    return info

def infer_column_roles_to_config(df: pd.DataFrame) -> dict:
    """Atajo: infiere roles y devuelve directamente { role: col_name }."""
    return {info["role"]: col
            for col, info in infer_column_roles(df).items()
            if info.get("role")}

def apply_config_to_df(df: pd.DataFrame, config: dict) -> pd.DataFrame:
    """
    Aplica la configuración de columnas al DataFrame,
    creando aliases estándar que el motor de análisis entiende.
    config = { role: col_name }  p.ej. { "date":"Fecha", "amount":"Total", ... }
    """
    role_to_alias = {
        "date":     "_fecha_dt",
        "amount":   "ingresos",
        "qty":      "unidades",
        "cost":     "costo",
        "status":   "estado",
        "product":  "publicacion",
        "category": "categoria",
        "geo":      "provincia",
        "customer": "comprador",
        "id":       "id_venta",
        "category2":"categoria2",
        "amount2":  "ingresos2",
        "qty2":     "unidades2",
    }

    for role, col in config.items():
        if not col or col not in df.columns:
            continue
        alias = role_to_alias.get(role)
        if not alias:
            continue
        # Si la columna fuente ya ES el alias calculado, no hay nada que hacer
        if col == alias:
            continue

        if role == "date":
            df["_fecha_dt"] = pd.to_datetime(
                df[col].apply(lambda v: _fecha_any(str(v)) if v else None),
                errors="coerce"
            )
            # Fallback: parseo directo pandas
            mask = df["_fecha_dt"].isna() & df[col].notna()
            if mask.any():
                df.loc[mask,"_fecha_dt"] = pd.to_datetime(
                    df.loc[mask, col], dayfirst=True, errors="coerce")
            df = _add_time_cols(df)
        elif alias in ("ingresos","costo","ingresos2","unidades","unidades2","qty2","amount2"):
            # Si "ingresos" ya fue calculado por read_ml (BN × unidades), no sobreescribir
            # con el precio unitario crudo. Solo sobreescribir si la columna fuente
            # es distinta de "ingresos" (alias ya calculado) o si no existe todavía.
            if alias == "ingresos" and "ingresos" in df.columns and col != "ingresos":
                # Verificar si ya existe un valor calculado (BN × unidades)
                # Esto ocurre cuando read_ml ya pobló "ingresos" correctamente.
                # Solo re-calcular si la columna fuente no es la BN/precio unitario.
                _col_l = col.lower()
                _es_precio_unit = any(x in _col_l for x in ["precio por unidad","precio unitario","precio unit"])
                if _es_precio_unit:
                    pass  # conservar el ingresos = BN × unidades ya calculado
                else:
                    df[alias] = pd.to_numeric(
                        df[col].apply(lambda v: re.sub(r"[^\d.\-]","",str(v)) if v else ""),
                        errors="coerce")
            else:
                df[alias] = pd.to_numeric(
                    df[col].apply(lambda v: re.sub(r"[^\d.\-]","",str(v)) if v else ""),
                    errors="coerce")
        else:
            df[alias] = df[col].apply(_str)

    if "_fecha_dt" not in df.columns:
        for c in ["_fecha_dt","_fecha_str","_mes","_mes_label","_anio","_sem"]:
            df[c] = None

    if "ingresos" not in df.columns:
        df["ingresos"] = 0.0

    return df

# ═══════════════════════════════════════════════════════════════════════════
# PARSERS ESPECÍFICOS ML y TN (mantienen la lógica previa)
# ═══════════════════════════════════════════════════════════════════════════

def read_ml(raw, filename):
    """
    Parser para el reporte de Mercado Libre (.xlsx).
    Formato exacto: descarga desde Mis Ventas → Exportar reporte.
    Headers en fila 6 (filas 1-5 son metadatos de ML).
    """
    buf = io.BytesIO(raw)
    try:
        df0 = pd.read_excel(buf, header=None, engine="openpyxl", dtype=str)
    except Exception:
        raise ValueError("El archivo no es un Excel válido (.xlsx).\n"
                         "El reporte de ML debe descargarse desde:\n"
                         "Mercado Libre → Mis Ventas → Exportar reporte")
    # Detectar fila de header buscando '# de venta'
    buf.seek(0)
    hrow = None
    for i, row in df0.iterrows():
        vals = [str(v).strip() for v in row if pd.notna(v) and str(v).strip()]
        if any(v.lower() == "# de venta" for v in vals):
            hrow = i; break
        if len(vals) >= 15:
            hrow = i; break
    if hrow is None:
        raise ValueError(
            "No se encontró el encabezado del reporte ML.\n"
            "Asegurate de descargar el archivo desde:\n"
            "Mercado Libre → Mis Ventas → Exportar reporte")
    buf.seek(0)
    df = pd.read_excel(buf, header=hrow, engine="openpyxl")
    df = df.dropna(how="all").reset_index(drop=True)
    df = _to_native(df)

    # ── Mapeo EXACTO de columnas del reporte de ML ──────────────────────
    # Fechas (formato: "27 de marzo de 2026 22:00 hs.")
    if "Fecha de venta" in df.columns:
        df["_fecha_dt"] = pd.to_datetime(
            [_fecha_ml(v) for v in df["Fecha de venta"]], errors="coerce")
        df = _add_time_cols(df)

    # ── Columna BN: Precio por unidad (columna 66 del Excel de ML) ──────
    # Intentar por nombre primero; si no, por posición (índice 65 = columna BN)
    PRECIO_UNIT_NAMES = ["Precio por unidad", "Precio por Unidad", "Precio unitario",
                         "Precio Unit.", "precio_por_unidad"]
    _col_precio_unit = None
    for pname in PRECIO_UNIT_NAMES:
        if pname in df.columns:
            _col_precio_unit = pname
            break
    # Fallback: usar posición BN (índice 65) si existe
    if _col_precio_unit is None:
        _raw_cols = list(df.columns)
        if len(_raw_cols) >= 66:
            _col_precio_unit = _raw_cols[65]  # índice 65 = columna BN

    # Numéricos
    NUM_ML = {
        "Ingresos por productos (ARS)": "ingresos_orig",  # guardamos el original pero no lo usamos como principal
        "Total (ARS)":                  "total_neto",
        "Unidades":                     "unidades",
        "Cargo por venta":              "cargo_venta",
        "Costo fijo":                   "costo_fijo",
        "Costos de envío (ARS)":        "costo_envio",
        "Costos de envio (ARS)":        "costo_envio",
        "Ingresos por envío (ARS)":     "ingreso_envio",
        "Ingresos por envio (ARS)":     "ingreso_envio",
        "Impuestos":                    "impuestos",
        "Descuentos":                   "descuentos",
        "Anulaciones y reembolsos (ARS)": "anulaciones",
    }
    for orig, alias in NUM_ML.items():
        if orig in df.columns and alias not in df.columns:
            df[alias] = pd.to_numeric(
                df[orig].apply(lambda v: re.sub(r"[^\d.\-]","",str(v)) if v else ""),
                errors="coerce")

    # ── Calcular ingresos = Precio por unidad (col BN) × Unidades ───────
    if _col_precio_unit and _col_precio_unit in df.columns:
        df["precio_por_unidad"] = pd.to_numeric(
            df[_col_precio_unit].apply(lambda v: re.sub(r"[^\d.\-]","",str(v)) if v else ""),
            errors="coerce")
        _unidades = df["unidades"] if "unidades" in df.columns else pd.Series([1]*len(df))
        df["ingresos"] = (df["precio_por_unidad"].fillna(0) * _unidades.fillna(1)).round(2)
    elif "ingresos_orig" in df.columns:
        # Fallback: usar columna original si no se encontró BN
        df["ingresos"] = df["ingresos_orig"]

    # Categóricos
    CAT_ML = {
        "# de venta":                       "id_venta",
        "Estado":                           "estado",
        "Descripción del estado":           "desc_estado",
        "Descripcion del estado":           "desc_estado",
        "Título de la publicación":         "publicacion",
        "Titulo de la publicacion":         "publicacion",
        "SKU":                              "sku",
        "Variante":                         "variante",
        "Canal de venta":                   "canal_ml",
        "Forma de entrega":                 "forma_envio",
        "Transportista":                    "transportista",
        "Ciudad":                           "ciudad",
        "Estado.1":                         "provincia",
        "País":                             "pais",
        "Comprador":                        "comprador",
        "Tienda oficial":                   "tienda",
        "# de publicación":                 "id_publicacion",
        "Venta por publicidad":             "por_publicidad",
    }
    for orig, alias in CAT_ML.items():
        if orig in df.columns and alias not in df.columns:
            df[alias] = df[orig].apply(_str)

    # Calcular "costo" consolidado (cargo venta + costo envío)
    import pandas as _pd
    c1 = df["cargo_venta"].fillna(0) if "cargo_venta" in df.columns else _pd.Series([0]*len(df))
    c2 = df["costo_envio"].fillna(0) if "costo_envio" in df.columns else _pd.Series([0]*len(df))
    df["costo"] = (c1.abs() + c2.abs())

    df["fuente"] = "Mercado Libre"
    # Normalizar estados ML
    ESTADOS_ML = {
        "entregado": "Entregado",
        "en camino": "En camino",
        "procesando": "En proceso",
        "cancelad":  "Cancelado",
        "reclamo":   "Reclamo",
        "paquete":   "Paquete múltiple",
    }
    if "estado" in df.columns:
        def norm_ml(v):
            if not v: return None
            sl = v.lower()
            for k, label in ESTADOS_ML.items():
                if k in sl: return label
            return v
        df["estado"] = df["estado"].apply(norm_ml)

    # Reportar qué columna se usó para ingresos
    # Si se calculó BN × unidades, apuntamos a "ingresos" (alias calculado)
    # para que apply_config_to_df no sobreescriba el valor correcto.
    _ingreso_col = "ingresos" if (_col_precio_unit and "ingresos" in df.columns) \
                   else ("ingresos_orig" if "ingresos_orig" in df.columns else "Ingresos por productos (ARS)")
    config = {"date":"Fecha de venta","amount": _ingreso_col,
              "qty":"Unidades","status":"Estado","product":"Título de la publicación",
              "geo":"Estado.1","customer":"Comprador","id":"# de venta","category":"Forma de entrega"}
    return df, config


def read_tn(raw, filename):
    """
    Parser para el reporte de Tienda Nube (.csv).
    Formato exacto: Panel TN → Estadísticas → Exportar pedidos.
    Encoding: latin-1 | Separador: punto y coma (;)
    
    Columnas principales del export real:
      Número de orden, Fecha, Estado de la orden, Estado del pago,
      Estado del envío, Total, Subtotal de productos, Descuento,
      Costo de envío, Nombre del comprador, Nombre del producto,
      Precio del producto, Cantidad del producto, SKU,
      Provincia o estado, Ciudad, Medio de envío, Medio de pago, Canal
    """
    # Detectar encoding (TN usa latin-1 en Argentina)
    for enc in ("latin-1", "cp1252", "utf-8-sig", "utf-8"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        text = raw.decode("latin-1", errors="replace")

    from io import StringIO
    # Detectar separador automáticamente (TN Argentina usa ";" pero puede venir con ",")
    sample = text[:4096]
    try:
        import csv as _csv
        dialect = _csv.Sniffer().sniff(sample, delimiters=";,	|")
        sep = dialect.delimiter
    except Exception:
        # Fallback: contar ocurrencias
        sep = ";" if text[:2048].count(";") >= text[:2048].count(",") else ","

    df = pd.read_csv(StringIO(text), sep=sep, dtype=str, na_filter=False)
    df = df.replace("", None)
    df.columns = [str(c).strip() for c in df.columns]
    df = df.dropna(how="all").reset_index(drop=True)
    df = _to_native(df)

    if df.empty:
        raise ValueError("El CSV de Tienda Nube no tiene datos.")

    # ── Detección de formato: verificar si tiene columnas típicas de TN ──
    # Incluir variantes con caracteres corruptos por encoding
    TN_KEY_COLS = {"Número de orden", "Fecha", "Total", "Estado del pago",
                   "Nombre del producto", "Nombre del comprador",
                   "NM-zmero de orden", "Estado del pago", "Nombre del comprador"}
    cols_set = set(df.columns)
    es_formato_tn = len(TN_KEY_COLS & cols_set) >= 3

    if not es_formato_tn:
        # CSV genérico subido como TN: usar parser genérico y etiquetar como Tienda Nube
        df2 = apply_config_to_df(df.copy(), infer_column_roles_to_config(df))
        df2["fuente"] = "Tienda Nube"
        if "_fecha_dt" not in df2.columns:
            for c in ["_fecha_dt","_fecha_str","_mes","_mes_label","_anio","_sem"]:
                df2[c] = None
        if "ingresos" not in df2.columns:
            df2["ingresos"] = 0.0
        config2 = {info["role"]: col
                   for col, info in infer_column_roles(df).items()
                   if info.get("role")}
        return df2, config2

    # ── Fechas (formato TN: "DD/MM/YYYY HH:MM:SS") ──────────────────────
    FC = "Fecha"  # columna de fecha en el CSV de TN
    if FC in df.columns:
        df["_fecha_dt"] = pd.to_datetime(df[FC], format="%d/%m/%Y %H:%M:%S", errors="coerce")
        # Fallback para filas con formato incompleto
        mask = df["_fecha_dt"].isna() & df[FC].notna()
        if mask.any():
            df.loc[mask, "_fecha_dt"] = pd.to_datetime(
                df.loc[mask, FC], dayfirst=True, errors="coerce")
        df = _add_time_cols(df)

    # ── Numéricos (los valores ya vienen como número o "0.00") ──────────
    NUM_TN = {
        "Total":                  "ingresos",
        "Subtotal de productos":  "subtotal",
        "Descuento":              "descuentos",
        "Costo de envío":         "costo_envio",
        "Precio del producto":    "precio_unit",
        "Cantidad del producto":  "unidades",
    }
    for orig, alias in NUM_TN.items():
        if orig in df.columns and alias not in df.columns:
            df[alias] = pd.to_numeric(
                df[orig].apply(lambda v: re.sub(r"[^\d.\-]","",str(v)) if v else ""),
                errors="coerce")

    # total_neto = Total - Costo de envío
    if "ingresos" in df.columns and "costo_envio" in df.columns:
        df["total_neto"] = df["ingresos"].fillna(0) - df["costo_envio"].fillna(0)
    elif "ingresos" in df.columns:
        df["total_neto"] = df["ingresos"]

    # Costo consolidado
    df["costo"] = df.get("costo_envio", pd.Series([0]*len(df))).fillna(0)

    # ── Categóricos ──────────────────────────────────────────────────────
    CAT_TN = {
        "Número de orden":   "id_venta",
        "Estado del pago":   "estado",         # Recibido, Pendiente, Reembolsado...
        "Estado de la orden":"estado_orden",
        "Estado del envío":  "estado_envio",
        "Nombre del comprador": "comprador",
        "Nombre del producto":  "publicacion",
        "SKU":               "sku",
        "Provincia o estado":"provincia",
        "Ciudad":            "ciudad",
        "País":              "pais",
        "Medio de envío":    "forma_envio",
        "Medio de pago":     "forma_pago",
        "Canal":             "canal_tn",        # Web, Móvil, Admin...
        "Email":             "email",
        "Localidad":         "localidad",
        "Cupón de descuento":"cupon",
        "Código de tracking del envío": "tracking",
    }
    for orig, alias in CAT_TN.items():
        if orig in df.columns and alias not in df.columns:
            df[alias] = df[orig].apply(_str)

    # ── Normalizar estados de pago de TN ─────────────────────────────────
    # Los estados reales del CSV: Recibido, Reembolsado, Pendiente,
    # Vencido, Rechazado, Parcialmente reembolsado
    ESTADOS_TN = {
        "recibido":                   "Pagado",
        "pagado":                     "Pagado",
        "pendiente":                  "Pendiente",
        "vencido":                    "Vencido",
        "rechazado":                  "Rechazado",
        "reembolsado":                "Reembolsado",
        "parcialmente reembolsado":   "Reembolso parcial",
        "cancelad":                   "Cancelado",
    }
    if "estado" in df.columns:
        def norm_tn(v):
            if not v or not isinstance(v, str): return None
            sl = v.lower().strip()
            for k, label in ESTADOS_TN.items():
                if k in sl: return label
            return v
        df["estado"] = df["estado"].apply(norm_tn)

    # Categoría de envío (simplificar nombre largo del medio)
    if "forma_envio" in df.columns:
        def simp_envio(v):
            if not v or not isinstance(v, str): return None
            v = v.strip()
            if not v: return None
            if "andreani" in v.lower(): return "Andreani"
            if "correo" in v.lower(): return "Correo Argentino"
            if "retiro" in v.lower(): return "Punto de retiro"
            if "occa" in v.lower() or "oca" in v.lower(): return "OCA"
            return v.split('"')[0].strip() or v
        df["forma_envio"] = df["forma_envio"].apply(simp_envio)

    df["fuente"] = "Tienda Nube"

    config = {"date":"Fecha","amount":"Total","qty":"Cantidad del producto",
              "status":"Estado del pago","product":"Nombre del producto",
              "geo":"Provincia o estado","customer":"Nombre del comprador",
              "id":"Número de orden","category":"Medio de envío"}
    return df, config

# ═══════════════════════════════════════════════════════════════════════════
# MOTOR DE ANÁLISIS (compartido por todas las fuentes)
# ═══════════════════════════════════════════════════════════════════════════

def _S(df, col):
    if col not in df.columns: return 0.0
    return float(df[col].sum(skipna=True))

def _R(v, d=2):
    if v is None or (isinstance(v,float) and math.isnan(v)): return 0
    return round(v, d)

def metricas(df):
    n   = len(df)
    ing = _S(df,"ingresos")
    ent = 0
    if "estado" in df.columns:
        estados_ok = ["entregado","pagado","paid","delivered","completad","complete","aprobado"]
        ent = df["estado"].fillna("").str.lower().apply(
            lambda s: any(x in s for x in estados_ok)).sum()
    return {
        "n_ventas":   n,
        "unidades":   _R(_S(df,"unidades"), 0),
        "ingresos":   _R(ing),
        "total_neto": _R(_S(df,"total_neto") if "total_neto" in df.columns else ing),
        "costo":      _R(abs(_S(df,"costo"))),
        "descuentos": _R(abs(_S(df,"descuentos"))) if "descuentos" in df.columns else 0,
        "ticket_prom":_R(ing/n) if n>0 else 0,
        "tasa_ok":    _R(int(ent)/n*100,1) if n>0 else 0,
    }

def grp(df, by, top=None):
    if by not in df.columns: return []
    num_cols = [c for c in ["ingresos","unidades"] if c in df.columns]
    tmp = df[[by]+num_cols].copy()
    tmp[by] = tmp[by].fillna("(vacío)")
    for c in num_cols:
        tmp[c] = pd.to_numeric(tmp[c], errors="coerce").fillna(0)
    agg = tmp.groupby(by, as_index=False)[num_cols].sum()
    agg["cantidad"] = tmp.groupby(by)[by].count().values
    agg = agg.sort_values("ingresos", ascending=False)
    if top: agg = agg.head(top)
    tot = agg["ingresos"].sum()
    agg["pct"] = (agg["ingresos"]/tot*100).round(1) if tot else 0
    agg["ingresos"] = agg["ingresos"].round(2)
    if "unidades" in agg.columns:
        agg["unidades"] = agg["unidades"].round(0).astype(int)
    return agg.rename(columns={by:"label"}).to_dict("records")

def grp_custom(df, by_col, val_col, agg_fn="sum", top=None):
    """Agrupa por cualquier columna con cualquier función."""
    if by_col not in df.columns or val_col not in df.columns: return []
    tmp = df[[by_col, val_col]].copy()
    tmp[by_col] = tmp[by_col].fillna("(vacío)").astype(str)
    tmp[val_col] = pd.to_numeric(tmp[val_col], errors="coerce").fillna(0)
    if agg_fn == "count":
        agg = tmp.groupby(by_col).size().reset_index(name="valor")
    elif agg_fn == "avg":
        agg = tmp.groupby(by_col, as_index=False)[val_col].mean().rename(columns={val_col:"valor"})
    elif agg_fn == "max":
        agg = tmp.groupby(by_col, as_index=False)[val_col].max().rename(columns={val_col:"valor"})
    elif agg_fn == "min":
        agg = tmp.groupby(by_col, as_index=False)[val_col].min().rename(columns={val_col:"valor"})
    else:
        agg = tmp.groupby(by_col, as_index=False)[val_col].sum().rename(columns={val_col:"valor"})
    agg = agg.sort_values("valor", ascending=False)
    if top: agg = agg.head(top)
    tot = agg["valor"].sum()
    agg["pct"] = (agg["valor"]/tot*100).round(1) if tot else 0
    agg["valor"] = agg["valor"].round(2)
    return agg.rename(columns={by_col:"label"}).to_dict("records")


def flex_por_zona(df, top=15):
    """
    Filtra envíos Flex (por forma_envio o transportista) y agrupa por provincia/zona.
    Devuelve lista con: zona, cantidad, pct_cantidad, ingresos, pct_ingresos
    """
    if df.empty:
        return {"zonas": [], "total_flex": 0, "total_envios": len(df)}

    # Detectar columna de envío (forma_envio tiene prioridad, luego transportista)
    col_envio = None
    for c in ["forma_envio", "transportista", "canal_ml"]:
        if c in df.columns:
            col_envio = c
            break
    if col_envio is None:
        return {"zonas": [], "total_flex": 0, "total_envios": len(df)}

    # Filtrar filas Flex
    mask_flex = df[col_envio].fillna("").astype(str).str.lower().str.contains("flex", na=False)
    df_flex = df[mask_flex].copy()

    total_envios = len(df)
    total_flex   = len(df_flex)

    if total_flex == 0:
        return {"zonas": [], "total_flex": 0, "total_envios": total_envios}

    # Agrupar por la columna más granular disponible:
    # ciudad > localidad > provincia
    # Construir etiqueta combinada ciudad + provincia cuando sea posible
    geo_col = None
    for c in ["ciudad", "localidad", "provincia"]:
        if c in df_flex.columns and df_flex[c].notna().any():
            geo_col = c
            break
    if geo_col is None:
        return {"zonas": [], "total_flex": total_flex, "total_envios": total_envios}

    # Crear etiqueta "Ciudad (Provincia)" para mayor contexto
    if geo_col == "ciudad" and "provincia" in df_flex.columns:
        df_flex = df_flex.copy()
        df_flex["_zona_label"] = df_flex["ciudad"].fillna("(sin ciudad)").astype(str).str.strip() +             " (" + df_flex["provincia"].fillna("").astype(str).str.strip() + ")"
        df_flex["_zona_label"] = df_flex["_zona_label"].str.replace(r" \(\)$", "", regex=True)
        grp_col = "_zona_label"
    else:
        grp_col = geo_col

    agg = df_flex.groupby(grp_col, as_index=False).agg(
        cantidad=(grp_col, "count")
    )
    if "ingresos" in df_flex.columns:
        ing_agg = df_flex.groupby(grp_col, as_index=False)["ingresos"].sum()
        agg = agg.merge(ing_agg, on=grp_col, how="left")
    else:
        agg["ingresos"] = 0.0

    agg = agg.sort_values("cantidad", ascending=False).head(top)
    tot_cant = agg["cantidad"].sum()
    tot_ing  = agg["ingresos"].sum() if "ingresos" in agg.columns else 0

    zonas = []
    for _, row in agg.iterrows():
        zonas.append({
            "zona":          str(row[grp_col]),
            "cantidad":      int(row["cantidad"]),
            "pct_cantidad":  round(row["cantidad"] / tot_cant * 100, 1) if tot_cant else 0,
            "ingresos":      round(float(row.get("ingresos", 0)), 2),
            "pct_ingresos":  round(float(row.get("ingresos", 0)) / tot_ing * 100, 1) if tot_ing else 0,
        })

    # ── Agregar coordenadas para el mapa de calor ──────────────────────
    # Diccionario de ciudades/barrios argentinos con coordenadas
    GEO_AR = {
        # CABA barrios
        "palermo":(-34.5755,-58.4268),"belgrano":(-34.5606,-58.4584),
        "caballito":(-34.6182,-58.4378),"flores":(-34.6273,-58.4621),
        "villa urquiza":(-34.5758,-58.4898),"recoleta":(-34.5875,-58.3928),
        "balvanera":(-34.6095,-58.4079),"almagro":(-34.6145,-58.4267),
        "villa del parque":(-34.5991,-58.4850),"montserrat":(-34.6155,-58.3808),
        "san telmo":(-34.6245,-58.3697),"la boca":(-34.6348,-58.3620),
        "barracas":(-34.6454,-58.3829),"boedo":(-34.6348,-58.4174),
        "villa crespo":(-34.5978,-58.4452),"chacarita":(-34.5854,-58.4549),
        "colegiales":(-34.5739,-58.4474),"devoto":(-34.5994,-58.5109),
        "floresta":(-34.6273,-58.4886),"liniers":(-34.6386,-58.5204),
        "mataderos":(-34.6636,-58.5115),"monte castro":(-34.6091,-58.5070),
        "nueva pompeya":(-34.6548,-58.4108),"parque chacabuco":(-34.6395,-58.4428),
        "parque patricios":(-34.6418,-58.4044),"paternal":(-34.6036,-58.4697),
        "saavedra":(-34.5557,-58.4932),"villa luro":(-34.6386,-58.4904),
        "villa pueyrredon":(-34.5879,-58.5048),"villa real":(-34.6283,-58.5069),
        "villa riachuelo":(-34.6734,-58.4566),"villa santa rita":(-34.6136,-58.4878),
        "villa soldati":(-34.6683,-58.4370),"agronomia":(-34.5994,-58.4975),
        "nuñez":(-34.5450,-58.4572),"versalles":(-34.6333,-58.5175),
        "parque avellaneda":(-34.6500,-58.4811),"puerto madero":(-34.6151,-58.3620),
        # GBA
        "avellaneda":(-34.6611,-58.3651),"quilmes":(-34.7218,-58.2536),
        "lanus":(-34.7052,-58.3924),"lomas de zamora":(-34.7606,-58.3981),
        "almirante brown":(-34.8200,-58.3800),"esteban echeverria":(-34.8167,-58.4500),
        "ezeiza":(-34.8526,-58.5161),"merlo":(-34.6826,-58.7272),
        "morón":(-34.6516,-58.6194),"moron":(-34.6516,-58.6194),
        "ituzaingo":(-34.6581,-58.6766),"hurlingham":(-34.5892,-58.6402),
        "tres de febrero":(-34.6100,-58.5600),"san martin":(-34.5747,-58.5367),
        "general san martin":(-34.5747,-58.5367),"la matanza":(-34.7704,-58.6222),
        "san justo":(-34.6847,-58.5606),"ramos mejia":(-34.6448,-58.5629),
        "haedo":(-34.6478,-58.5944),"villa tesei":(-34.6286,-58.6469),
        "ciudadela":(-34.6414,-58.5429),"tapiales":(-34.6792,-58.5553),
        "gonzales catan":(-34.7653,-58.6392),"isidro casanova":(-34.7250,-58.6083),
        "gregorio de laferrere":(-34.7450,-58.5861),"rafael castillo":(-34.7128,-58.6408),
        "virrey del pino":(-34.8108,-58.6372),"temperley":(-34.7703,-58.3978),
        "turdera":(-34.7917,-58.3889),"banfield":(-34.7406,-58.3941),
        "remedios de escalada":(-34.7539,-58.4025),"lomas":(-34.7606,-58.3981),
        "monte grande":(-34.8186,-58.4703),"canning":(-34.8803,-58.5025),
        "longchamps":(-34.8736,-58.3858),"glew":(-34.8972,-58.3747),
        "malvinas argentinas":(-34.4525,-58.7011),"don torcuato":(-34.4747,-58.6353),
        "tigre":(-34.4258,-58.5786),"el talar":(-34.4528,-58.6814),
        "benavidez":(-34.4022,-58.6897),"nordelta":(-34.3978,-58.6467),
        "escobar":(-34.3481,-58.7967),"pilar":(-34.4585,-58.9139),
        "del viso":(-34.4125,-58.8247),"maquinista savio":(-34.3900,-58.6531),
        "garín":(-34.4228,-58.7258),"garin":(-34.4228,-58.7258),
        "villa del lago":(-34.3633,-58.7633),"jose c paz":(-34.5228,-58.7756),
        "san miguel":(-34.5453,-58.7083),"bella vista":(-34.5681,-58.6878),
        "grand bourg":(-34.4978,-58.7281),"tortuguitas":(-34.4539,-58.7519),
        "general pacheco":(-34.4519,-58.6533),"ingeniero benavides":(-34.3694,-58.6789),
        "la lucila":(-34.4983,-58.5250),"martinez":(-34.4892,-58.5053),
        "vicente lopez":(-34.5269,-58.4778),"florida":(-34.5267,-58.5036),
        "munro":(-34.5300,-58.5203),"villa martelli":(-34.5567,-58.5369),
        "olivos":(-34.5097,-58.4917),"boulogne":(-34.4942,-58.5647),
        "la lonja":(-34.4419,-58.5722),"san isidro":(-34.4683,-58.5253),
        "beccar":(-34.4769,-58.5389),"acassuso":(-34.4808,-58.5125),
        "berazategui":(-34.7654,-58.2101),"florencio varela":(-34.8181,-58.2764),
        "quilmes oeste":(-34.7411,-58.2764),"bernal":(-34.7025,-58.2817),
        "ezpeleta":(-34.7528,-58.2314),"el jaguel":(-34.8425,-58.4539),
        "canning":(-34.8803,-58.5025),"spegazzini":(-34.9056,-58.5039),
        "tristan suarez":(-34.8608,-58.5508),"ezeiza":(-34.8526,-58.5161),
        "la plata":(-34.9206,-57.9544),"la plata (buenos aires)":(-34.9206,-57.9544),
        "berisso":(-34.8745,-57.8908),"ensenada":(-34.8589,-57.9108),
        "gonnet":(-34.8836,-57.9950),"city bell":(-34.8703,-58.0264),
        "villa elisa":(-34.8553,-58.0939),"manuel b gonnet":(-34.8836,-57.9950),
        "mar del plata":(-37.9995,-57.5575),"mar del plata (buenos aires)":(-37.9995,-57.5575),
        "cordoba":(-31.4201,-64.1888),"córdoba":(-31.4201,-64.1888),
        "rosario":(-32.9442,-60.6505),"santa fe":(-31.6333,-60.7000),
        "mendoza":(-32.8908,-68.8272),"tucuman":(-26.8083,-65.2176),
        "tucumán":(-26.8083,-65.2176),"salta":(-24.7833,-65.4167),
        "corrientes":(-27.4667,-58.8333),"resistencia":(-27.4500,-58.9833),
        "posadas":(-27.3667,-55.9000),"neuquén":(-38.9517,-68.0591),
        "neuquen":(-38.9517,-68.0591),"bariloche":(-41.1333,-71.3000),
        "bahia blanca":(-38.7183,-62.2663),"bahía blanca":(-38.7183,-62.2663),
        # Fallback provincias
        "buenos aires":(-34.6037,-58.3816),
        "capital federal":(-34.6037,-58.3816),
        "caba":(-34.6037,-58.3816),
    }

    def get_coords(zona_str):
        """Busca coordenadas para una zona por nombre."""
        z = zona_str.lower().strip()
        # Buscar exacto
        if z in GEO_AR: return GEO_AR[z]
        # Buscar sin paréntesis (ciudad sin provincia)
        z_base = z.split("(")[0].strip()
        if z_base in GEO_AR: return GEO_AR[z_base]
        # Buscar si alguna clave está contenida en z
        for key, coords in GEO_AR.items():
            if key in z or z in key:
                return coords
        return None

    for z in zonas:
        coords = get_coords(z["zona"])
        if coords:
            z["lat"] = coords[0]
            z["lng"] = coords[1]

    return {
        "zonas":        zonas,
        "total_flex":   total_flex,
        "total_envios": total_envios,
        "pct_flex_total": round(total_flex / total_envios * 100, 1) if total_envios else 0,
    }


def por_tiempo(df, periodo="dia", val_col="ingresos"):
    key = {"mes":"_mes","semana":"_sem","anio":"_anio"}.get(periodo,"_fecha_str")
    if key not in df.columns: return []
    num_cols = [c for c in [val_col,"unidades"] if c in df.columns]
    if not num_cols: return []
    tmp = df[[key]+num_cols].copy()
    tmp = tmp.dropna(subset=[key])
    tmp[key] = tmp[key].astype(str)
    for c in num_cols: tmp[c] = pd.to_numeric(tmp[c], errors="coerce").fillna(0)
    tmp["cantidad"] = 1
    agg = tmp.groupby(key, as_index=False)[num_cols+["cantidad"]].sum()
    agg = agg.sort_values(key).rename(columns={key:"periodo",val_col:"ingresos"})
    agg["ingresos"] = agg["ingresos"].round(2)
    return agg.to_dict("records")

def tabla_ventas(df, page=0, ps=50):
    prefer = ["id_venta","_fecha_str","publicacion","estado","fuente","categoria",
              "unidades","ingresos","total_neto","provincia","comprador"]
    cols = [c for c in prefer if c in df.columns]
    # Agregar cols numéricas extra que no estén ya
    for c in df.columns:
        if c not in cols and not c.startswith("_") and c in df.columns:
            if len(cols) < 14: cols.append(c)
    tmp = df[cols].copy()
    if "ingresos" in tmp.columns:
        tmp = tmp.sort_values("ingresos", ascending=False, na_position="last")
    total = len(tmp)
    rows = []
    for _, row in tmp.iloc[page*ps:(page+1)*ps].iterrows():
        r = {}
        for c in cols:
            v = row[c]
            if v is None or (isinstance(v,float) and math.isnan(v)): r[c]=None
            elif isinstance(v,float) and v==int(v): r[c]=int(v)
            elif isinstance(v,(float,int)): r[c]=round(float(v),2)
            else: r[c]=str(v)
        rows.append(r)
    return {"rows":rows,"total":total,"cols":cols}

def filtros_disp(df):
    def u(col):
        if col not in df.columns: return []
        return sorted(set(str(v).strip() for v in df[col].dropna()
                         if str(v).strip() not in ("","nan","None")))
    fd=fm=None
    meses=[]
    if "_fecha_dt" in df.columns:
        dts=df["_fecha_dt"].dropna()
        if len(dts): fd=str(dts.min().date()); fm=str(dts.max().date())
    if "_mes" in df.columns:
        meses = sorted(set(str(v).strip() for v in df["_mes"].dropna()
                           if str(v).strip() not in ("","nan","None")))
    # Columnas categóricas disponibles para filtrar
    cat_cols = [c for c in df.columns
                if not c.startswith("_") and df[c].dtype == object
                and df[c].nunique() <= 60 and df[c].nunique() >= 2]
    return {
        "estado":     u("estado"),
        "fuente":     u("fuente"),
        "categoria":  u("categoria"),
        "provincia":  u("provincia"),
        "forma_envio":u("forma_envio") if "forma_envio" in df.columns else [],
        "fecha_min":  fd,
        "fecha_max":  fm,
        "meses":      meses,
        "cat_cols":   cat_cols[:15],  # columnas disponibles para filtro dinámico
    }

def apply_filters(df, f):
    mask = pd.Series([True]*len(df), index=df.index)
    for col, val in [("estado", f.get("estado","__all__")),
                     ("fuente", f.get("fuente","__all__")),
                     ("categoria", f.get("categoria","__all__")),
                     ("provincia", f.get("provincia","__all__"))]:
        if val and val != "__all__" and col in df.columns:
            mask &= df[col].fillna("") == val
    # Filtro por mes (YYYY-MM)
    mes = f.get("mes","__all__")
    if mes and mes != "__all__" and "_mes" in df.columns:
        mask &= df["_mes"].fillna("") == mes
    # Filtro dinámico extra (custom_col + custom_val)
    if f.get("custom_col") and f.get("custom_val") and f["custom_col"] in df.columns:
        mask &= df[f["custom_col"]].fillna("").astype(str) == f["custom_val"]
    if f.get("fecha_desde") and "_fecha_dt" in df.columns:
        try: mask &= df["_fecha_dt"] >= pd.to_datetime(f["fecha_desde"])
        except: pass
    if f.get("fecha_hasta") and "_fecha_dt" in df.columns:
        try:
            # Incluir el día completo sumando 1 día (hasta las 23:59:59)
            hasta = pd.to_datetime(f["fecha_hasta"]) + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
            mask &= df["_fecha_dt"] <= hasta
        except: pass
    if f.get("texto"):
        txt = f["texto"].lower()
        tmask = pd.Series([False]*len(df), index=df.index)
        for col in df.select_dtypes(include="object").columns:
            if col.startswith("_"): continue
            tmask |= df[col].fillna("").astype(str).str.lower().str.contains(txt, na=False)
        mask &= tmask
    return df[mask].reset_index(drop=True)

def _get_combined(sids):
    frames = [STORE[s]["df"] for s in sids if s in STORE]
    if not frames: return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)

# ═══════════════════════════════════════════════════════════════════════════
# API
# ═══════════════════════════════════════════════════════════════════════════

def ok(d): return jsonify({"ok":True,**d})
def err(m,c=400): return jsonify({"ok":False,"error":str(m)}),c

@app.route("/")
def index(): return HTML

@app.route("/api/upload/ml", methods=["POST"])
def api_upload_ml():
    if "file" not in request.files: return err("Sin archivo.")
    f = request.files["file"]
    try:
        raw = f.read()
        ext = f.filename.rsplit(".", 1)[-1].lower() if "." in f.filename else ""
        if ext == "csv":
            # CSV subido en ML → redirigir automáticamente al parser de TN
            df_new, auto_config = read_tn(raw, f.filename)
            df_new["fuente"] = "Tienda Nube"
            sid_tn = str(uuid.uuid4())
            col_info_tn = infer_column_roles(df_new)
            STORE[sid_tn] = {"name": f.filename, "source": "tn", "df": df_new,
                             "config": auto_config, "col_info": col_info_tn}
            return ok({"sid": sid_tn, "filename": f.filename, "source": "tn",
                       "total_rows": len(df_new), "cols": list(df_new.columns),
                       "col_info": col_info_tn, "config": auto_config,
                       "filtros": filtros_disp(df_new),
                       "_aviso": "CSV detectado: cargado como Tienda Nube automáticamente"})
        df_new, auto_config = read_ml(raw, f.filename)
        col_info = infer_column_roles(df_new)

        # ── UPSERT: fusionar con el acumulado de ML ──────────────────────
        n_added = n_updated = 0
        KEY = "id_venta"  # columna clave: "# de venta"

        if ML_STORE["df"] is None:
            # Primera carga: guardar todo
            df_merged = df_new.copy()
            n_added   = len(df_merged)
        else:
            df_acc = ML_STORE["df"].copy()

            if KEY in df_acc.columns and KEY in df_new.columns:
                keys_acc = set(df_acc[KEY].dropna().astype(str))
                keys_new = df_new[KEY].astype(str)

                # Filas nuevas que no existen en el acumulado
                mask_new  = ~keys_new.isin(keys_acc)
                # Filas que ya existen (actualizar)
                mask_upd  = keys_new.isin(keys_acc)

                n_added   = int(mask_new.sum())
                n_updated = int(mask_upd.sum())

                # Quitar del acumulado las filas que van a ser reemplazadas
                keys_to_update = set(keys_new[mask_upd].tolist())
                df_acc = df_acc[~df_acc[KEY].astype(str).isin(keys_to_update)]

                # Unir: acumulado limpio + filas nuevas + filas actualizadas
                df_merged = pd.concat([df_acc, df_new], ignore_index=True)
            else:
                # Sin columna clave: concatenar y deduplicar
                df_merged = pd.concat([df_acc, df_new], ignore_index=True).drop_duplicates()
                n_added   = len(df_new)

        # Garantizar que fuente siempre sea "Mercado Libre" en el acumulado
        df_merged["fuente"] = "Mercado Libre"

        # Guardar en ML_STORE
        ML_STORE["df"]       = df_merged
        ML_STORE["config"]   = auto_config
        ML_STORE["col_info"] = col_info
        ML_STORE["files"].append(f.filename)

        # Crear o reutilizar el sid fijo de ML
        if ML_STORE["sid"] is None:
            ML_STORE["sid"] = str(uuid.uuid4())
        sid = ML_STORE["sid"]

        STORE[sid] = {
            "name":     "Mercado Libre (acumulado)",
            "source":   "ml",
            "df":       df_merged,
            "config":   auto_config,
            "col_info": col_info,
        }

        return ok({
            "sid":        sid,
            "filename":   f.filename,
            "source":     "ml",
            "total_rows": len(df_merged),
            "cols":       list(df_merged.columns),
            "col_info":   col_info,
            "config":     auto_config,
            "filtros":    filtros_disp(df_merged),
            "upsert": {
                "added":   n_added,
                "updated": n_updated,
                "total":   len(df_merged),
                "files":   ML_STORE["files"],
            }
        })
    except Exception as e:
        traceback.print_exc(); return err(str(e))

@app.route("/api/upload/tn", methods=["POST"])
def api_upload_tn():
    if "file" not in request.files: return err("Sin archivo.")
    f = request.files["file"]
    try:
        raw = f.read()
        df, auto_config = read_tn(raw, f.filename)
        # Garantizar fuente siempre correcta
        df["fuente"] = "Tienda Nube"
        sid = str(uuid.uuid4())
        col_info = infer_column_roles(df)
        STORE[sid] = {"name":f.filename,"source":"tn","df":df,
                      "config":auto_config,"col_info":col_info}
        return ok({"sid":sid,"filename":f.filename,"source":"tn",
                   "total_rows":len(df),"cols":list(df.columns),
                   "col_info":col_info,"config":auto_config,
                   "filtros":filtros_disp(df)})
    except Exception as e:
        traceback.print_exc(); return err(str(e))

@app.route("/api/upload/custom", methods=["POST"])
def api_upload_custom():
    """Carga cualquier Excel/CSV. Retorna info de columnas para configurar."""
    if "file" not in request.files: return err("Sin archivo.")
    f = request.files["file"]
    try:
        raw = f.read()
        df_raw = read_raw_file(raw, f.filename)
        col_info = infer_column_roles(df_raw)
        # Config inicial auto-inferida
        auto_config = {info["role"]: col
                       for col, info in col_info.items()
                       if info.get("role")}
        # Aplicar config inicial
        df = apply_config_to_df(df_raw.copy(), auto_config)
        if "fuente" not in df.columns:
            name = Path(f.filename).stem[:20]
            df["fuente"] = name
        sid = str(uuid.uuid4())
        STORE[sid] = {"name":f.filename,"source":"custom","df":df,
                      "df_raw":df_raw,"config":auto_config,"col_info":col_info}
        return ok({"sid":sid,"filename":f.filename,"source":"custom",
                   "total_rows":len(df_raw),
                   "cols":[c for c in df_raw.columns if not c.startswith("_")],
                   "col_info":col_info,"config":auto_config,
                   "filtros":filtros_disp(df)})
    except Exception as e:
        traceback.print_exc(); return err(str(e))

@app.route("/api/config/<sid>", methods=["POST"])
def api_config(sid):
    """Aplica nueva configuración de columnas a un dataset custom."""
    if sid not in STORE: return err("Dataset no encontrado.", 404)
    ds = STORE[sid]
    new_config = request.json or {}
    try:
        df_raw = ds.get("df_raw", ds["df"])
        df = apply_config_to_df(df_raw.copy(), new_config)
        name = Path(ds["name"]).stem[:20]
        if "fuente" not in df.columns:
            df["fuente"] = name
        ds["config"] = new_config
        ds["df"] = df
        return ok({"sid":sid,"config":new_config,"filtros":filtros_disp(df),
                   "preview": df.head(5).fillna("").astype(str).to_dict("records")})
    except Exception as e:
        traceback.print_exc(); return err(str(e))

@app.route("/api/dashboard", methods=["POST"])
def api_dashboard():
    body = request.json or {}
    sids = body.get("sids", [])
    f    = body.get("filtros", {})
    periodo = body.get("periodo","dia")
    pg   = int(body.get("page", 0))
    # Visualización custom
    viz = body.get("viz", {})  # { by_col, val_col, agg_fn }

    if not sids: return err("No hay datasets.", 400)
    df0 = _get_combined(sids)
    if df0.empty: return err("Sin datos.", 400)
    df  = apply_filters(df0, f)

    # Métricas por fuente
    fuentes = df["fuente"].unique() if "fuente" in df.columns else []
    metricas_por_fuente = {}
    for fnt in fuentes:
        sub = df[df["fuente"]==fnt]
        metricas_por_fuente[str(fnt)] = metricas(sub)

    # Visualización custom adicional
    viz_custom = []
    if viz.get("by_col") and viz.get("val_col"):
        viz_custom = grp_custom(df, viz["by_col"], viz["val_col"],
                                viz.get("agg_fn","sum"), top=int(viz.get("top_n",15)))

    return ok({
        "metricas":           metricas(df),
        "metricas_por_fuente":metricas_por_fuente,
        "por_estado":         grp(df,"estado"),
        "por_publicacion":    grp(df,"publicacion",top=20),
        "por_fuente":         grp(df,"fuente"),
        "por_categoria":      grp(df,"categoria",top=15),
        "por_envio":          grp(df,"forma_envio") if "forma_envio" in df.columns else [],
        "por_tiempo":         por_tiempo(df, periodo),
        "por_tiempo_fuentes": {
            str(fnt): por_tiempo(df[df["fuente"]==fnt], periodo)
            for fnt in fuentes
        },
        "por_provincia":      grp(df,"provincia",top=10),
        "flex_zonas":         flex_por_zona(df),
        "viz_custom":         viz_custom,
        "tabla":              tabla_ventas(df, pg),
        "n_filtradas":        len(df),
        "n_total":            len(df0),
        "filtros_disponibles":filtros_disp(df0),
        "col_names":          [c for c in df.columns if not c.startswith("_")],
        "col_info":           {
            c: {"type": ("number" if pd.api.types.is_numeric_dtype(df[c]) else
                         "date"   if pd.api.types.is_datetime64_any_dtype(df[c]) else
                         "text")}
            for c in df.columns if not c.startswith("_")
        },
    })

@app.route("/api/delete/<sid>", methods=["DELETE"])
def api_delete(sid):
    STORE.pop(sid, None)
    # Si se elimina el sid de ML, resetear el acumulado
    if ML_STORE["sid"] == sid:
        ML_STORE["sid"]     = None
        ML_STORE["df"]      = None
        ML_STORE["config"]  = None
        ML_STORE["col_info"]= None
        ML_STORE["files"]   = []
    return ok({"deleted": sid})


# ═══════════════════════════════════════════════════════════════════════════
# HTML COMPLETO
# ═══════════════════════════════════════════════════════════════════════════
HTML = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashify — Multi Marketplace</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.2.0/dist/chartjs-plugin-datalabels.min.js"></script>
<style>
:root{
  --bg:#f0f4f8;--card:#fff;--sb:#1a2535;--sb2:#131e2d;
  --acc:#2563eb;--acc2:#1d4ed8;--grn:#16a34a;--red:#dc2626;--orn:#d97706;
  --tx:#1e293b;--mu:#64748b;--br:#e2e8f0;--r:10px;
  --ml:#f59e0b;--tn:#7c3aed;--cx:#0d9488;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,sans-serif;font-size:13px;
  background:var(--bg);color:var(--tx);height:100vh;display:flex;
  flex-direction:column;overflow:hidden;-webkit-font-smoothing:antialiased}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-thumb{background:#c8d3de;border-radius:3px}
/* Topbar */
#top{min-height:52px;background:var(--sb);display:flex;align-items:center;
  gap:8px;padding:0 12px;flex-shrink:0;flex-wrap:wrap}
.logo{display:flex;align-items:center;gap:8px;color:#fff;font-weight:700;font-size:15px}
.chips{display:flex;gap:3px}
.chip{font-size:9px;font-weight:800;padding:2px 6px;border-radius:3px;letter-spacing:.05em}
.chip-ml{background:var(--ml);color:#1a1a1a}
.chip-tn{background:var(--tn);color:#fff}
.chip-cx{background:var(--cx);color:#fff}
.tbtn{border:none;color:#fff;
  padding:7px 14px;border-radius:7px;cursor:pointer;font-size:12px;font-weight:600;
  transition:all .15s;display:inline-flex;align-items:center;gap:6px;letter-spacing:.01em}
.tbtn.ml{background:#d97706;color:#fff}.tbtn.ml:hover{background:#b45309}
.tbtn.tn{background:#7c3aed;color:#fff}.tbtn.tn:hover{background:#6d28d9}
.tbtn.cx{background:#0d9488;color:#fff}.tbtn.cx:hover{background:#0f766e}
/* Layout */
#main{display:flex;flex:1;overflow:hidden}
#sb{width:234px;background:var(--sb2);display:flex;flex-direction:column;overflow-y:auto;flex-shrink:0}
#ct{flex:1;overflow-y:auto;padding:14px 16px}
/* Sidebar */
.sb-inner{padding:13px 11px}
.ss{font-size:9px;font-weight:700;letter-spacing:.1em;color:rgba(255,255,255,.24);
  margin-bottom:6px;text-transform:uppercase}
.src-area{border-radius:8px;overflow:hidden;border:1px solid rgba(255,255,255,.07);margin-bottom:8px}
.src-head{display:flex;align-items:center;gap:7px;padding:8px 10px}
.src-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.src-dot.ml{background:var(--ml)}.src-dot.tn{background:var(--tn)}.src-dot.cx{background:var(--cx)}
.src-nm{font-size:11px;font-weight:600;color:rgba(255,255,255,.75);flex:1}
.src-bd{font-size:9px;font-weight:700;padding:1px 5px;border-radius:3px}
.src-bd.ml{background:rgba(245,158,11,.18);color:var(--ml)}
.src-bd.tn{background:rgba(124,58,237,.18);color:#a78bfa}
.src-bd.cx{background:rgba(13,148,136,.18);color:#2dd4bf}
.src-files{border-top:1px solid rgba(255,255,255,.05)}
.src-file{display:flex;align-items:center;gap:5px;padding:5px 10px 5px 18px}
.src-fn{flex:1;font-size:11px;color:rgba(255,255,255,.5);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.src-fr{font-size:10px;color:rgba(255,255,255,.26)}
.sdl{background:none;border:none;cursor:pointer;color:rgba(255,60,60,.35);font-size:14px;line-height:1;padding:0}
.sdl:hover{color:#f87171}
.cfg-btn{font-size:10px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);
  color:rgba(255,255,255,.5);border-radius:4px;padding:2px 6px;cursor:pointer;margin-left:2px}
.cfg-btn:hover{background:rgba(255,255,255,.12);color:#fff}
.add-btn{width:100%;padding:6px;background:rgba(255,255,255,.04);
  border:1px dashed rgba(255,255,255,.1);border-radius:5px;color:rgba(255,255,255,.36);
  font-size:11px;cursor:pointer;transition:all .15s;margin:3px 0 7px}
.add-btn.ml:hover{border-color:var(--ml);color:var(--ml);background:rgba(245,158,11,.07)}
.add-btn.tn:hover{border-color:#a78bfa;color:#a78bfa;background:rgba(124,58,237,.07)}
.add-btn.cx:hover{border-color:#2dd4bf;color:#2dd4bf;background:rgba(13,148,136,.07)}
/* Filtros */
.filt-sep{height:1px;background:rgba(255,255,255,.06);margin:10px 0}
.fg{margin-bottom:7px}
.fl{font-size:10px;color:rgba(255,255,255,.36);margin-bottom:3px;display:block;font-weight:500}
select,input[type=text],input[type=date]{width:100%;background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.1);border-radius:5px;padding:6px 8px;
  color:#fff;font-size:11px;outline:none;transition:border-color .15s}
select:focus,input:focus{border-color:var(--acc)}
select option{background:#1a2535}
.dr{display:flex;gap:4px}.dr input{flex:1}
.bclr{width:100%;margin-top:5px;padding:6px;border-radius:5px;
  border:1px solid rgba(255,255,255,.1);background:transparent;
  color:rgba(255,255,255,.36);cursor:pointer;font-size:11px;transition:all .15s}
.bclr:hover{background:rgba(255,255,255,.06);color:rgba(255,255,255,.7)}
/* Slider range viz */
input[type=range]{-webkit-appearance:none;appearance:none;height:4px;border-radius:3px;
  background:rgba(255,255,255,.12);outline:none;border:none;padding:0;cursor:pointer}
input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
  width:14px;height:14px;border-radius:50%;background:var(--acc);cursor:pointer;
  border:2px solid rgba(255,255,255,.3);transition:transform .15s}
input[type=range]::-webkit-slider-thumb:hover{transform:scale(1.2)}
/* Viz empty state */
#viz-empty-state{transition:opacity .2s}
/* Panel de visualización custom */
.viz-panel{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
  border-radius:8px;padding:10px;margin-top:2px}
.viz-row{display:flex;gap:4px;margin-bottom:5px}
.viz-row select{flex:1}
.viz-apply{width:100%;padding:6px;border-radius:5px;background:var(--acc);
  border:none;color:#fff;font-size:11px;cursor:pointer;font-weight:600}
.viz-apply:hover{background:var(--acc2)}
.viz-fn-btn{padding:4px 6px;border-radius:5px;border:1px solid rgba(255,255,255,.15);
  background:rgba(255,255,255,.06);color:rgba(255,255,255,.6);cursor:pointer;font-size:11px;
  transition:all .15s;text-align:center}
.viz-fn-btn.act{background:var(--acc);color:#fff;border-color:var(--acc)}
.viz-fn-btn:hover{background:rgba(255,255,255,.12)}
.chat-chip{padding:4px 10px;border-radius:20px;border:1px solid var(--br);background:#f8fafc;
  color:var(--mu);cursor:pointer;font-size:11px;white-space:nowrap;transition:all .15s}
.chat-chip:hover{background:#eff6ff;border-color:var(--acc);color:var(--acc)}
.msg-user{background:#eff6ff;border-radius:12px 12px 4px 12px;padding:8px 12px;font-size:13px;
  align-self:flex-end;max-width:80%;color:var(--acc);font-weight:500}
.msg-bot{background:#f8fafc;border-radius:12px 12px 12px 4px;padding:10px 14px;font-size:13px;
  align-self:flex-start;max-width:95%;border:1px solid var(--br);line-height:1.55}
.msg-bot-chart{margin-top:10px;height:240px;position:relative}
.msg-thinking{color:var(--mu);font-size:12px;font-style:italic;align-self:flex-start;padding:4px 0}
/* ── Dashi ─────────────────────────────────────────── */
@keyframes dashiBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
@keyframes dashiPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.2)}}
@keyframes dashiWiggle{0%,100%{transform:rotate(0deg)}25%{transform:rotate(-6deg)}75%{transform:rotate(6deg)}}
@keyframes dashiSlideUp{from{opacity:0;transform:translateY(20px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}
@keyframes dashiTyping{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}
#dashi-btn:hover{transform:scale(1.1) translateY(-4px)!important;filter:drop-shadow(0 8px 20px rgba(0,0,0,.4))!important}
.dashi-chip{padding:5px 11px;border-radius:20px;border:1.5px solid #f3d5d5;background:#fff5f5;
  color:#c0392b;cursor:pointer;font-size:11px;font-weight:500;transition:all .15s;white-space:nowrap}
.dashi-chip:hover{background:#c0392b;color:#fff;border-color:#c0392b}
.dmsg-user{background:linear-gradient(135deg,#c0392b,#e74c3c);color:#fff;border-radius:18px 18px 4px 18px;
  padding:9px 13px;font-size:13px;align-self:flex-end;max-width:82%;line-height:1.45;box-shadow:0 2px 8px rgba(192,57,43,.3)}
.dmsg-bot{background:#fff;border-radius:4px 18px 18px 18px;padding:11px 14px;font-size:13px;
  align-self:flex-start;max-width:90%;border:1.5px solid #f0ece8;line-height:1.55;
  box-shadow:0 2px 8px rgba(0,0,0,.06)}
.dmsg-chart{margin-top:10px;height:220px;position:relative}
.dmsg-thinking{display:flex;gap:4px;align-items:center;padding:10px 14px;background:#fff;
  border-radius:4px 18px 18px 18px;border:1.5px solid #f0ece8;align-self:flex-start}
.dmsg-thinking span{width:7px;height:7px;border-radius:50%;background:#c0392b;display:inline-block}
.dmsg-thinking span:nth-child(1){animation:dashiTyping 1.2s .0s infinite}
.dmsg-thinking span:nth-child(2){animation:dashiTyping 1.2s .2s infinite}
.dmsg-thinking span:nth-child(3){animation:dashiTyping 1.2s .4s infinite}
/* Welcome */
#wlc{display:flex;align-items:center;justify-content:center;flex:1;
  gap:18px;padding:28px;flex-direction:column}
.wlc-inner{display:flex;gap:16px;max-width:920px;width:100%;flex-wrap:wrap;justify-content:center}
.drop-card{flex:1;min-width:240px;max-width:290px;border:2px dashed var(--br);border-radius:14px;
  padding:30px 24px;display:flex;flex-direction:column;align-items:center;gap:11px;
  cursor:pointer;transition:all .2s;background:#fff;text-align:center}
.drop-card.ml:hover,.drop-card.ml.dg{border-color:var(--ml);background:#fffbeb}
.drop-card.tn:hover,.drop-card.tn.dg{border-color:var(--tn);background:#f5f3ff}
.drop-card.cx:hover,.drop-card.cx.dg{border-color:var(--cx);background:#f0fdfa}
.dc-ico{width:54px;height:54px;border-radius:13px;display:flex;align-items:center;justify-content:center}
.dc-ico.ml{background:#fef3c7}.dc-ico.tn{background:#ede9fe}.dc-ico.cx{background:#ccfbf1}
.dc-t{font-size:15px;font-weight:700}
.dc-s{color:var(--mu);font-size:12px;line-height:1.5}
.dc-btn{padding:8px 20px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;border:none;margin-top:2px}
.dc-btn.ml{background:var(--ml);color:#1a1a1a}.dc-btn.ml:hover{background:#d97706}
.dc-btn.tn{background:var(--tn);color:#fff}.dc-btn.tn:hover{background:#6d28d9}
.dc-btn.cx{background:var(--cx);color:#fff}.dc-btn.cx:hover{background:#0f766e}
.fmt{display:flex;gap:5px;flex-wrap:wrap;justify-content:center}
.bg{padding:2px 8px;border-radius:20px;font-size:10px;font-weight:500}
.bg.ml{background:#fef3c7;color:#92400e}.bg.tn{background:#ede9fe;color:#5b21b6}
.bg.cx{background:#ccfbf1;color:#0f766e}
/* KPIs */
#kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:10px;margin-bottom:12px}
.kpi{background:#fff;border-radius:var(--r);padding:13px 16px;
  border:1px solid var(--br);position:relative;overflow:hidden}
.kpi::before{content:"";position:absolute;top:0;left:0;right:0;height:3px}
.kpi.bl::before{background:var(--acc)}.kpi.gr::before{background:var(--grn)}
.kpi.or::before{background:var(--orn)}.kpi.rd::before{background:var(--red)}
.kpi.pu::before{background:#7c3aed}.kpi.tl::before{background:#0d9488}
.kl{font-size:9px;font-weight:700;color:var(--mu);letter-spacing:.05em;margin-bottom:5px;text-transform:uppercase}
.kv{font-size:22px;font-weight:700;line-height:1.1}
.ks{font-size:10px;color:var(--mu);margin-top:3px}
/* Comparativa */
.cmp-bar{display:flex;gap:10px;margin-bottom:12px;overflow-x:auto}
.cmp-card{border-radius:var(--r);padding:13px 16px;border:2px solid;flex:1;min-width:180px}
.cmp-card.ml{background:#fffbeb;border-color:#fde68a}
.cmp-card.tn{background:#f5f3ff;border-color:#ddd6fe}
.cmp-card.cx{background:#f0fdfa;border-color:#99f6e4}
.cmp-card.gen{background:#f8fafc;border-color:#e2e8f0}
.cmp-lbl{font-size:10px;font-weight:700;letter-spacing:.06em;margin-bottom:7px}
.cmp-lbl.ml{color:#92400e}.cmp-lbl.tn{color:#5b21b6}
.cmp-lbl.cx{color:#0f766e}.cmp-lbl.gen{color:var(--mu)}
.cmp-row{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:3px}
.cmp-k{font-size:11px;color:var(--mu)}.cmp-v{font-size:13px;font-weight:600}
/* Cards */
.card{background:#fff;border-radius:var(--r);border:1px solid var(--br);overflow:hidden}
.ch{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--br)}
.ct{font-size:13px;font-weight:600}.cs{font-size:11px;color:var(--mu)}
.cb{padding:12px}.cw{position:relative;height:218px}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px}
.c2{grid-column:span 2}
@media(max-width:1100px){.g3{grid-template-columns:1fr 1fr}}
@media(max-width:760px){.g2,.g3{grid-template-columns:1fr}}
/* Tabla */
.tw{overflow:auto;max-height:260px}
table{width:100%;border-collapse:collapse;font-size:12px}
thead th{position:sticky;top:0;background:#f8fafc;padding:7px 11px;text-align:left;
  font-weight:600;color:var(--mu);border-bottom:2px solid var(--br);white-space:nowrap}
tbody td{padding:5px 11px;border-bottom:1px solid #f1f5f9;white-space:nowrap;
  max-width:190px;overflow:hidden;text-overflow:ellipsis}
tbody tr:hover td{background:#f8fafc}
.nr{text-align:right;font-variant-numeric:tabular-nums}
.pb{display:flex;align-items:center;gap:6px}
.pt{flex:1;height:4px;background:#e2e8f0;border-radius:3px;overflow:hidden;min-width:36px}
.pf{height:100%;border-radius:3px;transition:width .3s}
.tag{display:inline-block;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:600;white-space:nowrap}
.tOK{background:#dcfce7;color:#15803d}.tC{background:#fef3c7;color:#92400e}
.tX{background:#fee2e2;color:#b91c1c}.tP{background:#e0e7ff;color:#3730a3}
.tD{background:#f1f5f9;color:#475569}
/* Paginación */
.pg{display:flex;align-items:center;justify-content:space-between;
  padding:8px 15px;border-top:1px solid var(--br);font-size:12px;color:var(--mu)}
.pgb{display:flex;gap:4px}
.pb2{padding:4px 10px;border:1px solid var(--br);border-radius:5px;background:#fff;
  cursor:pointer;font-size:12px;transition:all .15s}
.pb2:hover:not(:disabled){border-color:var(--acc);color:var(--acc)}
.pb2:disabled{opacity:.38;cursor:not-allowed}
/* Periodo */
.ptabs{display:flex;gap:2px;background:#f1f5f9;border-radius:5px;padding:2px}
.ptab{padding:3px 9px;border-radius:4px;cursor:pointer;font-size:11px;font-weight:500;
  color:var(--mu);border:none;background:none;transition:all .15s}
.ptab.act{background:#fff;color:var(--acc);box-shadow:0 1px 3px rgba(0,0,0,.09)}
/* Loading / Error */
#ld{display:none;position:fixed;inset:0;background:rgba(10,17,30,.72);
  align-items:center;justify-content:center;z-index:500;flex-direction:column;gap:12px}
#ld.show{display:flex}
.sp{width:36px;height:36px;border:3px solid rgba(255,255,255,.18);border-top-color:#fff;
  border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.lm{color:#fff;font-size:13px}
#eb{display:none;padding:9px 16px;background:#fef2f2;border-bottom:1px solid #fecaca;
  align-items:center;gap:10px;font-size:13px;color:#b91c1c;flex-shrink:0}
#eb.show{display:flex}
.ex{background:none;border:none;cursor:pointer;color:#b91c1c;font-size:16px;margin-left:auto}
/* Modal configurador de columnas */
.modal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:400;
  align-items:center;justify-content:center;padding:20px}
.modal-bg.open{display:flex}
.modal{background:#fff;border-radius:14px;max-width:640px;width:100%;
  max-height:90vh;display:flex;flex-direction:column;overflow:hidden}
.modal-head{display:flex;align-items:center;justify-content:space-between;
  padding:16px 20px;border-bottom:1px solid var(--br)}
.modal-title{font-size:15px;font-weight:700}
.modal-body{overflow-y:auto;padding:20px;flex:1}
.modal-foot{padding:14px 20px;border-top:1px solid var(--br);display:flex;gap:8px;justify-content:flex-end}
.role-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.role-item{border:1px solid var(--br);border-radius:8px;padding:10px 12px}
.role-lbl{font-size:10px;font-weight:700;color:var(--mu);text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px;display:flex;align-items:center;gap:5px}
.role-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.role-desc{font-size:10px;color:var(--mu);margin-bottom:6px}
.role-sel{width:100%;background:#f8fafc;border:1px solid var(--br);border-radius:5px;
  padding:5px 8px;font-size:11px;color:var(--tx);outline:none}
.role-sel:focus{border-color:var(--acc)}
.preview-table{width:100%;font-size:11px;border-collapse:collapse;margin-top:10px}
.preview-table th{background:#f8fafc;padding:5px 8px;text-align:left;font-weight:600;
  color:var(--mu);border-bottom:1px solid var(--br)}
.preview-table td{padding:4px 8px;border-bottom:1px solid #f1f5f9}
.btn{padding:8px 18px;border-radius:7px;font-size:13px;font-weight:600;cursor:pointer;border:none;transition:all .15s}
.btn-primary{background:var(--acc);color:#fff}.btn-primary:hover{background:var(--acc2)}
.btn-ghost{background:#f1f5f9;color:var(--mu)}.btn-ghost:hover{background:#e2e8f0}
.info-tip{background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:8px 12px;font-size:11px;color:#1d4ed8;margin-bottom:14px}
/* Platform tabs */
.ptf{display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap}
.ptf-btn{display:flex;align-items:center;gap:7px;padding:9px 18px;border-radius:9px;
  border:2px solid transparent;cursor:pointer;font-size:13px;font-weight:600;
  transition:all .18s;background:#fff;color:var(--mu)}
.ptf-btn:hover{transform:translateY(-1px);box-shadow:0 3px 10px rgba(0,0,0,.1)}
.ptf-btn.all{border-color:var(--br)}.ptf-btn.all.act{border-color:var(--acc);background:#eff6ff;color:var(--acc)}
.ptf-btn.ml-t{border-color:#fde68a}.ptf-btn.ml-t.act{border-color:var(--ml);background:#fffbeb;color:#92400e}
.ptf-btn.tn-t{border-color:#ddd6fe}.ptf-btn.tn-t.act{border-color:var(--tn);background:#f5f3ff;color:#5b21b6}
.ptf-btn.cx-t{border-color:#99f6e4}.ptf-btn.cx-t.act{border-color:var(--cx);background:#f0fdfa;color:#0f766e}
.ptf-dot{width:9px;height:9px;border-radius:50%;flex-shrink:0}
.ptf-cnt{font-size:10px;font-weight:700;padding:1px 7px;border-radius:10px;margin-left:2px}
.ptf-cnt.ml{background:#fef3c7;color:#92400e}
.ptf-cnt.tn{background:#ede9fe;color:#5b21b6}
.ptf-cnt.cx{background:#ccfbf1;color:#0f766e}
.ptf-cnt.all{background:#eff6ff;color:var(--acc)}
/* Dash header */
.dh{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px}
.dt{font-size:17px;font-weight:700}
.nb{background:#eff6ff;color:var(--acc);padding:3px 11px;border-radius:16px;font-size:12px;font-weight:600}
input[type=file]{display:none}
</style>
</head>
<body>
<div id="ld"><div class="sp"></div><div class="lm" id="lm">Procesando...</div></div>
<div id="eb"><span id="et"></span><button class="ex" onclick="hE()">✕</button></div>

<div id="top">
  <div class="logo">
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
    Dashify
    <div class="chips">
      <span class="chip chip-ml">ML</span>
      <span class="chip chip-tn">TN</span>
      <span class="chip chip-cx">+ Excel</span>
    </div>
  </div>
  <div style="flex:1"></div>
  <button class="tbtn ml" onclick="trig('ml')">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
    Cargar reporte ML
  </button>
  <button class="tbtn tn" onclick="trig('tn')">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
    Cargar reporte TN
  </button>
  <button class="tbtn cx" onclick="trig('cx')">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
    Cualquier Excel/CSV
  </button>

</div>

<input type="file" id="fi-ml" accept=".xlsx,.xls" onchange="onFI(event,'ml')">
<input type="file" id="fi-tn" accept=".xlsx,.xls,.csv,.CSV" onchange="onFI(event,'tn')">
<input type="file" id="fi-cx" accept=".xlsx,.xls,.csv,.ods" onchange="onFI(event,'cx')">

<div id="main">
<div id="sb">
<div class="sb-inner">

  <div class="src-area">
    <div class="src-head"><div class="src-dot ml"></div><span class="src-nm">Mercado Libre</span><span class="src-bd ml">ML</span></div>
    <div class="src-files" id="files-ml"><div style="padding:6px 10px 6px 18px;font-size:11px;color:rgba(255,255,255,.22)">Sin archivos</div></div>
    <button class="add-btn ml" onclick="trig('ml')">+ Cargar reporte ML</button>
  </div>

  <div class="src-area">
    <div class="src-head"><div class="src-dot tn"></div><span class="src-nm">Tienda Nube</span><span class="src-bd tn">TN</span></div>
    <div class="src-files" id="files-tn"><div style="padding:6px 10px 6px 18px;font-size:11px;color:rgba(255,255,255,.22)">Sin archivos</div></div>
    <button class="add-btn tn" onclick="trig('tn')">+ Cargar reporte TN</button>
  </div>

  <div class="src-area">
    <div class="src-head"><div class="src-dot cx"></div><span class="src-nm">Fuente personalizada</span><span class="src-bd cx">XLS</span></div>
    <div class="src-files" id="files-cx"><div style="padding:6px 10px 6px 18px;font-size:11px;color:rgba(255,255,255,.22)">Sin archivos</div></div>
    <button class="add-btn cx" onclick="trig('cx')">+ Cualquier Excel/CSV</button>
  </div>

  <div class="filt-sep"></div>
  <div class="ss">FILTROS</div>

  <div class="fg">
    <label class="fl">Canal / Fuente</label>
    <select id="ff" onchange="rf()">
      <option value="__all__">Todos los canales</option>
    </select>
  </div>
  <div class="fg">
    <label class="fl">Estado</label>
    <select id="fe" onchange="rf()"><option value="__all__">Todos</option></select>
  </div>
  <div class="fg">
    <label class="fl">Categoría / Tipo</label>
    <select id="fcat" onchange="rf()"><option value="__all__">Todas</option></select>
  </div>
  <div class="fg">
    <label class="fl">Provincia / Región</label>
    <select id="fprov" onchange="rf()"><option value="__all__">Todas</option></select>
  </div>
  <div class="fg" id="fg-custom" style="display:none">
    <label class="fl">Filtro extra</label>
    <div class="viz-row">
      <select id="f-ccol" onchange="loadCustomVals()"><option value="">Columna...</option></select>
      <select id="f-cval" onchange="rf()"><option value="__all__">Todos</option></select>
    </div>
  </div>
  <div class="fg">
    <label class="fl">Período</label>
    <div class="dr"><input type="date" id="fd" onchange="onDateChange()"><input type="date" id="fh" onchange="onDateChange()"></div>
  </div>
  <div class="fg" id="fg-mes">
    <label class="fl">Mes</label>
    <select id="fmes" onchange="onMesChange()"><option value="__all__">Todos los meses</option></select>
  </div>
  <div class="fg">
    <label class="fl">Buscar en todo</label>
    <input type="text" id="fq" placeholder="Texto libre..." onkeydown="if(event.key==='Enter')rf()">
  </div>
  <button class="bclr" onclick="clrF()">↺ Limpiar filtros</button>

  <div class="filt-sep"></div>
  <div class="ss">VISUALIZACIÓN EXTRA</div>
  <div class="viz-panel">
    <div style="font-size:10px;color:rgba(255,255,255,.35);margin-bottom:8px;line-height:1.4">
      Construí tu propio gráfico agrupando cualquier columna de tus datos
    </div>
    <div class="fg">
      <label class="fl">Agrupar por <span style="color:rgba(255,255,255,.2)">(eje X / categorías)</span></label>
      <select id="v-by" onchange="vizAutoVal()"><option value="">-- elegí una columna --</option></select>
    </div>
    <div class="fg">
      <label class="fl">Métrica a mostrar <span style="color:rgba(255,255,255,.2)">(eje Y)</span></label>
      <select id="v-val"><option value="">-- elegí una métrica --</option></select>
    </div>
    <div class="fg">
      <label class="fl">Función de agregación</label>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:3px">
        <button class="viz-fn-btn act" id="vfn-sum"   onclick="setVizFn('sum',this)"  >∑ Suma</button>
        <button class="viz-fn-btn"     id="vfn-count" onclick="setVizFn('count',this)"># Conteo</button>
        <button class="viz-fn-btn"     id="vfn-avg"   onclick="setVizFn('avg',this)"  >⌀ Prom.</button>
        <button class="viz-fn-btn"     id="vfn-max"   onclick="setVizFn('max',this)"  >↑ Máx.</button>
      </div>
      <input type="hidden" id="v-agg" value="sum">
    </div>
    <div class="fg">
      <label class="fl">Tipo de gráfico</label>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:3px;margin-bottom:3px">
        <button class="viz-fn-btn act" id="vt-bar"      onclick="setVizType('bar',this)"      title="Barras verticales">▊ Barras</button>
        <button class="viz-fn-btn"     id="vt-horizontalBar" onclick="setVizType('horizontalBar',this)" title="Barras horizontales">▬ Horiz.</button>
        <button class="viz-fn-btn"     id="vt-line"     onclick="setVizType('line',this)"     title="Línea">↗ Línea</button>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:3px">
        <button class="viz-fn-btn"     id="vt-area"     onclick="setVizType('area',this)"     title="Área rellena">◿ Área</button>
        <button class="viz-fn-btn"     id="vt-doughnut" onclick="setVizType('doughnut',this)" title="Torta/Rosca">◉ Torta</button>
        <button class="viz-fn-btn"     id="vt-pie"      onclick="setVizType('pie',this)"      title="Pie">◔ Pie</button>
      </div>
      <input type="hidden" id="v-type" value="bar">
    </div>
    <div class="fg">
      <label class="fl">Top N resultados</label>
      <div style="display:flex;align-items:center;gap:6px">
        <input type="range" id="v-topn" min="5" max="30" value="15" step="5"
               style="flex:1;accent-color:var(--acc);background:transparent;border:none;padding:2px 0"
               oninput="$('v-topn-lbl').textContent=this.value">
        <span id="v-topn-lbl" style="font-size:11px;color:rgba(255,255,255,.6);min-width:20px;text-align:right">15</span>
      </div>
    </div>
    <button class="viz-apply" onclick="applyViz()">▶ Graficar ahora</button>
    <button class="viz-apply" onclick="clearViz()" style="background:rgba(255,255,255,.08);color:rgba(255,255,255,.5);margin-top:3px;font-weight:400">✕ Limpiar</button>
  </div>
</div>
</div>


<div id="ct">
<!-- ═══════════════════════════════════════════
     DASHI — Panda Rojo Analista IA (Flotante)
══════════════════════════════════════════════ -->

<!-- Botón flotante Dashi -->
<div id="dashi-btn" onclick="toggleDashi()" title="¡Preguntale a Dashi!" style="
  position:fixed;bottom:28px;right:28px;width:68px;height:68px;
  border-radius:50%;cursor:pointer;z-index:300;
  filter:drop-shadow(0 4px 16px rgba(0,0,0,.35));
  transition:transform .2s,filter .2s;
  animation:dashiBounce 3s ease-in-out infinite;
  user-select:none;
">
  <svg width="68" height="68" viewBox="0 0 68 68" xmlns="http://www.w3.org/2000/svg">
    <!-- Cuerpo -->
    <circle cx="34" cy="38" r="22" fill="#e8d5b7"/>
    <!-- Parche panza -->
    <ellipse cx="34" cy="42" rx="13" ry="10" fill="#f5ede0"/>
    <!-- Orejas izquierda -->
    <circle cx="14" cy="18" r="9" fill="#1a1a1a"/>
    <circle cx="14" cy="18" r="5.5" fill="#c0392b"/>
    <!-- Orejas derecha -->
    <circle cx="54" cy="18" r="9" fill="#1a1a1a"/>
    <circle cx="54" cy="18" r="5.5" fill="#c0392b"/>
    <!-- Cabeza -->
    <circle cx="34" cy="26" r="20" fill="#c0392b"/>
    <!-- Cara blanca -->
    <ellipse cx="34" cy="28" rx="14" ry="12" fill="#f5ede0"/>
    <!-- Antifaz izquierdo -->
    <ellipse cx="26" cy="24" rx="7" ry="5.5" fill="#1a1a1a" opacity=".85"/>
    <!-- Antifaz derecho -->
    <ellipse cx="42" cy="24" rx="7" ry="5.5" fill="#1a1a1a" opacity=".85"/>
    <!-- Ojos -->
    <circle cx="26" cy="24" r="3" fill="#fff"/>
    <circle cx="42" cy="24" r="3" fill="#fff"/>
    <circle cx="27" cy="24" r="1.5" fill="#1a1a1a"/>
    <circle cx="43" cy="24" r="1.5" fill="#1a1a1a"/>
    <!-- Brillo ojos -->
    <circle cx="27.8" cy="23" r=".7" fill="#fff"/>
    <circle cx="43.8" cy="23" r=".7" fill="#fff"/>
    <!-- Nariz -->
    <ellipse cx="34" cy="30" rx="2.5" ry="1.8" fill="#c0392b"/>
    <!-- Bigotes -->
    <line x1="20" y1="31" x2="30" y2="30.5" stroke="#888" stroke-width=".8"/>
    <line x1="20" y1="33" x2="30" y2="32" stroke="#888" stroke-width=".8"/>
    <line x1="38" y1="30.5" x2="48" y2="31" stroke="#888" stroke-width=".8"/>
    <line x1="38" y1="32" x2="48" y2="33" stroke="#888" stroke-width=".8"/>
    <!-- Cola roja rayada (parte visible) -->
    <path d="M52 54 Q62 46 58 36 Q56 30 60 24" stroke="#c0392b" stroke-width="5" fill="none" stroke-linecap="round"/>
    <path d="M52 54 Q62 46 58 36 Q56 30 60 24" stroke="#e8d5b7" stroke-width="5" fill="none" stroke-linecap="round" stroke-dasharray="4 5"/>
  </svg>
  <!-- Burbuja de notificación -->
  <div id="dashi-notif" style="
    position:absolute;top:-2px;right:-2px;
    background:#e53e3e;color:#fff;border-radius:50%;
    width:20px;height:20px;font-size:11px;font-weight:700;
    display:flex;align-items:center;justify-content:center;
    border:2px solid #fff;animation:dashiPulse 2s ease-in-out infinite;
  ">!</div>
</div>

<!-- Panel Dashi -->
<div id="dashi-panel" style="
  position:fixed;bottom:108px;right:28px;width:380px;max-width:94vw;
  background:#fff;border-radius:20px;
  box-shadow:0 8px 40px rgba(0,0,0,.22);
  z-index:299;display:none;flex-direction:column;overflow:hidden;
  border:1.5px solid #f3e8e8;
  animation:dashiSlideUp .25s cubic-bezier(.34,1.56,.64,1);
  max-height:82vh;
">
  <!-- Header con Dashi -->
  <div style="background:linear-gradient(135deg,#c0392b 0%,#e74c3c 100%);padding:14px 16px;display:flex;align-items:center;gap:12px;flex-shrink:0">
    <!-- Mini Dashi -->
    <div style="width:44px;height:44px;flex-shrink:0;animation:dashiWiggle 2s ease-in-out infinite">
      <svg width="44" height="44" viewBox="0 0 68 68" xmlns="http://www.w3.org/2000/svg">
        <circle cx="34" cy="38" r="22" fill="#e8d5b7"/>
        <ellipse cx="34" cy="42" rx="13" ry="10" fill="#f5ede0"/>
        <circle cx="14" cy="18" r="9" fill="#1a1a1a"/><circle cx="14" cy="18" r="5.5" fill="#c0392b"/>
        <circle cx="54" cy="18" r="9" fill="#1a1a1a"/><circle cx="54" cy="18" r="5.5" fill="#c0392b"/>
        <circle cx="34" cy="26" r="20" fill="#c0392b"/>
        <ellipse cx="34" cy="28" rx="14" ry="12" fill="#f5ede0"/>
        <ellipse cx="26" cy="24" rx="7" ry="5.5" fill="#1a1a1a" opacity=".85"/>
        <ellipse cx="42" cy="24" rx="7" ry="5.5" fill="#1a1a1a" opacity=".85"/>
        <circle cx="26" cy="24" r="3" fill="#fff"/><circle cx="42" cy="24" r="3" fill="#fff"/>
        <circle cx="27" cy="24" r="1.5" fill="#1a1a1a"/><circle cx="43" cy="24" r="1.5" fill="#1a1a1a"/>
        <circle cx="27.8" cy="23" r=".7" fill="#fff"/><circle cx="43.8" cy="23" r=".7" fill="#fff"/>
        <ellipse cx="34" cy="30" rx="2.5" ry="1.8" fill="#c0392b"/>
      </svg>
    </div>
    <div style="flex:1;color:#fff">
      <div style="font-weight:800;font-size:15px;letter-spacing:.3px">Dashi 🐾</div>
      <div style="font-size:11px;opacity:.85" id="dashi-status-txt">Tu analista de ventas</div>
    </div>
    <div style="display:flex;gap:6px">
      <button onclick="clearChat()" title="Limpiar chat" style="background:rgba(255,255,255,.18);border:none;border-radius:8px;color:#fff;cursor:pointer;padding:5px 8px;font-size:12px">🗑</button>
      <button onclick="toggleDashi()" style="background:rgba(255,255,255,.18);border:none;border-radius:8px;color:#fff;cursor:pointer;padding:5px 8px;font-size:14px">✕</button>
    </div>
  </div>

  <!-- Mensajes -->
  <div id="chat-msgs" style="flex:1;overflow-y:auto;padding:14px 14px 8px;display:flex;flex-direction:column;gap:10px;min-height:160px;max-height:420px;background:#fafaf9"></div>

  <!-- Chips -->
  <div id="chat-chips" style="padding:8px 12px 4px;display:flex;gap:5px;flex-wrap:wrap;background:#fafaf9;border-top:1px solid #f0ece8;flex-shrink:0">
    <button class="dashi-chip" onclick="askChip(this)">📈 ¿Vendí más que el mes pasado?</button>
    <button class="dashi-chip" onclick="askChip(this)">🏆 Producto más rentable</button>
    <button class="dashi-chip" onclick="askChip(this)">📍 ¿Qué provincia compra más?</button>
    <button class="dashi-chip" onclick="askChip(this)">🚚 Analizá mis envíos</button>
    <button class="dashi-chip" onclick="askChip(this)">📊 Evolución de ingresos</button>
  </div>

  <!-- Input -->
  <div style="padding:10px 12px 12px;background:#fff;border-top:1px solid #f0ece8;display:flex;gap:8px;flex-shrink:0;align-items:flex-end">
    <input id="chat-input" type="text" placeholder="Preguntale algo a Dashi..." style="
      flex:1;padding:9px 13px;border-radius:20px;border:1.5px solid #e8d5d5;
      font-size:13px;outline:none;transition:border-color .2s;background:#fafaf9;
    " onkeydown="if(event.key==='Enter')sendChat()" onfocus="this.style.borderColor='#c0392b'" onblur="this.style.borderColor='#e8d5d5'">
    <button onclick="sendChat()" id="chat-send" style="
      width:38px;height:38px;border-radius:50%;background:#c0392b;color:#fff;
      border:none;cursor:pointer;font-size:16px;display:flex;align-items:center;
      justify-content:center;flex-shrink:0;transition:transform .15s,background .15s;
    " onmouseover="this.style.background='#a93226';this.style.transform='scale(1.08)'" onmouseout="this.style.background='#c0392b';this.style.transform='scale(1)'">➤</button>
  </div>
</div>


  <!-- Welcome -->
  <div id="wlc" style="display:flex">
    <div style="text-align:center;margin-bottom:12px">
      <div style="font-size:20px;font-weight:700">Dashboard Multi-Marketplace</div>
      <div style="color:var(--mu);font-size:13px;margin-top:4px">Cargá uno o varios archivos de cualquier fuente</div>
    </div>
    <div class="wlc-inner">
      <div class="drop-card ml" id="dz-ml" ondragover="dov(event,'ml')" ondragleave="dlv('ml')" ondrop="drp(event,'ml')">
        <div class="dc-ico ml"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>
        <div class="dc-t">Mercado Libre</div>
        <div class="dc-s">Reporte desde Mis Ventas → Exportar</div>
        <div class="fmt"><span class="bg ml">.xlsx</span><span class="bg ml">.xls</span></div>
        <button class="dc-btn ml" onclick="trig('ml')">Seleccionar</button>
      </div>
      <div class="drop-card tn" id="dz-tn" ondragover="dov(event,'tn')" ondragleave="dlv('tn')" ondrop="drp(event,'tn')">
        <div class="dc-ico tn"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>
        <div class="dc-t">Tienda Nube</div>
        <div class="dc-s">Reporte Panel TN → Informes, o cualquier CSV/Excel etiquetado como Tienda Nube</div>
        <div class="fmt"><span class="bg tn">.xlsx</span><span class="bg tn">.csv</span></div>
        <button class="dc-btn tn" onclick="trig('tn')">Seleccionar</button>
      </div>
      <div class="drop-card cx" id="dz-cx" ondragover="dov(event,'cx')" ondragleave="dlv('cx')" ondrop="drp(event,'cx')">
        <div class="dc-ico cx"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0d9488" stroke-width="1.8"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg></div>
        <div class="dc-t">Cualquier Excel / CSV</div>
        <div class="dc-s">Detecta columnas automáticamente.<br>Podés mapearlas a medida.</div>
        <div class="fmt"><span class="bg cx">.xlsx</span><span class="bg cx">.csv</span><span class="bg cx">.ods</span></div>
        <button class="dc-btn cx" onclick="trig('cx')">Seleccionar</button>
      </div>
    </div>
    <div style="font-size:11px;color:var(--mu);text-align:center">También podés arrastrar archivos directamente sobre las tarjetas</div>
  </div>

  <!-- Dashboard -->
  <div id="dash" style="display:none">
    <!-- Tabs de plataforma -->
    <div class="ptf" id="ptf-bar">
      <button class="ptf-btn all act" onclick="setPlatform('__all__',this)">
        <div class="ptf-dot" style="background:var(--acc)"></div>
        Todas las plataformas
        <span class="ptf-cnt all" id="ptf-cnt-all">—</span>
      </button>
      <button class="ptf-btn ml-t" id="ptf-ml" onclick="setPlatform('Mercado Libre',this)" style="display:none">
        <div class="ptf-dot" style="background:var(--ml)"></div>
        Mercado Libre
        <span class="ptf-cnt ml" id="ptf-cnt-ml">—</span>
      </button>
      <button class="ptf-btn tn-t" id="ptf-tn" onclick="setPlatform('Tienda Nube',this)" style="display:none">
        <div class="ptf-dot" style="background:var(--tn)"></div>
        Tienda Nube
        <span class="ptf-cnt tn" id="ptf-cnt-tn">—</span>
      </button>
    </div>
    <div class="dh">
      <div><div class="dt" id="dash-title">Resumen de ventas</div><div style="font-size:11px;color:var(--mu);margin-top:2px" id="dm"></div></div>
      <span class="nb" id="nb"></span>
    </div>
    <div id="kpis"></div>
    <div id="cmp-bar" class="cmp-bar" style="display:none"></div>

    <div class="g3" style="margin-bottom:12px">
      <div class="card c2">
        <div class="ch">
          <div><div class="ct">Ventas en el tiempo</div><div class="cs">Por canal / fuente</div></div>
          <div class="ptabs">
            <button class="ptab act" onclick="sp('dia',this)">Día</button>
            <button class="ptab" onclick="sp('mes',this)">Mes</button>
            <button class="ptab" onclick="sp('semana',this)">Semana</button>
            <button class="ptab" onclick="sp('anio',this)">Año</button>
          </div>
        </div>
        <div class="cb"><div class="cw"><canvas id="c-t"></canvas></div></div>
      </div>
      <div class="card">
        <div class="ch"><div class="ct" id="ct-fu">Por canal</div><div class="cs">% ingresos</div></div>
        <div class="cb"><div class="cw"><canvas id="c-fu"></canvas></div></div>
      </div>
    </div>

    <div class="g3" style="margin-bottom:12px">
      <div class="card">
        <div class="ch"><div class="ct">Estado</div><div class="cs">Por ingresos</div></div>
        <div class="cb"><div class="cw"><canvas id="c-es"></canvas></div></div>
      </div>
      <div class="card">
        <div class="ch"><div class="ct">Categoría / Tipo</div><div class="cs">Por ingresos</div></div>
        <div class="cb"><div class="cw"><canvas id="c-cat"></canvas></div></div>
      </div>
      <div class="card">
        <div class="ch">
          <div class="ct">Regiones / Provincias</div>
          <div style="display:flex;gap:6px;align-items:center">
            <button id="btn-prov-ing" onclick="setProvSort('ingresos')" style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid var(--acc);background:var(--acc);color:#fff;cursor:pointer;font-weight:600">$ Facturación</button>
            <button id="btn-prov-uds" onclick="setProvSort('unidades')" style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid var(--br);background:#fff;color:var(--mu);cursor:pointer">📦 Unidades</button>
          </div>
        </div>
        <div class="cb"><div class="cw"><canvas id="c-pr"></canvas></div></div>
      </div>
    </div>

    <!-- Envíos Flex por zona -->
    <div class="card" id="flex-card" style="margin-bottom:12px;display:none">
      <div class="ch">
        <div>
          <div class="ct">📦 Envíos Flex por zona</div>
          <div class="cs" id="flex-subtitle">—</div>
        </div>
        <div style="display:flex;gap:6px;align-items:center">
          <button id="btn-flex-cant" onclick="setFlexSort('cantidad')" style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid var(--acc);background:var(--acc);color:#fff;cursor:pointer;font-weight:600">📦 Envíos</button>
          <button id="btn-flex-ing"  onclick="setFlexSort('ingresos')"  style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid var(--br);background:#fff;color:var(--mu);cursor:pointer">$ Facturación</button>
        </div>
      </div>
      <!-- KPIs resumen Flex -->
      <div id="flex-kpis" style="display:flex;gap:0;border-bottom:1px solid var(--br)"></div>
      <!-- Gráfico de barras + Mapa de calor -->
      <div style="display:flex;gap:0;border-bottom:1px solid var(--br)">
        <!-- Barras -->
        <div style="flex:1;padding:16px;min-width:0;border-right:1px solid var(--br)">
          <div style="font-size:11px;font-weight:700;color:var(--mu);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Envíos por zona</div>
          <div style="position:relative;height:280px"><canvas id="c-flex-bar"></canvas></div>
        </div>
        <!-- Mapa de calor geográfico -->
        <div style="flex:1;padding:16px;min-width:0">
          <div style="font-size:11px;font-weight:700;color:var(--mu);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">Mapa de calor — Densidad Flex por zona</div>
          <div id="flex-map" style="height:280px;border-radius:10px;overflow:hidden;border:1px solid var(--br)"></div>
          <div style="margin-top:8px;display:flex;align-items:center;gap:6px">
            <span style="font-size:10px;color:var(--mu)">Pocos</span>
            <div style="flex:1;height:6px;border-radius:3px;background:linear-gradient(to right,#00f,#0ff,#0f0,#ff0,#f00)"></div>
            <span style="font-size:10px;color:var(--mu)">Muchos envíos</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Viz custom -->
    <div class="g2" style="margin-bottom:12px">
      <div class="card">
        <div class="ch">
          <div class="ct">Top publicaciones / productos</div>
          <div style="display:flex;gap:6px;align-items:center">
            <button id="btn-sort-ing" onclick="setPubSort('ingresos')" style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid var(--acc);background:var(--acc);color:#fff;cursor:pointer;font-weight:600">$ Facturación</button>
            <button id="btn-sort-uds" onclick="setPubSort('unidades')" style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid var(--br);background:#fff;color:var(--mu);cursor:pointer">📦 Unidades</button>
          </div>
        </div>
        <div class="tw"><table>
          <thead><tr><th>Producto</th><th class="nr" id="th-ing">Ingresos ▼</th><th class="nr" id="th-uds">Uds</th><th>Share</th></tr></thead>
          <tbody id="tb-p"></tbody>
        </table></div>
      </div>
      <div class="card" id="viz-custom-card" style="transition:box-shadow .3s">
        <div class="ch" style="flex-wrap:wrap;gap:6px">
          <div style="flex:1;min-width:0">
            <div class="ct" id="viz-custom-title">Visualización personalizada</div>
            <div class="cs" id="viz-custom-sub" style="margin-top:2px">Configurá en el panel izquierdo</div>
          </div>
          <div style="display:flex;gap:4px;align-items:center;flex-shrink:0">
            <button onclick="applyViz()" title="Refrescar gráfico" style="font-size:11px;padding:3px 10px;border-radius:6px;border:1px solid var(--acc);background:var(--acc);color:#fff;cursor:pointer;font-weight:600">▶ Graficar</button>
            <button onclick="clearViz()" title="Limpiar" style="font-size:11px;padding:3px 8px;border-radius:6px;border:1px solid var(--br);background:#fff;color:var(--mu);cursor:pointer">✕</button>
          </div>
        </div>
        <div class="cb"><div class="cw" style="position:relative"><canvas id="c-viz"></canvas></div></div>
      </div>
    </div>

        <!-- Tabla -->
    <div class="card">
      <div class="ch"><div class="ct">Detalle completo</div><div class="cs" id="ts"></div></div>
      <div class="tw" id="tw-main"></div>
      <div class="pg">
        <span id="pi"></span>
        <div class="pgb">
          <button class="pb2" id="pp" onclick="cp(-1)">‹ Anterior</button>
          <button class="pb2" id="pn" onclick="cp(1)">Siguiente ›</button>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<!-- Modal configurador de columnas -->
<div class="modal-bg" id="modal-cfg">
<div class="modal">
  <div class="modal-head">
    <span class="modal-title" id="modal-cfg-title">Configurar columnas</span>
    <button class="btn btn-ghost" style="padding:4px 10px;font-size:12px" onclick="closeModal()">✕</button>
  </div>
  <div class="modal-body">
    <div class="info-tip">
      Asigná el <strong>rol</strong> de cada columna para que Dashify sepa qué representa cada dato.
      Los campos con ★ son los más importantes para las visualizaciones.
    </div>
    <div class="role-grid" id="role-grid"></div>
    <div style="margin-top:16px">
      <div style="font-size:12px;font-weight:600;margin-bottom:8px;color:var(--mu)">Vista previa de los primeros datos:</div>
      <div style="overflow-x:auto"><table class="preview-table" id="preview-tbl"></table></div>
    </div>
  </div>
  <div class="modal-foot">
    <button class="btn btn-ghost" onclick="closeModal()">Cancelar</button>
    <button class="btn btn-primary" onclick="applyConfig()">Aplicar configuración</button>
  </div>
</div>
</div>

<script>
Chart.register(ChartDataLabels)

const S = { sids:[], periodo:"dia", page:0, charts:{}, _tot:0, catCols:[], numCols:[], platform:"__all__", _flexMap:null }
const DS = {}  // { sid: { name, source, rows, cols, colInfo, config } }
let cfgSid = null  // sid del dataset que se está configurando

const $ = id => document.getElementById(id)
function sL(m="Procesando..."){$("lm").textContent=m;$("ld").classList.add("show")}
function hL(){$("ld").classList.remove("show")}
function sE(m){$("et").textContent=m;$("eb").classList.add("show")}
function hE(){$("eb").classList.remove("show")}

function fmt(n,p=0){
  if(n==null||isNaN(n))return"—"
  return"$ "+Math.round(n).toLocaleString("es-AR")
}
function fN(n){
  if(n==null||isNaN(n))return"—"
  return Number.isInteger(n)?n.toLocaleString("es-AR"):n.toFixed(1)
}
function etag(e){
  if(!e||e==="null")return""
  const s=e.toLowerCase()
  if(s.includes("entregado")||s.includes("pagado")||s.includes("paid")||s.includes("completad")||s.includes("aprobado"))
    return`<span class="tag tOK">${e}</span>`
  if(s.includes("camino")||s.includes("enviad")||s.includes("pendiente")||s.includes("procesando"))
    return`<span class="tag tC">${e}</span>`
  if(s.includes("cancelad")||s.includes("reembols"))
    return`<span class="tag tX">${e}</span>`
  return`<span class="tag tD">${e}</span>`
}
function srcTag(f){
  if(!f)return""
  const sl=f.toLowerCase()
  const c=sl.includes("mercado")?"ml":sl.includes("tienda")?"tn":"cx"
  return`<span class="src-bd ${c}" style="border-radius:4px">${f.slice(0,12)}</span>`
}
function dc(id){if(S.charts[id]){S.charts[id].destroy();delete S.charts[id]}}

const COLORS=["#2563eb","#7c3aed","#16a34a","#f59e0b","#dc2626","#0d9488","#db2777","#0369a1","#65a30d","#9333ea","#e11d48","#0891b2"]
const SRC_COLORS={"Mercado Libre":"#f59e0b","Tienda Nube":"#7c3aed"}

function srcColor(name){
  if(!name)return COLORS[0]
  return SRC_COLORS[name] || COLORS[Object.keys(SRC_COLORS).length + Object.keys(DS).findIndex(k=>DS[k].name===name)]
}

// ── Upload ─────────────────────────────────────────────────────────────────
function trig(src){
  const el=$("fi-"+src)
  el.value=""  // reset para permitir subir el mismo archivo dos veces
  el.click()
}
async function onFI(e,src){const f=[...e.target.files];e.target.value="";for(const x of f)await up(x,src)}
function dov(e,s){e.preventDefault();$("dz-"+s).classList.add("dg")}
function dlv(s){$("dz-"+s).classList.remove("dg")}
async function drp(e,s){
  e.preventDefault();$("dz-"+s).classList.remove("dg")
  const ok={ml:/\.(xlsx|xls)$/i,tn:/\.(xlsx|xls|csv)$/i,cx:/\.(xlsx|xls|csv|ods)$/i}
  const f=[...e.dataTransfer.files].filter(x=>ok[s].test(x.name))
  if(!f.length){sE("Formato no compatible para este canal");return}
  for(const x of f)await up(x,s)
}

async function up(file,src){
  sL("Leyendo archivo...")
  console.log("[Dashify] Subiendo:", file.name, "src:", src, "size:", file.size)
  try{
    const fd=new FormData();fd.append("file",file)
    const r=await fetch("/api/upload/"+src,{method:"POST",body:fd})
    console.log("[Dashify] HTTP status:", r.status)
    const d=await r.json()
    console.log("[Dashify] Respuesta:", d)
    if(!d.ok)throw new Error(d.error)

    // Para ML: actualizar el DS existente si el sid ya estaba registrado (upsert)
    const isNew = !S.sids.includes(d.sid)
    DS[d.sid]={name: src==="ml" ? "Mercado Libre (acumulado)" : d.filename,
               source:src, rows:d.total_rows,
               cols:d.cols, colInfo:d.col_info, config:d.config,
               upsert: d.upsert||null}
    if(isNew) S.sids.push(d.sid)
    // No actualizamos selectores de columna aquí; lo hace rf() con el combinado
    renderSideFiles()
    popF(d.filtros, true)
    $("wlc").style.display="none"
    $("dash").style.display="block"
    S.page=0

    // Mostrar resumen del upsert para ML
    if(src==="ml" && d.upsert){
      const u=d.upsert
      const msg = u.updated>0
        ? `✓ ML: +${u.added} nuevas, ${u.updated} actualizadas · Total acumulado: ${u.total} ventas`
        : `✓ ML: +${u.added} ventas nuevas cargadas · Total acumulado: ${u.total}`
      showToast(msg)
    }

    // Si es archivo custom, abrir modal de configuración
    if(src==="cx"){
      openCfgModal(d.sid, d.filename, d.cols, d.col_info, d.config)
      return
    }
    await rf()
  }catch(e){
    console.error("[Dashify] Error:", e)
    sE(e.message || "Error desconocido al cargar el archivo")
  }
  finally{hL()}
}

function showToast(msg, ms=4000){
  let t=document.getElementById("toast-notif")
  if(!t){
    t=document.createElement("div")
    t.id="toast-notif"
    t.style.cssText="position:fixed;bottom:20px;right:20px;background:#1e293b;color:#fff;"+
      "padding:10px 16px;border-radius:8px;font-size:12px;font-weight:500;z-index:999;"+
      "box-shadow:0 4px 12px rgba(0,0,0,.3);border-left:3px solid #16a34a;max-width:360px;"+
      "transition:opacity .3s"
    document.body.appendChild(t)
  }
  t.textContent=msg
  t.style.opacity="1"
  clearTimeout(t._tm)
  t._tm=setTimeout(()=>t.style.opacity="0", ms)
}

// ── Sidebar archivos ────────────────────────────────────────────────────────
function renderSideFiles(){
  ["ml","tn","cx"].forEach(src=>{
    const el=$("files-"+src)
    const mine=S.sids.filter(sid=>DS[sid]?.source===src)
    if(!mine.length){
      el.innerHTML=`<div style="padding:5px 10px 5px 18px;font-size:11px;color:rgba(255,255,255,.2)">Sin archivos</div>`
      return
    }
    if(src==="ml"){
      // ML: un único bloque acumulado con lista de archivos cargados
      const sid=mine[0]
      const ds=DS[sid]
      const u=ds.upsert
      const fileList=(u&&u.files?u.files:[ds.name])
      el.innerHTML=`
        <div style="padding:5px 10px 5px 14px">
          ${fileList.map(fn=>`
            <div class="src-file" style="padding:3px 0">
              <span class="src-fn" title="${fn}" style="font-size:10px">📄 ${fn}</span>
            </div>`).join("")}
          <div style="margin-top:4px;font-size:10px;color:rgba(255,255,255,.38);padding-left:4px">
            Total acumulado: ${ds.rows} ventas
          </div>
        </div>
        <div style="padding:0 10px 6px 14px">
          <button class="sdl" style="font-size:11px;color:rgba(255,60,60,.5)" onclick="delSrc('${sid}')">✕ Limpiar ML</button>
        </div>`
    } else {
      el.innerHTML=mine.map(sid=>`
        <div class="src-file">
          <span class="src-fn" title="${DS[sid].name}">${DS[sid].name}</span>
          <span class="src-fr">${DS[sid].rows}f</span>
          ${src==="cx"?`<button class="cfg-btn" onclick="openCfgModal('${sid}','${DS[sid].name}',null,null,null,true)">⚙</button>`:""}
          <button class="sdl" onclick="delSrc('${sid}')">x</button>
        </div>`).join("")
    }
  })
}

async function delSrc(sid){
  await fetch("/api/delete/"+sid,{method:"DELETE"})
  S.sids=S.sids.filter(s=>s!==sid)
  delete DS[sid]
  renderSideFiles()
  if(!S.sids.length){$("wlc").style.display="flex";$("dash").style.display="none"}
  else await rf()
}

// ── Modal configurador de columnas ─────────────────────────────────────────
const ROLES = [
  {id:"date",     label:"★ Fecha",          desc:"Columna de fecha/hora de la venta",      color:"#2563eb"},
  {id:"amount",   label:"★ Monto / Ingresos",desc:"Valor principal (ventas, facturación)", color:"#16a34a"},
  {id:"qty",      label:"Cantidad / Unidades",desc:"Número de unidades vendidas",           color:"#0d9488"},
  {id:"status",   label:"★ Estado",          desc:"Estado de la venta o pago",             color:"#d97706"},
  {id:"product",  label:"★ Producto",        desc:"Nombre del producto o publicación",     color:"#7c3aed"},
  {id:"category", label:"Categoría",         desc:"Tipo, categoría o envío (para filtrar)",color:"#0891b2"},
  {id:"geo",      label:"Región / Provincia", desc:"Ubicación geográfica del comprador",   color:"#dc2626"},
  {id:"customer", label:"Cliente",           desc:"Nombre o ID del comprador",             color:"#9333ea"},
  {id:"id",       label:"ID / N° de orden",  desc:"Identificador único de la venta",       color:"#64748b"},
  {id:"cost",     label:"Costo / Descuento", desc:"Costo de envío, descuento u otro costo",color:"#e11d48"},
  {id:"amount2",  label:"Valor secundario",  desc:"Segunda métrica numérica",              color:"#65a30d"},
  {id:"category2",label:"Categoría 2",       desc:"Segunda categoría para agrupar",        color:"#f59e0b"},
]

function openCfgModal(sid, filename, cols, colInfo, config, reopen=false){
  cfgSid = sid
  const ds = DS[sid]
  if(reopen){
    cols = ds.cols
    colInfo = ds.colInfo
    config = ds.config
  }
  $("modal-cfg-title").textContent = "Configurar columnas: " + filename

  const allCols = cols || []
  const currentConfig = config || {}

  // Invertir config para ver qué columna tiene cada rol
  const roleToCol = {}
  for(const [role,col] of Object.entries(currentConfig)) roleToCol[role]=col

  // Construir grid de roles
  const colOptions = `<option value="">— sin asignar —</option>` +
    allCols.map(c=>`<option value="${c}">${c}</option>`).join("")

  $("role-grid").innerHTML = ROLES.map(r=>{
    const current = roleToCol[r.id] || ""
    const auto = colInfo && Object.entries(colInfo).find(([c,i])=>i.role===r.id)?.[0]
    const hint = auto && !current ? ` (sugerido: ${auto})` : ""
    return `<div class="role-item">
      <div class="role-lbl">
        <div class="role-dot" style="background:${r.color}"></div>
        ${r.label}
      </div>
      <div class="role-desc">${r.desc}${hint}</div>
      <select class="role-sel" data-role="${r.id}">
        ${colOptions}
      </select>
    </div>`
  }).join("")

  // Setear valores actuales
  document.querySelectorAll(".role-sel").forEach(sel=>{
    const role = sel.dataset.role
    const val = roleToCol[role] || ""
    sel.value = val
  })

  // Preview table
  const info = colInfo || {}
  const sample = allCols.map(c=>({col:c, type:info[c]?.type||"?", role:info[c]?.role||"", sample:info[c]?.sample||[]}))
  $("preview-tbl").innerHTML = `
    <thead><tr><th>Columna</th><th>Tipo detectado</th><th>Rol sugerido</th><th>Muestra</th></tr></thead>
    <tbody>${sample.slice(0,12).map(s=>`<tr>
      <td style="font-weight:500">${s.col}</td>
      <td><span class="tag" style="background:${s.type==="number"?"#dbeafe":s.type==="date"?"#dcfce7":"#f1f5f9"};color:${s.type==="number"?"#1d4ed8":s.type==="date"?"#15803d":"#475569"}">${s.type}</span></td>
      <td style="color:var(--mu)">${s.role||"—"}</td>
      <td style="color:var(--mu);font-size:10px">${s.sample.slice(0,2).join(", ")}</td>
    </tr>`).join("")}</tbody>`

  $("modal-cfg").classList.add("open")
}

function closeModal(){$("modal-cfg").classList.remove("open")}

async function applyConfig(){
  if(!cfgSid)return
  const newConfig = {}
  document.querySelectorAll(".role-sel").forEach(sel=>{
    if(sel.value) newConfig[sel.dataset.role] = sel.value
  })
  sL("Aplicando configuración...")
  closeModal()
  try{
    const r=await fetch("/api/config/"+cfgSid,{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify(newConfig)
    })
    const d=await r.json()
    if(!d.ok)throw new Error(d.error)
    DS[cfgSid].config=newConfig
    popF(d.filtros, true)
    await rf()
  }catch(e){sE(e.message)}
  finally{hL()}
}

// Cerrar modal al hacer clic fuera
$("modal-cfg").addEventListener("click", e=>{ if(e.target===$("modal-cfg"))closeModal() })

// ── Selectores de visualización ────────────────────────────────────────────
function updateColSelectors(cols, colInfo){
  if(!cols || !cols.length) return

  // Separar columnas por tipo usando colInfo del servidor
  const allCols = cols.filter(c => !c.startsWith("_"))
  S.numCols = allCols.filter(c => colInfo?.[c]?.type === "number")
  S.catCols = allCols.filter(c => colInfo?.[c]?.type !== "date")

  // Fallback heurístico si colInfo no llegó
  if(!colInfo || !Object.keys(colInfo).length){
    const numKeywords = ["ingreso","total","monto","precio","costo","cantidad","unidad","qty","amount","subtotal","descuento","impuesto","cargo","valor"]
    S.numCols = allCols.filter(c => numKeywords.some(k => c.toLowerCase().includes(k)))
    S.catCols = allCols
  }

  // Preservar selección actual del usuario
  const prevBy  = $("v-by")?.value  || ""
  const prevVal = $("v-val")?.value || ""

  const bySel  = $("v-by")
  const valSel = $("v-val")
  if(!bySel || !valSel) return

  bySel.innerHTML = `<option value="">-- elegí una columna --</option>` +
    S.catCols.map(c => `<option value="${c}"${c===prevBy?" selected":""}}>${c}</option>`).join("")

  // Columnas de valor: primero métricas conocidas, luego el resto numéricas
  const knownMetrics = ["ingresos","unidades","costo","total_neto","descuentos","precio_unit","subtotal","cargo_venta"]
  const orderedNum = [
    ...knownMetrics.filter(k => S.numCols.includes(k)),
    ...S.numCols.filter(k => !knownMetrics.includes(k))
  ]
  const valCols = orderedNum.length ? orderedNum : allCols
  valSel.innerHTML = `<option value="">-- elegí una métrica --</option>` +
    valCols.map(c => `<option value="${c}"${c===prevVal?" selected":""}}>${c}</option>`).join("")

  // Filtro custom col
  const ccol = $("f-ccol")
  if(ccol){
    ccol.innerHTML = `<option value="">Columna...</option>` +
      S.catCols.map(c => `<option value="${c}">${c}</option>`).join("")
    $("fg-custom").style.display = "block"
  }
}

async function loadCustomVals(){
  const col = $("f-ccol").value
  const sel = $("f-cval")
  sel.innerHTML = `<option value="__all__">Todos</option>`
  if(!col || !S.sids.length) return
}

// ── Filtros ────────────────────────────────────────────────────────────────
function popF(f, resetDates=false){
  function fill(id,vals,all="Todos"){
    const s=$(id),cv=s.value
    s.innerHTML=`<option value="__all__">${all}</option>`+vals.map(v=>`<option value="${v}">${v||"(vacío)"}</option>`).join("")
    if(vals.includes(cv))s.value=cv
  }
  // Canal/fuente
  const fuenteSel=$("ff")
  const fuenteVals=(f.fuente||[])
  fuenteSel.innerHTML=`<option value="__all__">Todos los canales</option>`+
    fuenteVals.map(v=>`<option value="${v}">${v}</option>`).join("")

  fill("fe",f.estado||[])
  fill("fcat",f.categoria||[])
  fill("fprov",f.provincia||[])

  // Filtro de mes — siempre actualizar con los meses disponibles
  const meses = f.meses || []
  const fmes = $("fmes"), cvMes = fmes ? fmes.value : "__all__"
  if(fmes){
    fmes.innerHTML = `<option value="__all__">Todos los meses</option>` +
      meses.map(m => {
        const [y,mo] = m.split("-")
        const label = mo && y ? new Date(+y,+mo-1,1).toLocaleDateString("es-AR",{month:"long",year:"numeric"}) : m
        return `<option value="${m}">${label}</option>`
      }).join("")
    if(meses.includes(cvMes)) fmes.value = cvMes
  }

  // Fechas: solo actualizar valores cuando se carga un archivo (resetDates=true)
  // En refreshes de dashboard (rf), NUNCA tocar los valores que el usuario eligió
  if(f.fecha_min){
    const fdEl=$("fd"), fhEl=$("fh")
    // Siempre actualizar los atributos min/max para que el date-picker tenga el rango correcto
    fdEl.min = f.fecha_min; fdEl.max = f.fecha_max
    fhEl.min = f.fecha_min; fhEl.max = f.fecha_max
    if(resetDates){
      const curDesde = fdEl.value, curHasta = fhEl.value
      if(!curDesde || curDesde > f.fecha_max || curHasta < f.fecha_min){
        // Primera carga o rango completamente fuera → resetear al rango completo
        fdEl.value = f.fecha_min; fhEl.value = f.fecha_max
      } else {
        // Solo expandir si el nuevo archivo tiene datos más allá del rango actual
        if(f.fecha_min < curDesde) fdEl.value = f.fecha_min
        if(f.fecha_max > curHasta) fhEl.value = f.fecha_max
      }
    }
  }
}

// Cuando cambia una fecha manualmente, limpiar el filtro de mes
function onDateChange(){ const fm=$("fmes"); if(fm) fm.value="__all__"; rf() }
// Cuando cambia el mes, setear el rango de fechas del mes seleccionado
function onMesChange(){
  const mes = $("fmes").value
  if(mes && mes !== "__all__"){
    const [y,m] = mes.split("-").map(Number)
    const desde = new Date(y,m-1,1)
    const hasta = new Date(y,m,0)  // último día del mes
    const fmt = d => d.toISOString().split("T")[0]
    $("fd").value = fmt(desde)
    $("fh").value = fmt(hasta)
  } else {
    $("fd").value = $("fd").min || ""
    $("fh").value = $("fh").max || ""
  }
  rf()
}

function gF(){
  const ccol=$("f-ccol").value, cval=$("f-cval").value
  // Platform tab tiene prioridad sobre el select de fuente
  const fuente = S.platform !== "__all__" ? S.platform : $("ff").value
  return{
    fuente:      fuente,
    estado:      $("fe").value,
    categoria:   $("fcat").value,
    provincia:   $("fprov").value,
    mes:         ($("fmes") ? $("fmes").value : "__all__"),
    fecha_desde: $("fd").value,
    fecha_hasta: $("fh").value,
    texto:       $("fq").value.trim(),
    custom_col:  ccol||null,
    custom_val:  (cval&&cval!=="__all__")?cval:null,
  }
}
function gViz(){
  return {
    by_col:    $("v-by").value,
    val_col:   $("v-val").value,
    agg_fn:    $("v-agg").value,
    chart_type:$("v-type").value || "bar",
    top_n:     parseInt($("v-topn")?.value || "15")
  }
}

function setVizFn(fn, btn){
  $("v-agg").value = fn
  ;["vfn-sum","vfn-count","vfn-avg","vfn-max"].forEach(id=>{ const el=$(id); if(el) el.classList.remove("act") })
  btn.classList.add("act")
}

function setVizType(type, btn){
  $("v-type").value = type
  ;["vt-bar","vt-horizontalBar","vt-line","vt-area","vt-doughnut","vt-pie"].forEach(id=>{ const el=$(id); if(el) el.classList.remove("act") })
  btn.classList.add("act")
}

function vizAutoVal(){
  const by = $("v-by").value
  const valSel = $("v-val")
  if(!by || !valSel.options.length) return
  const byL = by.toLowerCase()

  function trySelect(preferred){
    for(let i=0;i<valSel.options.length;i++){
      if(preferred.some(p => valSel.options[i].value===p || valSel.options[i].value.toLowerCase().includes(p))){
        valSel.selectedIndex=i; return
      }
    }
    if(valSel.options.length>1) valSel.selectedIndex=1
  }

  if(byL.includes("fecha") || byL.includes("_mes") || byL.includes("_sem") || byL.includes("_anio")){
    setVizType("line",  $("vt-line"))
    trySelect(["ingresos","total","monto","amount"])
  } else if(byL.includes("pub") || byL.includes("prod") || byL.includes("sku") || byL.includes("titulo") || byL.includes("articulo")){
    setVizType("horizontalBar", $("vt-horizontalBar"))
    trySelect(["ingresos","total","monto","amount"])
  } else if(byL.includes("estado") || byL.includes("pago") || byL.includes("envio") || byL.includes("forma")){
    setVizType("doughnut", $("vt-doughnut"))
    trySelect(["unidades","cantidad","qty"])
  } else if(byL.includes("provincia") || byL.includes("ciudad") || byL.includes("region") || byL.includes("zona")){
    setVizType("horizontalBar", $("vt-horizontalBar"))
    trySelect(["ingresos","total","monto"])
  } else if(byL.includes("categ") || byL.includes("tipo") || byL.includes("canal")){
    setVizType("pie", $("vt-pie"))
    trySelect(["ingresos","total"])
  } else {
    setVizType("bar", $("vt-bar"))
    if(valSel.options.length>1) valSel.selectedIndex=1
  }
}
function clrF(){
  ["ff","fe","fcat","fprov"].forEach(id=>{const s=$(id);if(s)s.value="__all__"})
  const fm=$("fmes"); if(fm) fm.value="__all__"
  $("fd").value=$("fd").min||""; $("fh").value=$("fh").max||""; $("fq").value=""
  $("f-ccol").value="";$("f-cval").innerHTML=`<option value="__all__">Todos</option>`
  S.page=0;rf()
}

function setPlatform(plat, btn){
  S.platform = plat
  S.page = 0
  // Actualizar estilos de botones
  document.querySelectorAll(".ptf-btn").forEach(b=>b.classList.remove("act"))
  btn.classList.add("act")
  // Sincronizar con el select de fuente del sidebar
  const ff=$("ff")
  if(ff) ff.value = plat
  // Actualizar título del dashboard
  const titles={"__all__":"Resumen de ventas","Mercado Libre":"Mercado Libre","Tienda Nube":"Tienda Nube"}
  $("dash-title").textContent = titles[plat] || plat
  rf()
}

function updatePlatformTabs(fuentes, mpf){
  // Mostrar/ocultar tabs según fuentes disponibles
  const ml=$("ptf-ml"), tn=$("ptf-tn")
  const hasMl = fuentes.includes("Mercado Libre")
  const hasTn = fuentes.includes("Tienda Nube")
  if(ml) ml.style.display = hasMl ? "" : "none"
  if(tn) tn.style.display = hasTn ? "" : "none"

  // Actualizar contadores
  const total = Object.values(mpf).reduce((a,v)=>a+v.n_ventas,0)
  const cntAll=$("ptf-cnt-all")
  if(cntAll) cntAll.textContent = total+" ventas"

  if(hasMl && mpf["Mercado Libre"]){
    const c=$("ptf-cnt-ml")
    if(c) c.textContent = mpf["Mercado Libre"].n_ventas+" ventas"
  }
  if(hasTn && mpf["Tienda Nube"]){
    const c=$("ptf-cnt-tn")
    if(c) c.textContent = mpf["Tienda Nube"].n_ventas+" ventas"
  }

  // Si la plataforma activa ya no tiene datos, volver a "todas"
  if(S.platform !== "__all__" && !fuentes.includes(S.platform)){
    S.platform = "__all__"
    document.querySelectorAll(".ptf-btn").forEach(b=>b.classList.remove("act"))
    const allBtn=document.querySelector(".ptf-btn.all")
    if(allBtn) allBtn.classList.add("act")
  }
}
function sp(p,btn){
  S.periodo=p
  document.querySelectorAll(".ptab").forEach(b=>b.classList.remove("act"))
  btn.classList.add("act");rf()
}
function cp(d){
  const ps=Math.max(1,Math.ceil(S._tot/50))
  S.page=Math.max(0,Math.min(ps-1,S.page+d));rf()
}

// ── Refresh ────────────────────────────────────────────────────────────────
async function rf(){
  if(!S.sids.length)return
  sL("Actualizando...")
  try{
    const r=await fetch("/api/dashboard",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({sids:S.sids,filtros:gF(),periodo:S.periodo,page:S.page,viz:S._vizActive?gViz():{}})
    })
    const d=await r.json()
    if(!d.ok)throw new Error(d.error)
    popF(d.filtros_disponibles)
    if(d.col_names){updateColSelectors(d.col_names, d.col_info||null)}
    rd(d)
  }catch(e){sE(e.message)}
  finally{hL()}
}

// ── Top productos sort ────────────────────────────────────────────────────
S._pubSort = "ingresos"  // "ingresos" | "unidades"

function setPubSort(key){
  S._pubSort = key
  // Actualizar estilos de botones
  const acc = "background:var(--acc);color:#fff;border-color:var(--acc)"
  const off = "background:#fff;color:var(--mu);border-color:var(--br)"
  $("btn-sort-ing").style.cssText = $("btn-sort-ing").style.cssText.replace(/background:[^;]+;color:[^;]+;border-color:[^;]+/,"") + (key==="ingresos"?acc:off)
  $("btn-sort-uds").style.cssText = $("btn-sort-uds").style.cssText.replace(/background:[^;]+;color:[^;]+;border-color:[^;]+/,"") + (key==="unidades"?acc:off)
  // Actualizar encabezados de columna
  const thI = $("th-ing"), thU = $("th-uds")
  if(thI) thI.textContent = key==="ingresos" ? "Ingresos ▼" : "Ingresos"
  if(thU) thU.textContent = key==="unidades" ? "Uds ▼" : "Uds"
  renderPubTable()
}

function renderPubTable(){
  const data = (S._pubData||[]).slice()
  const key = S._pubSort || "ingresos"
  data.sort((a,b)=>(b[key]||0)-(a[key]||0))
  // Recalcular pct relativo al sort key
  const tot = data.reduce((s,r)=>s+(r[key]||0),0)
  $("tb-p").innerHTML = data.map((r,i)=>{
    const pct = tot ? ((r[key]||0)/tot*100).toFixed(1) : 0
    return `<tr>
      <td><div style="display:flex;align-items:center;gap:5px">
        <span style="width:10px;height:10px;border-radius:50%;background:${COLORS[i%COLORS.length]};flex-shrink:0;display:inline-block"></span>
        <span title="${r.label||""}">${(r.label||"—").slice(0,38)}</span>
      </div></td>
      <td class="nr">${fmt(r.ingresos)}</td>
      <td class="nr">${fN(r.unidades||0)}</td>
      <td><div class="pb"><div class="pt"><div class="pf" style="width:${pct}%;background:${COLORS[i%COLORS.length]}"></div></div>
      <span style="font-size:10px;color:var(--mu);min-width:28px;text-align:right">${pct}%</span></div></td>
    </tr>`
  }).join("")
}

// ── Render ─────────────────────────────────────────────────────────────────
function getPeriodoLabel(){
  const mes = $("fmes") ? $("fmes").value : "__all__"
  const desde = $("fd") ? $("fd").value : ""
  const hasta = $("fh") ? $("fh").value : ""
  if(mes && mes !== "__all__"){
    const [y,m] = mes.split("-").map(Number)
    return new Date(y,m-1,1).toLocaleDateString("es-AR",{month:"long",year:"numeric"})
  }
  if(desde && hasta){
    const fmtD = v => { const [y,m,d] = v.split("-"); return `${d}/${m}/${y}` }
    if(desde === hasta) return fmtD(desde)
    return `${fmtD(desde)} al ${fmtD(hasta)}`
  }
  return "Todos los períodos"
}

function rd(d){
  const m=d.metricas
  S._tot=d.tabla?.total||0
  $("nb").textContent=`${m.n_ventas} venta${m.n_ventas!==1?"s":""} · ${d.n_filtradas} filtradas`

  // Mostrar período seleccionado bajo el título
  const dmEl=$("dm")
  if(dmEl) dmEl.textContent = getPeriodoLabel()

  // Actualizar tabs de plataforma
  const fuentes=Object.keys(d.metricas_por_fuente||{})
  updatePlatformTabs(fuentes, d.metricas_por_fuente||{})

  // KPIs
  $("kpis").innerHTML=`
    <div class="kpi bl"><div class="kl">INGRESOS</div><div class="kv">${fmt(m.ingresos)}</div><div class="ks">Neto: ${fmt(m.total_neto)}</div></div>
    <div class="kpi gr"><div class="kl">UNIDADES</div><div class="kv">${fN(m.unidades)}</div><div class="ks">${m.n_ventas} órdenes</div></div>
    <div class="kpi or"><div class="kl">TICKET PROM.</div><div class="kv">${fmt(m.ticket_prom)}</div><div class="ks">por orden</div></div>
    <div class="kpi rd"><div class="kl">COSTOS</div><div class="kv">${fmt(m.costo)}</div><div class="ks">envío + cargos</div></div>
    <div class="kpi pu"><div class="kl">DESCUENTOS</div><div class="kv">${fmt(m.descuentos)}</div><div class="ks">aplicados</div></div>
    <div class="kpi tl"><div class="kl">% COBRADO/OK</div><div class="kv">${m.tasa_ok}%</div><div class="ks">del total</div></div>`

  // Comparativa por fuente
  const mpf=d.metricas_por_fuente||{}
  const fuenteKeys=Object.keys(mpf)
  const cmpBar=$("cmp-bar")
  if(fuenteKeys.length>1){
    cmpBar.style.display="flex"
    const cls={Mercado_Libre:"ml","Mercado Libre":"ml","Tienda Nube":"tn","Tienda_Nube":"tn"}
    cmpBar.innerHTML=fuenteKeys.map(f=>{
      const mf=mpf[f]
      const c=cls[f]||cls[f.replace(" ","_")]||"gen"
      return`<div class="cmp-card ${c}">
        <div class="cmp-lbl ${c}">${f.toUpperCase()}</div>
        <div class="cmp-row"><span class="cmp-k">Ingresos</span><span class="cmp-v">${fmt(mf.ingresos)}</span></div>
        <div class="cmp-row"><span class="cmp-k">Unidades</span><span class="cmp-v">${fN(mf.unidades)}</span></div>
        <div class="cmp-row"><span class="cmp-k">Ticket</span><span class="cmp-v">${fmt(mf.ticket_prom)}</span></div>
        <div class="cmp-row"><span class="cmp-k">Órdenes</span><span class="cmp-v">${mf.n_ventas}</span></div>
        <div class="cmp-row"><span class="cmp-k">% OK</span><span class="cmp-v">${mf.tasa_ok}%</span></div>
      </div>`
    }).join("")
  } else {
    cmpBar.style.display="none"
  }

  // Gráfico de tiempo: una línea por fuente
  rT(d.por_tiempo_fuentes||{})

  // Donut por fuente
  rD("c-fu", d.por_fuente, "label", fuenteKeys.map(f=>SRC_COLORS[f]||COLORS[Object.keys(SRC_COLORS).length]))

  rD("c-es", d.por_estado, "label", ["#16a34a","#d97706","#2563eb","#dc2626","#db2777","#7c3aed"])

  // Categoría
  if(d.por_categoria?.length){
    rD("c-cat", d.por_categoria, "label", COLORS)
  } else {
    rD("c-cat", d.por_envio, "label", ["#2563eb","#16a34a","#d97706","#7c3aed","#dc2626"])
  }

  // Top provincias
  S._provData = d.por_provincia || []
  renderProvChart()

  // Flex por zona
  S._flexData = d.flex_zonas || null
  renderFlexChart()

  // Top publicaciones
  S._pubData = d.por_publicacion || []
  renderPubTable()

  // Viz custom
  const vb = $("v-by")?.value, vv = $("v-val")?.value, va = $("v-agg")?.value || "sum"
  const vt = $("v-type")?.value || "bar"
  if(S._vizActive && d.viz_custom?.length && vb && vv){
    hideVizEmpty()
    const aggLabels = {"sum":"Suma de","count":"Conteo de","avg":"Promedio de","max":"Máximo de","min":"Mínimo de"}
    const typeLabels = {"bar":"Barras","horizontalBar":"Barras horiz.","line":"Línea","area":"Área","doughnut":"Rosca","pie":"Torta"}
    $("viz-custom-title").textContent = `${aggLabels[va]||""} ${vv}`
    $("viz-custom-sub").textContent   = `agrupado por ${vb}  ·  ${typeLabels[vt]||""}  ·  ${d.viz_custom.length} grupos`
    rCustom("c-viz", d.viz_custom, vt)
  } else if(S._vizActive && vb && vv && !d.viz_custom?.length){
    dc("c-viz")
    $("viz-custom-title").textContent = "Sin datos para esta combinación"
    $("viz-custom-sub").textContent   = "Probá con otro filtro o columna"
    renderVizEmpty()
  } else {
    dc("c-viz")
    $("viz-custom-title").textContent = "Visualización personalizada"
    $("viz-custom-sub").textContent   = "Configurá en el panel izquierdo"
    renderVizEmpty()
  }

  rTab(d.tabla)

  // Si no hay viz activa, mostrar estado vacío
  if(!S._vizActive) setTimeout(renderVizEmpty, 100)
}

function rT(timeBySource){
  dc("c-t")
  const allPeriods=[...new Set(Object.values(timeBySource).flat().map(r=>r.periodo))].filter(Boolean).sort()
  if(!allPeriods.length)return
  const datasets=Object.entries(timeBySource).map(([fname,rows],i)=>{
    const color=SRC_COLORS[fname]||COLORS[i]
    const getV=k=>rows.find(r=>r.periodo===k)?.ingresos||0
    return{label:fname,data:allPeriods.map(k=>getV(k)),
      borderColor:color,backgroundColor:color+"18",fill:true,tension:0.4,pointRadius:3,borderWidth:2}
  })
  if(!datasets.length)return
  S.charts["c-t"]=new Chart($("c-t"),{
    type:"line",
    data:{labels:allPeriods,datasets},
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{labels:{font:{size:11},boxWidth:10}},datalabels:{display:false}},
      scales:{
        x:{ticks:{font:{size:10},maxRotation:30},grid:{display:false}},
        y:{ticks:{font:{size:10},callback:v=>fN(v)},grid:{color:"rgba(0,0,0,.04)"}}
      }
    }
  })
}

function rD(cid,rows,lk,cols){
  dc(cid)
  if(!rows?.length)return
  S.charts[cid]=new Chart($(cid),{
    type:"doughnut",
    data:{labels:rows.map(r=>r[lk]||"(vacío)"),
      datasets:[{data:rows.map(r=>r.ingresos||0),backgroundColor:cols||COLORS,borderColor:"#fff",borderWidth:2,hoverOffset:5}]},
    options:{responsive:true,maintainAspectRatio:false,cutout:"60%",
      plugins:{
        legend:{position:"right",labels:{font:{size:10},boxWidth:10,padding:7,
          generateLabels(ch){
            const ds=ch.data,tot=ds.datasets[0].data.reduce((a,b)=>a+b,0)
            return ds.labels.map((l,i)=>({
              text:`${l.length>16?l.slice(0,16)+"…":l} ${tot?((ds.datasets[0].data[i]/tot)*100).toFixed(1)+"%":""}`,
              fillStyle:ds.datasets[0].backgroundColor[i],fontColor:"#475569",hidden:false,index:i
            }))
          }
        }},
        datalabels:{display:false}
      }
    }
  })
}

// ── Envíos Flex por zona ──────────────────────────────────────────────────
S._flexData  = null
S._flexSort  = "cantidad"

function setFlexSort(key){
  S._flexSort = key
  const bC=$("btn-flex-cant"), bI=$("btn-flex-ing")
  if(bC){bC.style.background=key==="cantidad"?"var(--acc)":"#fff";bC.style.color=key==="cantidad"?"#fff":"var(--mu)";bC.style.borderColor=key==="cantidad"?"var(--acc)":"var(--br)"}
  if(bI){bI.style.background=key==="ingresos"?"var(--acc)":"#fff";bI.style.color=key==="ingresos"?"#fff":"var(--mu)";bI.style.borderColor=key==="ingresos"?"var(--acc)":"var(--br)"}
  renderFlexChart()
}

function renderFlexChart(){
  const fz = S._flexData
  if(!fz || !fz.zonas?.length){ $("flex-card").style.display="none"; return }
  $("flex-card").style.display = ""

  const key      = S._flexSort || "cantidad"
  const rows     = [...fz.zonas].sort((a,b)=>b[key]-a[key])
  const totFlex  = fz.total_flex  || 0
  const totEnv   = fz.total_envios || 1
  const pctFlex  = fz.pct_flex_total || 0
  const totIng   = rows.reduce((s,r)=>s+r.ingresos, 0)
  const maxVal   = rows[0]?.[key] || 1   // máximo real para escala del heatmap

  // ── Subtitle ───────────────────────────────────────────────────────────
  const sub = $("flex-subtitle")
  if(sub) sub.textContent = `${totFlex.toLocaleString("es-AR")} Flex · ${pctFlex}% del total de envíos`

  // ── KPIs ───────────────────────────────────────────────────────────────
  const kpiEl = $("flex-kpis")
  if(kpiEl){
    const pctColor = pctFlex>=30?"#16a34a":pctFlex>=10?"#d97706":"#64748b"
    kpiEl.innerHTML = `
      <div style="flex:1;padding:12px 16px;border-right:1px solid var(--br)">
        <div style="font-size:10px;color:var(--mu);font-weight:600;text-transform:uppercase;letter-spacing:.4px">Total Flex</div>
        <div style="font-size:24px;font-weight:800;color:#0d9488">${totFlex.toLocaleString("es-AR")}</div>
        <div style="font-size:11px;color:var(--mu)">envíos Flex</div>
      </div>
      <div style="flex:1;padding:12px 16px;border-right:1px solid var(--br)">
        <div style="font-size:10px;color:var(--mu);font-weight:600;text-transform:uppercase;letter-spacing:.4px">Incidencia</div>
        <div style="font-size:24px;font-weight:800;color:${pctColor}">${pctFlex}%</div>
        <div style="font-size:11px;color:var(--mu)">del total de envíos</div>
      </div>
      <div style="flex:1;padding:12px 16px;border-right:1px solid var(--br)">
        <div style="font-size:10px;color:var(--mu);font-weight:600;text-transform:uppercase;letter-spacing:.4px">Facturación Flex</div>
        <div style="font-size:24px;font-weight:800;color:#2563eb">$ ${Math.round(totIng).toLocaleString("es-AR")}</div>
        <div style="font-size:11px;color:var(--mu)">en ventas Flex</div>
      </div>
      <div style="flex:1;padding:12px 16px">
        <div style="font-size:10px;color:var(--mu);font-weight:600;text-transform:uppercase;letter-spacing:.4px">Zonas</div>
        <div style="font-size:24px;font-weight:800;color:#7c3aed">${rows.length}</div>
        <div style="font-size:11px;color:var(--mu)">zonas con Flex</div>
      </div>`
  }

  // ── Gráfico de barras (Chart.js) ───────────────────────────────────────
  dc("c-flex-bar")
  const barRows  = rows.slice(0,12)   // top 12 para que entre bien
  const barVals  = barRows.map(r => key==="cantidad" ? r.cantidad : Math.round(r.ingresos))
  const pctVals  = barRows.map(r => key==="cantidad" ? r.pct_cantidad : r.pct_ingresos)
  const barLabel = key==="cantidad" ? "Envíos" : "Facturación ($)"
  // Paleta de verde teal degradado según valor
  const barColors = barVals.map((v,i) => {
    const intensity = Math.round(40 + (v/maxVal)*215)  // 40-255
    return `rgba(13,148,136,${(0.35 + (v/maxVal)*0.65).toFixed(2)})`
  })
  const rev = [...barRows].reverse()
  const revVals = [...barVals].reverse()
  const revPct  = [...pctVals].reverse()
  const revColors = [...barColors].reverse()

  S.charts["c-flex-bar"] = new Chart($("c-flex-bar"), {
    type: "bar",
    data: {
      labels: rev.map(r => r.zona.length > 22 ? r.zona.slice(0,22)+"…" : r.zona),
      datasets: [{
        label: barLabel,
        data: revVals,
        backgroundColor: revColors,
        borderRadius: 4,
        borderSkipped: "left",
      }]
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: {
          display: true,
          anchor: "end",
          align: "end",
          font: { size: 10, weight: "700" },
          color: "#475569",
          formatter: (v, ctx) => {
            const pct = revPct[ctx.dataIndex]
            return key==="cantidad"
              ? `${v} (${pct}%)`
              : `${pct}%`
          }
        },
        tooltip: {
          callbacks: {
            label: ctx => {
              const r = rev[ctx.dataIndex]
              const v = revVals[ctx.dataIndex]
              const pct = revPct[ctx.dataIndex]
              if(key==="cantidad") return ` ${v} envíos · ${pct}% del total Flex`
              return ` $ ${v.toLocaleString("es-AR")} · ${pct}% del total`
            }
          }
        }
      },
      scales: {
        x: {
          ticks: { font:{size:9}, callback: v => key==="cantidad" ? v : "$ "+v.toLocaleString("es-AR") },
          grid: { display: false }
        },
        y: { ticks: { font:{size:10} }, grid: { display: false } }
      }
    }
  })

  // ── Mapa de calor Leaflet ──────────────────────────────────────────────
  const mapEl = $("flex-map")
  if(!mapEl) return

  // Filtrar solo zonas con coordenadas
  const zonasCon = fz.zonas.filter(r => r.lat && r.lng)

  if(zonasCon.length === 0){
    mapEl.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--mu);font-size:13px;background:#f8fafc;border-radius:10px">
      <div style="text-align:center">
        <div style="font-size:28px;margin-bottom:8px">📍</div>
        <div>Sin coordenadas para las zonas encontradas</div>
        <div style="font-size:11px;margin-top:4px">Cargá datos con columna Ciudad para ver el mapa</div>
      </div>
    </div>`
    return
  }

  // Destruir mapa previo si existe
  if(S._flexMap){ S._flexMap.remove(); S._flexMap = null }

  // Centro del mapa: promedio ponderado de coordenadas
  const totCant = zonasCon.reduce((s,r)=>s+r.cantidad,0)
  const centerLat = zonasCon.reduce((s,r)=>s+r.lat*r.cantidad,0)/totCant
  const centerLng = zonasCon.reduce((s,r)=>s+r.lng*r.cantidad,0)/totCant

  // Crear mapa Leaflet
  const map = L.map("flex-map", {zoomControl:true, scrollWheelZoom:true})
    .setView([centerLat, centerLng], 10)
  S._flexMap = map

  // Tiles OpenStreetMap
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap",
    maxZoom: 18
  }).addTo(map)

  // Datos del heatmap: [lat, lng, intensity]
  const maxCant = Math.max(...zonasCon.map(r=>r.cantidad))
  const heatData = zonasCon.map(r => [r.lat, r.lng, r.cantidad/maxCant])

  // Capa de heatmap
  L.heatLayer(heatData, {
    radius: 35,
    blur: 25,
    maxZoom: 14,
    max: 1.0,
    gradient: {0.0:"blue", 0.3:"cyan", 0.5:"lime", 0.7:"yellow", 1.0:"red"}
  }).addTo(map)

  // Círculos con tooltip para cada zona
  zonasCon.forEach(r => {
    const size = Math.max(6, Math.round(8 + (r.cantidad/maxCant)*20))
    L.circleMarker([r.lat, r.lng], {
      radius: size,
      fillColor: "#0d9488",
      color: "#fff",
      weight: 1.5,
      opacity: 0.9,
      fillOpacity: 0.7
    })
    .bindTooltip(`<strong>${r.zona}</strong><br>${r.cantidad} envíos (${r.pct_cantidad}% del Flex)<br>$ ${Math.round(r.ingresos).toLocaleString("es-AR")}`, {
      direction:"top", sticky:false
    })
    .addTo(map)
  })

  // Ajustar zoom para mostrar todos los puntos
  if(zonasCon.length > 1){
    const bounds = L.latLngBounds(zonasCon.map(r=>[r.lat,r.lng]))
    map.fitBounds(bounds, {padding:[30,30]})
  }
}


// ── Top provincias sort ───────────────────────────────────────────────────
S._provSort = "ingresos"

function setProvSort(key){
  S._provSort = key
  const acc = "var(--acc)", br = "var(--br)"
  const bI = $("btn-prov-ing"), bU = $("btn-prov-uds")
  if(bI){ bI.style.background = key==="ingresos"?"var(--acc)":"#fff"; bI.style.color = key==="ingresos"?"#fff":"var(--mu)"; bI.style.borderColor = key==="ingresos"?"var(--acc)":"var(--br)" }
  if(bU){ bU.style.background = key==="unidades"?"var(--acc)":"#fff"; bU.style.color = key==="unidades"?"#fff":"var(--mu)"; bU.style.borderColor = key==="unidades"?"var(--acc)":"var(--br)" }
  renderProvChart()
}

function renderProvChart(){
  const key = S._provSort || "ingresos"
  const rows = [...(S._provData||[])].sort((a,b)=>(b[key]||0)-(a[key]||0)).slice(0,10).reverse()
  const fmt2 = key==="unidades" ? v=>fN(v) : v=>fmt(v)
  const color = key==="unidades" ? "rgba(13,148,136,.72)" : "rgba(37,99,235,.72)"
  dc("c-pr")
  if(!rows.length) return
  S.charts["c-pr"] = new Chart($("c-pr"), {
    type: "bar",
    data: {
      labels: rows.map(r => r.label||"(vacío)"),
      datasets: [{
        data: rows.map(r => r[key]||0),
        backgroundColor: color,
        borderRadius: 3,
        borderSkipped: "left"
      }]
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        datalabels: { display: true, anchor: "end", align: "end", formatter: fmt2, font: { size: 9 }, color: "#475569" }
      },
      scales: {
        x: { ticks: { font: { size: 9 }, callback: fmt2 }, grid: { display: false } },
        y: { ticks: { font: { size: 10 } }, grid: { display: false } }
      }
    }
  })
}

function rB(cid,rows){
  dc(cid)
  if(!rows?.length)return
  rows=[...rows].reverse()
  S.charts[cid]=new Chart($(cid),{
    type:"bar",
    data:{labels:rows.map(r=>r.label||"(vacío)"),
      datasets:[{data:rows.map(r=>r.ingresos||0),backgroundColor:"rgba(37,99,235,.72)",borderRadius:3,borderSkipped:"left"}]},
    options:{indexAxis:"y",responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:false},
        datalabels:{display:true,anchor:"end",align:"end",formatter:v=>fN(v),font:{size:9},color:"#475569"}},
      scales:{
        x:{ticks:{font:{size:9},callback:v=>fN(v)},grid:{display:false}},
        y:{ticks:{font:{size:10}},grid:{display:false}}
      }
    }
  })
}

function rCustom(cid, rows, chartType="bar"){
  dc(cid)
  if(!rows?.length) return

  const labels = rows.map(r => (r.label||"(vacío)").toString().slice(0,35))
  const vals   = rows.map(r => r.valor || 0)
  const pcts   = rows.map(r => r.pct   || 0)
  const maxVal = Math.max(...vals) || 1

  const isHorizontal = chartType === "horizontalBar"
  const isDoughnut   = chartType === "doughnut"
  const isPie        = chartType === "pie"
  const isLine       = chartType === "line"
  const isArea       = chartType === "area"
  const isCircular   = isDoughnut || isPie

  // Paleta degradada de intensidad para barras
  const barColors = vals.map((v,i) => {
    const alpha = (0.45 + (v / maxVal) * 0.55).toFixed(2)
    return COLORS[i % COLORS.length] + Math.round(parseFloat(alpha)*255).toString(16).padStart(2,"0")
  })

  const chartJsType = isHorizontal ? "bar" : isArea ? "line" : chartType

  const dataset = {
    label: "Valor",
    data: vals,
    backgroundColor: isCircular ? COLORS.map(c=>c+"cc") : (isLine||isArea) ? "rgba(37,99,235,.12)" : barColors,
    borderColor:     isCircular ? COLORS : (isLine||isArea) ? "#2563eb" : COLORS.map(c=>c+"ff"),
    borderWidth:     isCircular ? 2 : (isLine||isArea) ? 2.5 : 1,
    borderRadius:    isCircular || isLine || isArea ? 0 : 5,
    fill:            isArea,
    tension:         (isLine||isArea) ? 0.35 : 0,
    pointRadius:     (isLine||isArea) ? 3.5 : 0,
    pointHoverRadius:(isLine||isArea) ? 5   : 0,
    hoverOffset:     isCircular ? 6 : 0,
    borderSkipped:   isHorizontal ? "left" : "bottom",
  }

  const fmtVal = v => {
    if(Math.abs(v) >= 1e6) return "$"+fN(Math.round(v/1000))+"K"
    if(Math.abs(v) >= 1e4) return fN(Math.round(v))
    return fN(v)
  }

  S.charts[cid] = new Chart($(cid), {
    type: chartJsType,
    data: { labels, datasets:[dataset] },
    options:{
      indexAxis:        isHorizontal ? "y" : "x",
      responsive:       true,
      maintainAspectRatio: false,
      animation:        { duration: 400 },
      plugins:{
        legend:{ display: isCircular, position:"right",
          labels:{ font:{size:10}, boxWidth:11, padding:8,
            generateLabels(ch){
              const ds=ch.data, tot=ds.datasets[0].data.reduce((a,b)=>a+b,0)
              return ds.labels.map((l,i)=>({
                text: `${l.length>18?l.slice(0,18)+"…":l}  ${tot?((ds.datasets[0].data[i]/tot)*100).toFixed(1)+"%":""}`,
                fillStyle: ds.datasets[0].backgroundColor[i], fontColor:"#475569", hidden:false, index:i
              }))
            }
          }
        },
        tooltip:{
          callbacks:{
            label: ctx => {
              const v = ctx.parsed[isHorizontal?"x":"y"] ?? ctx.parsed
              const tot = ctx.dataset.data.reduce((a,b)=>a+b,0)
              const pct = tot ? " (" + (v/tot*100).toFixed(1) + "%)" : ""
              return "  " + fmtVal(v) + pct
            }
          }
        },
        datalabels:{
          display: isCircular,
          formatter:(v,ctx)=>{
            const tot=ctx.dataset.data.reduce((a,b)=>a+b,0)
            const p = tot ? (v/tot*100) : 0
            return p >= 5 ? p.toFixed(1)+"%" : ""
          },
          font:{size:10, weight:"600"}, color:"#fff"
        }
      },
      scales: isCircular ? {} : {
        x:{
          ticks:{ font:{size:10}, maxRotation: isHorizontal?0:35,
                  callback: isHorizontal ? fmtVal : undefined },
          grid:{ display: isHorizontal, color:"rgba(0,0,0,.04)" }
        },
        y:{
          ticks:{ font:{size:10},
                  callback: isHorizontal ? undefined : fmtVal },
          grid:{ display: !isHorizontal, color:"rgba(0,0,0,.04)" }
        }
      }
    }
  })
}

// ── Funciones de control del panel viz ────────────────────────────────────
S._vizActive = false  // si hay una viz custom activa

function applyViz(){
  const by  = $("v-by")?.value
  const val = $("v-val")?.value
  if(!by || !val){
    // Mostrar ayuda visual en el panel
    const card = $("viz-custom-card")
    if(card){ card.style.boxShadow = "0 0 0 2px #ef4444"; setTimeout(()=>card.style.boxShadow="",1500) }
    return
  }
  S._vizActive = true
  rf()
}

function clearViz(){
  S._vizActive = false
  const bySel = $("v-by"), valSel = $("v-val")
  if(bySel) bySel.value = ""
  if(valSel) valSel.value = ""
  dc("c-viz")
  $("viz-custom-title").textContent = "Visualización personalizada"
  $("viz-custom-sub").textContent   = "Configurá en el panel izquierdo"
  // Mostrar estado vacío
  renderVizEmpty()
}

function renderVizEmpty(){
  const canvas = $("c-viz")
  if(!canvas) return
  const parent = canvas.parentElement
  const emptyId = "viz-empty-state"
  if(!$(emptyId)){
    const div = document.createElement("div")
    div.id = emptyId
    div.style.cssText = "position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#94a3b8;pointer-events:none"
    div.innerHTML = `
      <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" style="opacity:.4;margin-bottom:12px">
        <rect x="3" y="3" width="18" height="18" rx="2"/><polyline points="3,15 8,9 13,13 18,7"/>
      </svg>
      <div style="font-size:13px;font-weight:500;color:#64748b;margin-bottom:4px">Sin visualización activa</div>
      <div style="font-size:11px;color:#94a3b8;text-align:center;line-height:1.5;max-width:180px">
        Elegí columna, métrica y tipo de gráfico,<br>luego presioná <strong>Graficar</strong>
      </div>`
    parent.appendChild(div)
  } else {
    $(emptyId).style.display = ""
  }
}

function hideVizEmpty(){
  const el = $("viz-empty-state")
  if(el) el.style.display = "none"
}

function rTab(t){
  if(!t)return
  const rows=t.rows||[],tot=t.total||0,cols=t.cols||[]
  const ps=Math.max(1,Math.ceil(tot/50))
  S._tot=tot
  $("ts").textContent=`${tot} registros · ${cols.length} columnas`
  $("pi").textContent=`Página ${S.page+1} de ${ps} · ${tot} filas`
  $("pp").disabled=S.page===0;$("pn").disabled=S.page>=ps-1
  // Tabla dinámica con todas las columnas disponibles
  const twMain=$("tw-main")
  twMain.innerHTML=`<table>
    <thead><tr>${cols.map(c=>`<th${["ingresos","total_neto","costo","unidades"].includes(c)?' class="nr"':''}>${
      c.startsWith("_fecha")||c==="_fecha_str"?"Fecha":c.replace(/_/g," ")
    }</th>`).join("")}</tr></thead>
    <tbody>${rows.map(row=>`<tr>${cols.map(c=>{
      const v=row[c]
      const isNum=["ingresos","total_neto","costo","unidades"].includes(c)
      if(c==="estado")return`<td>${etag(v)}</td>`
      if(c==="fuente")return`<td>${srcTag(v)}</td>`
      if(isNum)return`<td class="nr" style="font-weight:${c==="ingresos"?"600":"400"}">${v==null?"—":fmt(v)}</td>`
      return`<td title="${v||""}" style="max-width:180px">${v==null||v==="null"?"—":String(v).slice(0,40)}</td>`
    }).join("")}</tr>`).join("")}</tbody>
  </table>`
}

// ── Dashi — Chat IA Flotante ──────────────────────────────────────────────
let chatChartCounter = 0
let dashiOpen = false
let chatHistorial = []   // {rol:"user"|"assistant", texto:"..."}

function toggleDashi(){
  dashiOpen = !dashiOpen
  const panel = $("dashi-panel")
  const notif  = $("dashi-notif")
  if(dashiOpen){
    panel.style.display = "flex"
    if(notif) notif.style.display = "none"
    // Mensaje de bienvenida si está vacío
    const msgs = $("chat-msgs")
    if(!msgs.children.length){
      const welcome = document.createElement("div")
      welcome.className = "dmsg-bot"
      const hasDatos = S.sids.length > 0
      welcome.innerHTML = hasDatos
        ? `<strong>¡Hola! Soy Dashi 🐾</strong><br>Cargaste datos y estoy listo para ayudarte. Podés preguntarme sobre tus ventas, comparar meses, ver qué producto te da más margen... ¡lo que quieras!`
        : `<strong>¡Hola! Soy Dashi 🐾</strong><br>Soy tu analista de ventas con IA. Primero cargá tus archivos de Mercado Libre o Tienda Nube y después ¡preguntame lo que quieras sobre tus datos!`
      msgs.appendChild(welcome)
    }
    setTimeout(()=>{ $("chat-input")?.focus() }, 100)
  } else {
    panel.style.display = "none"
  }
}

function clearChat(){
  chatHistorial = []
  $("chat-msgs").innerHTML = ""
  Object.keys(S.charts).filter(k=>k.startsWith("dc-")).forEach(k=>{
    S.charts[k]?.destroy(); delete S.charts[k]
  })
  const welcome = document.createElement("div")
  welcome.className = "dmsg-bot"
  welcome.innerHTML = `<strong>Chat limpio 🐾</strong><br>¿En qué más te puedo ayudar?`
  $("chat-msgs").appendChild(welcome)
}

function askChip(btn){
  // Sacar emoji del chip para la pregunta
  $("chat-input").value = btn.textContent.trim()
  sendChat()
}

async function sendChat(){
  if(!S.sids.length){
    toggleDashi()
    setTimeout(()=>sE("Primero cargá tus archivos de ventas."),100)
    return
  }
  const input = $("chat-input")
  const pregunta = input.value.trim()
  if(!pregunta) return
  input.value = ""
  input.disabled = true

  const msgs = $("chat-msgs")

  // Mensaje usuario
  const uDiv = document.createElement("div")
  uDiv.className = "dmsg-user"
  uDiv.textContent = pregunta
  msgs.appendChild(uDiv)

  // Typing animado
  const thinkDiv = document.createElement("div")
  thinkDiv.className = "dmsg-thinking"
  thinkDiv.innerHTML = "<span></span><span></span><span></span>"
  msgs.appendChild(thinkDiv)
  msgs.scrollTop = msgs.scrollHeight

  // Estado header
  const statusTxt = $("dashi-status-txt")
  if(statusTxt) statusTxt.textContent = "Analizando tus datos..."

  const sendBtn = $("chat-send")
  if(sendBtn){ sendBtn.disabled=true; sendBtn.style.opacity=".5" }

  try{
    const res = await fetch("/api/chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({sids:S.sids, pregunta, filtros:gF(), historial:chatHistorial})
    })
    const data = await res.json()
    if(!data.ok) throw new Error(data.error)
    // Guardar en historial para contexto
    chatHistorial.push({rol:"user", texto:pregunta})

    const r = data.resultado
    msgs.removeChild(thinkDiv)

    // Burbuja respuesta
    const botDiv = document.createElement("div")
    botDiv.className = "dmsg-bot"

    const txtDiv = document.createElement("div")
    // Formatear: negrita para **texto**
    txtDiv.innerHTML = (r.respuesta||"Sin respuesta.")
      .replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>")
      .replace(/\n/g,"<br>")
    botDiv.appendChild(txtDiv)

    // Gráfico
    const g = r.grafico
    if(g && g.tipo && g.tipo!=="none" && g.labels?.length && g.values?.length){
      const chartId = "dc-" + (++chatChartCounter)
      const wrap = document.createElement("div")
      wrap.className = "dmsg-chart"
      const canvas = document.createElement("canvas")
      canvas.id = chartId
      wrap.appendChild(canvas)
      botDiv.appendChild(wrap)

      setTimeout(()=>{
        const isDoughnut = g.tipo==="doughnut"
        const isLine     = g.tipo==="line"
        const datasets = [{
          label: g.label_series||"Valor",
          data: g.values,
          backgroundColor: isDoughnut ? COLORS.map(c=>c+"dd") : isLine?"rgba(192,57,43,.12)":(g.color||"rgba(192,57,43,.8)"),
          borderColor: isLine?(g.color||"#c0392b"):COLORS,
          fill:isLine, tension:isLine?.4:0,
          pointRadius:isLine?4:0, borderWidth:isLine?2.5:1,
          borderRadius:isDoughnut||isLine?0:5
        }]
        if(g.values2?.length) datasets.push({
          label:g.label_series2||"Serie 2", data:g.values2, type:"line",
          borderColor:"#16a34a", backgroundColor:"rgba(22,163,74,.08)",
          fill:true,tension:.4,pointRadius:3,borderWidth:2,yAxisID:"y2"
        })
        S.charts[chartId] = new Chart($(chartId),{
          type:g.tipo,
          data:{ labels:g.labels, datasets },
          options:{
            responsive:true,maintainAspectRatio:false,
            plugins:{
              legend:{display:datasets.length>1||isDoughnut,labels:{font:{size:10},boxWidth:10}},
              title:{display:!!g.titulo,text:g.titulo,font:{size:11,weight:"600"},padding:{bottom:5}},
              datalabels:{display:isDoughnut,
                formatter:(v,ctx)=>{const t=ctx.dataset.data.reduce((a,b)=>a+b,0);return t?(v/t*100).toFixed(1)+"%":""},
                font:{size:10},color:"#fff"}
            },
            scales: isDoughnut ? {} : {
              x:{ticks:{font:{size:9},maxRotation:30},grid:{display:false}},
              y:{ticks:{font:{size:9},callback:v=>typeof v==="number"&&v>999?"$"+Math.round(v).toLocaleString("es-AR"):v},grid:{color:"rgba(0,0,0,.04)"}},
              ...(g.values2?.length?{y2:{position:"right",ticks:{font:{size:9}},grid:{display:false}}}:{})
            }
          }
        })
      },60)
    }

    msgs.appendChild(botDiv)
    // Guardar respuesta en historial
    chatHistorial.push({rol:"assistant", texto: r.respuesta||""})
    // Limitar historial a 10 turnos
    if(chatHistorial.length > 20) chatHistorial = chatHistorial.slice(-20)

  }catch(e){
    if(thinkDiv.parentNode) msgs.removeChild(thinkDiv)
    const errDiv = document.createElement("div")
    errDiv.className = "dmsg-bot"
    errDiv.style.cssText += ";border-color:#fecaca;background:#fff5f5"
    const msg = e.message||"Error desconocido"
    const friendly = msg.includes("key")||msg.includes("API key")
      ? "⚙️ Necesitás configurar la API Key. Tocá el botón <strong>⚙️</strong> arriba a la derecha."
      : msg.includes("429") ? "🐾 Demasiadas consultas seguidas, esperá un momento e intentá de nuevo."
      : msg.includes("timeout") ? "⏱️ La consulta tardó demasiado. Intentá de nuevo."
      : `❌ ${msg}`
    errDiv.innerHTML = `<span>${friendly}</span>`
    msgs.appendChild(errDiv)
  }finally{
    input.disabled = false
    if(sendBtn){ sendBtn.disabled=false; sendBtn.style.opacity="1" }
    if(statusTxt) statusTxt.textContent = "Tu analista de ventas"
    msgs.scrollTop = msgs.scrollHeight
    input.focus()
  }
}


</script>
</body>
</html>
"""

# ═══════════════════════════════════════════════════════════════════════════
# API KEY + CHAT ROUTES
# ═══════════════════════════════════════════════════════════════════════════

@app.route("/api/chat", methods=["POST"])
def api_chat():
    """
    Motor analítico local inteligente.
    Extrae entidades (productos, meses, métricas, zonas) de la pregunta
    y genera respuesta + gráfico a medida sin API externa.
    """
    import difflib

    body     = request.json or {}
    sids     = body.get("sids", [])
    pregunta = body.get("pregunta", "").strip()
    filtros  = body.get("filtros", {})

    if not pregunta: return err("Pregunta vacia.")
    if not sids:     return err("No hay datos cargados.")

    try:
        df0 = _get_combined(sids)
        if df0.empty: return err("Sin datos.")
        df = apply_filters(df0, filtros)
        m  = metricas(df)
    except Exception as ex:
        traceback.print_exc()
        return err("Error procesando datos: " + str(ex))

    p_orig = pregunta
    p = pregunta.lower()

    # ── HELPERS ─────────────────────────────────────────────────────────
    def fmt_ars(v):
        try: return "$ {:,}".format(int(round(v))).replace(",", ".")
        except: return "$ 0"

    def var_pct(nuevo, viejo):
        if not viejo: return None
        return round((nuevo - viejo) / viejo * 100, 1)

    def flecha(pct):
        if pct is None: return ""
        return ("▲ +{}%".format(pct)) if pct > 0 else ("▼ {}%".format(pct))

    def no_grafico():
        return {"tipo":"none","titulo":"","labels":[],"values":[],"values2":[],
                "label_series":"","label_series2":"","color":"#2563eb"}

    def norm_grafico(g):
        def _v(x):
            # Convert numpy types to native Python
            try:
                import numpy as np
                if isinstance(x, (np.integer,)): return int(x)
                if isinstance(x, (np.floating,)): return float(x)
            except ImportError: pass
            if hasattr(x, 'item'): return x.item()
            return x
        def _vlist(lst):
            return [round(float(_v(x)), 2) if isinstance(_v(x), float) else _v(x) for x in (lst or [])]
        return {
            "tipo":          g.get("tipo","none"),
            "titulo":        str(g.get("titulo","")),
            "labels":        [str(l) for l in g.get("labels",[])],
            "values":        _vlist(g.get("values",[])),
            "values2":       _vlist(g.get("values2",[])),
            "label_series":  str(g.get("label_series","")),
            "label_series2": str(g.get("label_series2","")),
            "color":         str(g.get("color","#2563eb")),
        }

    def meses_data():
        if "_mes" not in df.columns: return {}
        result = {}
        for mes in sorted(df["_mes"].dropna().unique()):
            sub = df[df["_mes"] == mes]
            result[mes] = metricas(sub)
        return result

    # ── EXTRACCIÓN DE ENTIDADES ──────────────────────────────────────────
    MESES_MAP = {
        "enero":"01","febrero":"02","marzo":"03","abril":"04",
        "mayo":"05","junio":"06","julio":"07","agosto":"08",
        "septiembre":"09","octubre":"10","noviembre":"11","diciembre":"12",
        "ene":"01","feb":"02","mar":"03","abr":"04","jun":"06",
        "jul":"07","ago":"08","sep":"09","oct":"10","nov":"11","dic":"12",
    }
    ANIOS = ["2024","2025","2026","2027"]
    METRICAS_MAP = {
        "ingresos":["ingreso","facturacion","facturación","plata","dinero","venta en pesos","$"],
        "unidades":["unidad","unidades","cantidad","cuantos","cuántos","vendidos","piezas"],
        "n_ventas":["ordenes","órdenes","pedidos","ventas","transacciones","operaciones"],
        "ticket_prom":["ticket","promedio","precio promedio","valor promedio"],
        "costo":["costo","costos","gasto","gastos","comision"],
    }

    def detectar_metrica(texto):
        for col, kws in METRICAS_MAP.items():
            if any(kw in texto for kw in kws):
                return col
        return "ingresos"  # default

    def detectar_meses_en_texto(texto):
        found = []
        anio_actual = "2026"
        for anio in ANIOS:
            if anio in texto:
                anio_actual = anio
                break
        for nombre, num in MESES_MAP.items():
            if nombre in texto:
                # Try to find the year near this month
                idx = texto.find(nombre)
                ctx = texto[max(0,idx-5):idx+20]
                anio_cercano = anio_actual
                for a in ANIOS:
                    if a in ctx:
                        anio_cercano = a
                        break
                key = "{}-{}".format(anio_cercano, num)
                if key not in found:
                    found.append(key)
        return found

    def detectar_meses_disponibles():
        if "_mes" not in df.columns: return []
        return sorted(df["_mes"].dropna().unique().tolist())

    def buscar_producto(texto):
        """Busca el producto más similar al mencionado en la pregunta."""
        if "publicacion" not in df.columns: return None
        prods = df["publicacion"].dropna().unique().tolist()
        if not prods: return None
        # Buscar coincidencia directa (case insensitive)
        texto_lower = texto.lower()
        for p_name in prods:
            if p_name and p_name.lower() in texto_lower:
                return p_name
        # Buscar palabras del texto en nombres de productos
        palabras = [w for w in texto_lower.split() if len(w) > 3]
        best_score = 0
        best_prod  = None
        for p_name in prods:
            if not p_name: continue
            p_lower = p_name.lower()
            score = sum(1 for w in palabras if w in p_lower)
            if score > best_score:
                best_score = score
                best_prod  = p_name
        if best_score > 0:
            return best_prod
        # Fuzzy match como último recurso
        texto_words = texto_lower.split()
        for word in texto_words:
            if len(word) < 4: continue
            matches = difflib.get_close_matches(word,
                [pn.lower() for pn in prods if pn], n=1, cutoff=0.7)
            if matches:
                for pn in prods:
                    if pn and pn.lower() == matches[0]:
                        return pn
        return None

    def buscar_zona(texto):
        if "provincia" not in df.columns: return None
        zonas = df["provincia"].dropna().unique().tolist()
        texto_lower = texto.lower()
        for z in zonas:
            if z and z.lower() in texto_lower:
                return z
        return None

    # ── DETECCIÓN DE INTENCIÓN ───────────────────────────────────────────
    meses_en_pregunta  = detectar_meses_en_texto(p)
    meses_disponibles  = detectar_meses_disponibles()
    metrica_pedida     = detectar_metrica(p)
    producto_pedido    = buscar_producto(p_orig)
    zona_pedida        = buscar_zona(p_orig)
    es_comparacion     = any(x in p for x in ["compar","vs","versus","contra","diferencia","cambio entre","entre","diferencia"])
    es_evolucion       = any(x in p for x in ["evolucion","evoluci","tendencia","historico","tiempo","mes a mes","como fue","como estuvo"])
    es_top             = any(x in p for x in ["top","mejor","peor","mas vendido","mas factur","mayor","menor","ranking","primeros","ultimos"])
    es_distribucion    = any(x in p for x in ["distribucion","distribuci","porcentaje","proporcion","como se reparte","cuanto representa"])

    respuesta = ""
    g = no_grafico()

    # ══════════════════════════════════════════════════════════════════════
    # CASO A: Producto específico mencionado
    # ══════════════════════════════════════════════════════════════════════
    if producto_pedido and "publicacion" in df.columns:
        df_prod = df[df["publicacion"] == producto_pedido]

        # A1: COMPARACIÓN de producto entre 2 meses
        if len(meses_en_pregunta) == 2 and "_mes" in df.columns:
            m1, m2 = meses_en_pregunta[0], meses_en_pregunta[1]
            df1 = df_prod[df_prod["_mes"] == m1]
            df2 = df_prod[df_prod["_mes"] == m2]

            v1 = float(_R(df1[metrica_pedida].sum())) if metrica_pedida in df1.columns and not df1.empty else 0.0
            v2 = float(_R(df2[metrica_pedida].sum())) if metrica_pedida in df2.columns and not df2.empty else 0.0
            vp = var_pct(v2, v1)

            lbl_met = {"ingresos":"Ingresos","unidades":"Unidades","n_ventas":"Ventas","ticket_prom":"Ticket prom","costo":"Costos"}.get(metrica_pedida,"Valor")
            fmt_v = (lambda v: fmt_ars(v)) if metrica_pedida in ["ingresos","costo","ticket_prom"] else (lambda v: str(int(v)))

            respuesta = (
                "📊 **{}** — {} por mes\n\n".format(producto_pedido[:45], lbl_met) +
                "**{}:** {} {}\n".format(m1, fmt_v(v1), "" if v1 > 0 else "(sin ventas)") +
                "**{}:** {} {}\n".format(m2, fmt_v(v2), "" if v2 > 0 else "(sin ventas)") +
                "\n"
            )
            if v1 == 0 and v2 == 0:
                respuesta += "⚠️ No hay datos de este producto en esos meses."
            elif vp is not None:
                respuesta += "{} {} en {} comparado con {}.".format(
                    "▲ Creció un {}%".format(vp) if vp > 0 else "▼ Cayó un {}%".format(abs(vp)),
                    "en " + lbl_met.lower(), m2, m1)
            g = {
                "tipo": "bar",
                "titulo": "{} — {} ({} vs {})".format(producto_pedido[:30], lbl_met, m1, m2),
                "labels": [m1, m2],
                "values": [v1, v2],
                "values2": [],
                "label_series": lbl_met,
                "label_series2": "",
                "color": "#7c3aed"
            }

        # A2: Producto en TODOS los meses (evolución)
        elif "_mes" in df.columns and (es_evolucion or len(meses_disponibles) > 1):
            evol = []
            for mes in meses_disponibles:
                sub = df_prod[df_prod["_mes"] == mes]
                if sub.empty: continue
                val = _R(sub[metrica_pedida].sum()) if metrica_pedida in sub.columns else 0
                evol.append({"mes": mes, "valor": val})

            if not evol:
                respuesta = "No hay datos de **{}** en ningún mes del período.".format(producto_pedido)
            else:
                vals  = [e["valor"] for e in evol]
                lbl_met = {"ingresos":"Ingresos","unidades":"Unidades","n_ventas":"Ventas"}.get(metrica_pedida,"Valor")
                fmt_v  = (lambda v: fmt_ars(v)) if metrica_pedida in ["ingresos","costo"] else (lambda v: str(int(v)))
                max_v  = max(vals); max_m = evol[vals.index(max_v)]["mes"]
                respuesta = (
                    "📈 **{}** — evolución de {}\n\n".format(producto_pedido[:40], lbl_met.lower()) +
                    "**Mejor mes:** {} con {}\n".format(max_m, fmt_v(max_v)) +
                    "**Total período:** {}\n\n".format(fmt_v(sum(vals)))
                )
                if len(vals) >= 2:
                    vp = var_pct(vals[-1], vals[0])
                    respuesta += "Entre {} y {}: {}".format(evol[0]["mes"], evol[-1]["mes"], flecha(vp))
                g = {
                    "tipo": "line",
                    "titulo": "{} — {} por mes".format(producto_pedido[:30], lbl_met),
                    "labels": [e["mes"] for e in evol],
                    "values": [e["valor"] for e in evol],
                    "values2": [],
                    "label_series": lbl_met,
                    "label_series2": "",
                    "color": "#7c3aed"
                }

        # A3: Resumen del producto
        else:
            mm = metricas(df_prod)
            top_prov_prod = grp(df_prod, "provincia", top=3)
            respuesta = (
                "🛍️ **{}**\n\n".format(producto_pedido[:50]) +
                "**Ventas:** {} órdenes · **Unidades:** {} · **Ingresos:** {}\n".format(
                    mm["n_ventas"], int(mm["unidades"]), fmt_ars(mm["ingresos"])) +
                "**Ticket promedio:** {}\n".format(fmt_ars(mm["ticket_prom"]))
            )
            if top_prov_prod:
                respuesta += "**Provincias top:** " + ", ".join(
                    "{} ({}%)".format(r["label"], r.get("pct",0)) for r in top_prov_prod) + "\n"
            top_prods_all = grp(df, "publicacion", top=20)
            rank = next((i+1 for i,r in enumerate(top_prods_all) if r["label"] == producto_pedido), None)
            if rank:
                respuesta += "**Ranking:** #{} en ingresos entre todos tus productos".format(rank)

            g = {
                "tipo": "doughnut" if top_prov_prod else "none",
                "titulo": "{} — ventas por provincia".format(producto_pedido[:30]),
                "labels": [r["label"] for r in top_prov_prod],
                "values": [r["ingresos"] for r in top_prov_prod],
                "values2": [],
                "label_series": "Ingresos",
                "label_series2": "",
                "color": "#7c3aed"
            }

    # ══════════════════════════════════════════════════════════════════════
    # CASO B: Comparación de 2 meses específicos (sin producto)
    # ══════════════════════════════════════════════════════════════════════
    elif len(meses_en_pregunta) == 2 and "_mes" in df.columns:
        m1, m2 = meses_en_pregunta[0], meses_en_pregunta[1]
        df1 = df[df["_mes"] == m1]; df2 = df[df["_mes"] == m2]
        mm1 = metricas(df1); mm2 = metricas(df2)

        v_ing = var_pct(mm2["ingresos"],    mm1["ingresos"])
        v_ven = var_pct(mm2["n_ventas"],    mm1["n_ventas"])
        v_uds = var_pct(mm2["unidades"],    mm1["unidades"])
        v_tck = var_pct(mm2["ticket_prom"], mm1["ticket_prom"])

        respuesta = (
            "📊 **Comparación {} vs {}**\n\n".format(m1, m2) +
            "| Métrica | {} | {} | Variación |\n".format(m1, m2) +
            "|---|---|---|---|\n" +
            "| Ingresos | {} | {} | {} |\n".format(fmt_ars(mm1["ingresos"]), fmt_ars(mm2["ingresos"]), flecha(v_ing)) +
            "| Ventas | {} | {} | {} |\n".format(mm1["n_ventas"], mm2["n_ventas"], flecha(v_ven)) +
            "| Unidades | {} | {} | {} |\n".format(int(mm1["unidades"]), int(mm2["unidades"]), flecha(v_uds)) +
            "| Ticket prom | {} | {} | {} |".format(fmt_ars(mm1["ticket_prom"]), fmt_ars(mm2["ticket_prom"]), flecha(v_tck))
        )
        metrica_mostrar = metrica_pedida
        val1 = _R(df1[metrica_mostrar].sum()) if metrica_mostrar in df1.columns and not df1.empty else mm1.get(metrica_mostrar,0)
        val2 = _R(df2[metrica_mostrar].sum()) if metrica_mostrar in df2.columns and not df2.empty else mm2.get(metrica_mostrar,0)
        lbl_met = {"ingresos":"Ingresos","unidades":"Unidades","n_ventas":"Ventas"}.get(metrica_mostrar,"Valor")
        g = {
            "tipo": "bar",
            "titulo": "Comparación {} vs {} — {}".format(m1, m2, lbl_met),
            "labels": [m1, m2],
            "values": [val1, val2],
            "values2": [mm1["n_ventas"], mm2["n_ventas"]],
            "label_series": lbl_met, "label_series2": "Ventas",
            "color": "#2563eb"
        }

    # ══════════════════════════════════════════════════════════════════════
    # CASO C: Zona específica mencionada
    # ══════════════════════════════════════════════════════════════════════
    elif zona_pedida and "provincia" in df.columns:
        df_zona = df[df["provincia"] == zona_pedida]
        mm_zona = metricas(df_zona)
        top_prods_zona = grp(df_zona, "publicacion", top=5)

        respuesta = (
            "📍 **{}** — análisis de zona\n\n".format(zona_pedida) +
            "**Ventas:** {} órdenes · **Ingresos:** {} · **Unidades:** {}\n".format(
                mm_zona["n_ventas"], fmt_ars(mm_zona["ingresos"]), int(mm_zona["unidades"])) +
            "**Ticket promedio:** {}\n\n".format(fmt_ars(mm_zona["ticket_prom"]))
        )
        if top_prods_zona:
            respuesta += "**Top productos en {}:**\n".format(zona_pedida)
            for i, r in enumerate(top_prods_zona[:5], 1):
                respuesta += "{}. {} — {} ({} uds)\n".format(
                    i, r["label"][:35], fmt_ars(r["ingresos"]), int(r.get("unidades",0)))

        # Evolución de la zona por mes
        if "_mes" in df_zona.columns:
            evol_zona = []
            for mes in meses_disponibles:
                sub = df_zona[df_zona["_mes"] == mes]
                if sub.empty: continue
                evol_zona.append({"mes": mes, "valor": _R(float(sub["ingresos"].sum())) if "ingresos" in sub.columns else 0})
            if len(evol_zona) > 1:
                g = {
                    "tipo": "line",
                    "titulo": "{} — ingresos por mes".format(zona_pedida),
                    "labels": [e["mes"] for e in evol_zona],
                    "values": [e["valor"] for e in evol_zona],
                    "values2": [],
                    "label_series": "Ingresos",
                    "label_series2": "",
                    "color": "#0d9488"
                }
            elif top_prods_zona:
                g = {
                    "tipo": "bar",
                    "titulo": "Top productos en {}".format(zona_pedida),
                    "labels": [r["label"][:25] for r in top_prods_zona],
                    "values": [r["ingresos"] for r in top_prods_zona],
                    "values2": [r.get("unidades",0) for r in top_prods_zona],
                    "label_series": "Ingresos", "label_series2": "Unidades",
                    "color": "#0d9488"
                }

    # ══════════════════════════════════════════════════════════════════════
    # CASO D: Un mes específico mencionado (análisis de ese mes)
    # ══════════════════════════════════════════════════════════════════════
    elif len(meses_en_pregunta) == 1 and "_mes" in df.columns:
        mes_pedido = meses_en_pregunta[0]
        df_mes = df[df["_mes"] == mes_pedido]

        if df_mes.empty:
            respuesta = "No encontré datos para **{}**. Los meses disponibles son: {}.".format(
                mes_pedido, ", ".join(meses_disponibles))
        else:
            mm_mes = metricas(df_mes)
            top_prods_mes = grp(df_mes, "publicacion", top=5)
            top_prov_mes  = grp(df_mes, "provincia", top=3)

            respuesta = (
                "📅 **{}** — resumen del mes\n\n".format(mes_pedido) +
                "**Ventas:** {} órdenes · **Ingresos:** {} · **Unidades:** {}\n".format(
                    mm_mes["n_ventas"], fmt_ars(mm_mes["ingresos"]), int(mm_mes["unidades"])) +
                "**Ticket promedio:** {} · **Tasa entrega:** {}%\n\n".format(
                    fmt_ars(mm_mes["ticket_prom"]), mm_mes["tasa_ok"])
            )
            if top_prods_mes:
                respuesta += "**Top productos:**\n"
                for i,r in enumerate(top_prods_mes[:3],1):
                    respuesta += "{}. {} — {} ({} uds)\n".format(
                        i, r["label"][:35], fmt_ars(r["ingresos"]), int(r.get("unidades",0)))

            # Comparar con mes anterior si existe
            idx_mes = meses_disponibles.index(mes_pedido) if mes_pedido in meses_disponibles else -1
            if idx_mes > 0:
                mes_ant = meses_disponibles[idx_mes - 1]
                df_ant  = df[df["_mes"] == mes_ant]
                mm_ant  = metricas(df_ant)
                vp = var_pct(mm_mes["ingresos"], mm_ant["ingresos"])
                respuesta += "\n{} vs {}: {} en ingresos".format(mes_pedido, mes_ant, flecha(vp))

            met = metrica_pedida
            lbl_met = {"ingresos":"Ingresos","unidades":"Unidades","n_ventas":"Ventas"}.get(met,"Ingresos")
            g = {
                "tipo": "bar",
                "titulo": "Top productos en {} — {}".format(mes_pedido, lbl_met),
                "labels": [r["label"][:28] for r in top_prods_mes[:8]],
                "values": [r["ingresos"] if met=="ingresos" else r.get("unidades",0) for r in top_prods_mes[:8]],
                "values2": [r.get("unidades",0) if met=="ingresos" else r["ingresos"] for r in top_prods_mes[:8]],
                "label_series": lbl_met, "label_series2": "Unidades" if met=="ingresos" else "Ingresos",
                "color": "#2563eb"
            }

    # ══════════════════════════════════════════════════════════════════════
    # CASO E: TOP / RANKING con métrica específica
    # ══════════════════════════════════════════════════════════════════════
    elif es_top:
        met  = metrica_pedida
        lbl_met = {"ingresos":"Ingresos","unidades":"Unidades","n_ventas":"Ventas","ticket_prom":"Ticket prom","costo":"Costos"}.get(met,"Ingresos")
        fmt_v = (lambda v: fmt_ars(v)) if met in ["ingresos","costo","ticket_prom"] else (lambda v: str(int(v)))
        peor = any(x in p for x in ["peor","menor","menos","últimos","ultimos","bajo"])

        top = grp(df, "publicacion", top=10)
        if met == "unidades":
            top_sorted = sorted(top, key=lambda x: x.get("unidades",0), reverse=not peor)
        elif met == "n_ventas":
            top_sorted = sorted(top, key=lambda x: x.get("cantidad",0), reverse=not peor)
        else:
            top_sorted = sorted(top, key=lambda x: x["ingresos"], reverse=not peor)

        prefix = "Peor" if peor else "Top"
        respuesta = "🏆 **{} productos por {}**\n\n".format(prefix, lbl_met.lower())
        for i, r in enumerate(top_sorted[:8], 1):
            val = r.get("unidades",0) if met=="unidades" else r.get("cantidad",0) if met=="n_ventas" else r["ingresos"]
            respuesta += "**{}. {}** — {}\n".format(i, r["label"][:38], fmt_v(val))

        g = {
            "tipo": "bar",
            "titulo": "{} productos por {}".format(prefix, lbl_met),
            "labels": [r["label"][:28] for r in top_sorted[:8]],
            "values": [r.get("unidades",0) if met=="unidades" else r.get("cantidad",0) if met=="n_ventas" else r["ingresos"] for r in top_sorted[:8]],
            "values2": [r["ingresos"] if met!="ingresos" else r.get("unidades",0) for r in top_sorted[:8]],
            "label_series": lbl_met, "label_series2": "Ingresos" if met!="ingresos" else "Unidades",
            "color": "#16a34a" if not peor else "#dc2626"
        }

    # ══════════════════════════════════════════════════════════════════════
    # CASO F: Evolución temporal general
    # ══════════════════════════════════════════════════════════════════════
    elif es_evolucion or any(x in p for x in ["evolucion","tendencia","historico","tiempo","mes a mes","como fue","dias"]):
        met = metrica_pedida
        periodo_t = "mes" if m["n_ventas"] > 300 else "dia"
        tiempo = por_tiempo(df, periodo_t)
        lbl_met = {"ingresos":"Ingresos","unidades":"Unidades","n_ventas":"Ventas"}.get(met,"Ingresos")

        if not tiempo:
            respuesta = "No hay suficientes datos temporales para mostrar evolución."
        else:
            t_show = tiempo[-18:]
            vals = [r.get(met, r["ingresos"]) for r in t_show]
            max_v = max(vals); min_v = min(vals)
            max_p = t_show[vals.index(max_v)]["periodo"]
            min_p = t_show[vals.index(min_v)]["periodo"]
            ultimos = vals[-3:] if len(vals) >= 3 else vals
            if len(ultimos) >= 2 and ultimos[-1] > ultimos[0]:
                tend = "📈 Tendencia reciente al alza."
            elif len(ultimos) >= 2 and ultimos[-1] < ultimos[0]:
                tend = "📉 Tendencia reciente a la baja."
            else:
                tend = "➡️ Tendencia reciente estable."
            respuesta = (
                "📈 **Evolución de {} por {}**\n\n".format(lbl_met.lower(), periodo_t) +
                "**Mejor período:** {} ({} {})\n".format(max_p, "$ {:,}".format(int(max_v)).replace(",",".") if met in ["ingresos","costo"] else str(int(max_v)), lbl_met.lower()) +
                "**Período más bajo:** {} ({} {})\n\n".format(min_p, "$ {:,}".format(int(min_v)).replace(",",".") if met in ["ingresos","costo"] else str(int(min_v)), lbl_met.lower()) +
                tend
            )
            g = {
                "tipo": "line",
                "titulo": "Evolución de {} por {}".format(lbl_met, periodo_t),
                "labels": [r["periodo"] for r in t_show],
                "values": vals,
                "values2": [r.get("unidades",0) for r in t_show] if met == "ingresos" else [],
                "label_series": lbl_met, "label_series2": "Unidades" if met == "ingresos" else "",
                "color": "#2563eb"
            }

    # ══════════════════════════════════════════════════════════════════════
    # CASO G: Comparación mes anterior (sin meses explícitos)
    # ══════════════════════════════════════════════════════════════════════
    elif any(x in p for x in ["mes pasado","mes anterior","comparar","mes a mes","vendi mas","vendi menos","crecio","crecí","bajo","subi"]):
        md    = meses_data()
        meses = sorted(md.keys())
        if len(meses) < 2:
            mes = meses[0] if meses else "sin datos"
            mm_u = md.get(mes, m)
            respuesta = (
                "📅 Solo tengo datos de **{}**. Carga otro mes para comparar.\n\n".format(mes) +
                "{} ventas · {} ingresos · ticket prom {}".format(
                    mm_u["n_ventas"], fmt_ars(mm_u["ingresos"]), fmt_ars(mm_u["ticket_prom"]))
            )
        else:
            m_act = meses[-1]; m_ant = meses[-2]
            da = md[m_act]; db = md[m_ant]
            v_ing = var_pct(da["ingresos"], db["ingresos"])
            v_ven = var_pct(da["n_ventas"], db["n_ventas"])
            v_uds = var_pct(da["unidades"], db["unidades"])
            respuesta = (
                "📊 **{} vs {}**\n\n".format(m_act, m_ant) +
                "**Ingresos:** {} {} vs {}\n".format(fmt_ars(da["ingresos"]), flecha(v_ing), fmt_ars(db["ingresos"])) +
                "**Ventas:** {} {} vs {}\n".format(da["n_ventas"], flecha(v_ven), db["n_ventas"]) +
                "**Unidades:** {} {} vs {}\n\n".format(int(da["unidades"]), flecha(v_uds), int(db["unidades"]))
            )
            if (v_ing or 0) > 5: respuesta += "🚀 Creciste {}% en ingresos.".format(v_ing)
            elif (v_ing or 0) < -5: respuesta += "⚠️ Caída de {}% en ingresos.".format(abs(v_ing or 0))
            else: respuesta += "➡️ Ingresos similares al mes anterior."
            g = {
                "tipo": "bar", "titulo": "Comparación mensual — Ingresos",
                "labels": meses, "values": [md[ms]["ingresos"] for ms in meses],
                "values2": [md[ms]["n_ventas"] for ms in meses],
                "label_series": "Ingresos ($)", "label_series2": "Ventas",
                "color": "#2563eb"
            }

    # ══════════════════════════════════════════════════════════════════════
    # CASO H: Distribución / porcentajes
    # ══════════════════════════════════════════════════════════════════════
    elif es_distribucion:
        if any(x in p for x in ["envio","flex","logistic"]):
            top_env = grp(df, "forma_envio", top=8) if "forma_envio" in df.columns else []
            g = {"tipo":"doughnut","titulo":"Distribución por tipo de envío",
                 "labels":[r["label"] for r in top_env],"values":[r.get("cantidad",0) for r in top_env],
                 "values2":[],"label_series":"Envíos","label_series2":"","color":"#0d9488"}
            respuesta = "📊 Distribución de envíos:\n\n" + "\n".join(
                "**{}:** {}% ({} envíos)".format(r["label"], r.get("pct",0), r.get("cantidad",0)) for r in top_env[:6])
        elif any(x in p for x in ["estado","cancelado","entregado"]):
            est = grp(df, "estado")
            g = {"tipo":"doughnut","titulo":"Distribución por estado de venta",
                 "labels":[r["label"] for r in est],"values":[r.get("cantidad",0) for r in est],
                 "values2":[],"label_series":"Cantidad","label_series2":"","color":"#7c3aed"}
            respuesta = "📊 Distribución por estado:\n\n" + "\n".join(
                "**{}:** {}% ({})".format(r["label"], r.get("pct",0), r.get("cantidad",0)) for r in est)
        else:
            top = grp(df, "publicacion", top=8)
            g = {"tipo":"doughnut","titulo":"Distribución de ingresos por producto",
                 "labels":[r["label"][:25] for r in top],"values":[r["ingresos"] for r in top],
                 "values2":[],"label_series":"Ingresos","label_series2":"","color":"#2563eb"}
            respuesta = "📊 Distribución de ingresos por producto:\n\n" + "\n".join(
                "**{}:** {}% ({})".format(r["label"][:35], r.get("pct",0), fmt_ars(r["ingresos"])) for r in top[:6])

    # ══════════════════════════════════════════════════════════════════════
    # CASO I: Costos / margen
    # ══════════════════════════════════════════════════════════════════════
    elif any(x in p for x in ["costo","gasto","margen","ganancia","neto","comision"]):
        ing = m["ingresos"]; cost = m["costo"]; neto = m["total_neto"]
        margen_pct = round(neto / ing * 100, 1) if ing else 0
        respuesta = (
            "💰 **Análisis de costos**\n\n" +
            "**Ingresos brutos:** {}\n".format(fmt_ars(ing)) +
            "**Costos (envío + cargos ML):** {}\n".format(fmt_ars(cost)) +
            "**Ingreso neto:** {}\n".format(fmt_ars(neto)) +
            "**Margen neto estimado:** {}%\n\n".format(margen_pct) +
            ("⚠️ Margen bajo del 50%. Evaluá ajustar precios." if margen_pct < 50
             else "📊 Margen razonable." if margen_pct < 70
             else "✅ Buen margen controlado.")
        )
        g = {"tipo":"doughnut","titulo":"Ingresos vs Costos",
             "labels":["Ingreso neto","Costos"],"values":[round(neto,2),round(cost,2)],
             "values2":[],"label_series":"Distribución","label_series2":"","color":"#16a34a"}

    # ══════════════════════════════════════════════════════════════════════
    # CASO J: Resumen / fallback
    # ══════════════════════════════════════════════════════════════════════
    else:
        md = meses_data(); meses_disp = sorted(md.keys())
        top3 = grp(df, "publicacion", top=3)
        top1p = grp(df, "provincia", top=1)
        respuesta = (
            "🐾 **Resumen de tus ventas**\n\n" +
            "**{} órdenes** · **{} unidades** · **{}** en ingresos\n".format(
                m["n_ventas"], int(m["unidades"]), fmt_ars(m["ingresos"])) +
            "Ticket prom: **{}** · Tasa entrega: **{}%**\n\n".format(
                fmt_ars(m["ticket_prom"]), m["tasa_ok"])
        )
        if top3: respuesta += "🏆 Top: **{}** ({})\n".format(top3[0]["label"][:40], fmt_ars(top3[0]["ingresos"]))
        if top1p: respuesta += "📍 Zona líder: **{}** ({}%)\n".format(top1p[0]["label"], top1p[0].get("pct",0))
        if len(meses_disp) >= 2:
            vp = var_pct(md[meses_disp[-1]]["ingresos"], md[meses_disp[-2]]["ingresos"])
            respuesta += "📅 vs mes anterior: {}\n".format(flecha(vp))
        respuesta += (
            "\n💡 Ejemplos de lo que podés preguntarme:\n" +
            "• Compará Camiseta XL en enero vs febrero\n" +
            "• Top 5 productos por unidades vendidas\n" +
            "• ¿Cómo le fue a Buenos Aires este mes?\n" +
            "• Evolución de ingresos de marzo\n" +
            "• ¿Cuánto vendí en enero?"
        )
        periodo_t = "mes" if m["n_ventas"] > 300 else "dia"
        tiempo = por_tiempo(df, periodo_t)
        if tiempo:
            g = {"tipo":"line","titulo":"Evolución de ingresos","labels":[r["periodo"] for r in tiempo[-12:]],
                 "values":[r["ingresos"] for r in tiempo[-12:]],"values2":[],
                 "label_series":"Ingresos","label_series2":"","color":"#2563eb"}

    return ok({"resultado": {"respuesta": respuesta, "grafico": norm_grafico(g)}})


if __name__ == "__main__":
    import threading, webbrowser
    def open_browser():
        import time; time.sleep(1.2)
        webbrowser.open(f"http://{HOST}:{PORT}")
    threading.Thread(target=open_browser, daemon=True).start()
    app.run(host=HOST, port=PORT, debug=False)
