@echo off
title Dashify
echo.
echo  ===================================
echo    Dashify - Iniciando...
echo  ===================================
echo.
set PYTHON=
python --version >nul 2>&1
if not errorlevel 1 ( set PYTHON=python & goto :found )
py --version >nul 2>&1
if not errorlevel 1 ( set PYTHON=py & goto :found )
python3 --version >nul 2>&1
if not errorlevel 1 ( set PYTHON=python3 & goto :found )
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" "C:\Python312\python.exe" "C:\Python311\python.exe") do (
  if exist %%P ( set PYTHON=%%P & goto :found ) )
echo [ERROR] Python no encontrado. Descargalo desde https://www.python.org/downloads/
pause & exit /b 1
:found
echo  Python: %PYTHON%
echo  Instalando dependencias...
%PYTHON% -m pip install flask pandas openpyxl requests odfpy --quiet --disable-pip-version-check 2>nul
if errorlevel 1 %PYTHON% -m pip install flask pandas openpyxl requests odfpy --user --quiet
echo.
echo  Iniciando en http://127.0.0.1:7841
echo  El navegador se abre automaticamente.
echo  Cerra esta ventana para detener.
echo.
cd /d "%~dp0"
%PYTHON% app.py
echo.
echo  Dashify cerrado.
pause
