#!/bin/bash
echo ""; echo "╔══════════════════════════════════════╗"; echo "║       Dashify — Iniciando...         ║"; echo "╚══════════════════════════════════════╝"; echo ""
PYTHON=""
for cmd in python3 python; do
  if command -v $cmd &>/dev/null; then
    VER=$($cmd -c "import sys; print(sys.version_info.major)" 2>/dev/null)
    if [ "$VER" = "3" ]; then PYTHON=$cmd; break; fi
  fi
done
if [ -z "$PYTHON" ]; then echo "[ERROR] Python 3 no encontrado."; exit 1; fi
$PYTHON -m pip install flask pandas openpyxl requests odfpy --quiet 2>/dev/null
echo " Iniciando en http://127.0.0.1:7841 — Ctrl+C para cerrar"; echo ""
cd "$(dirname "$0")"; $PYTHON app.py
