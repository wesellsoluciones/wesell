#!/bin/bash
# ═══════════════════════════════════════════════════════
#  Dashify — Script de inicio para macOS y Linux
# ═══════════════════════════════════════════════════════

clear
echo ""
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║                                               ║"
echo "  ║        DASHIFY — Dashboard de Ventas          ║"
echo "  ║                                               ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo ""

# ── Detectar Python 3 ────────────────────────────────────────────────────────
PYTHON=""
for cmd in python3 python python3.13 python3.12 python3.11 python3.10 python3.9 python3.8; do
  if command -v "$cmd" &>/dev/null; then
    VER=$("$cmd" -c "import sys; print(sys.version_info.major)" 2>/dev/null)
    if [ "$VER" = "3" ]; then
      PYVER=$("$cmd" -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null)
      PYTHON="$cmd"
      break
    fi
  fi
done

if [ -z "$PYTHON" ]; then
  echo "  ❌  Python 3 no encontrado en tu sistema."
  echo ""
  echo "  Para instalarlo:"
  if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "    macOS  → https://www.python.org/downloads/macos/"
    echo "    O con Homebrew: brew install python3"
  else
    echo "    Ubuntu/Debian → sudo apt install python3 python3-pip"
    echo "    Fedora/RHEL   → sudo dnf install python3 python3-pip"
    echo "    Arch          → sudo pacman -S python python-pip"
  fi
  echo ""
  read -p "  Presioná Enter para salir..." _
  exit 1
fi

echo "  ✓  Python detectado: $PYVER ($PYTHON)"

# ── Verificar versión mínima (3.8+) ─────────────────────────────────────────
MIN_OK=$("$PYTHON" -c "import sys; print('ok' if sys.version_info >= (3,8) else 'no')" 2>/dev/null)
if [ "$MIN_OK" != "ok" ]; then
  echo "  ❌  Necesitás Python 3.8 o superior. Versión actual: $PYVER"
  echo "      Descargá la última versión en: https://www.python.org/downloads/"
  exit 1
fi

# ── Instalar dependencias ────────────────────────────────────────────────────
echo "  ⏳  Verificando dependencias..."
echo "      (Solo la primera vez puede tardar un momento)"
echo ""

# Detectar pip
PIP=""
for p in pip3 pip "$PYTHON -m pip"; do
  if $p --version &>/dev/null 2>&1; then PIP=$p; break; fi
done
if [ -z "$PIP" ]; then PIP="$PYTHON -m pip"; fi

# Instalar desde requirements.txt
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
$PIP install -r "$SCRIPT_DIR/requirements.txt" --quiet 2>/dev/null

if [ $? -ne 0 ]; then
  # Reintentar con --user
  $PIP install -r "$SCRIPT_DIR/requirements.txt" --user --quiet 2>/dev/null
  if [ $? -ne 0 ]; then
    echo "  ⚠️  No se pudieron instalar todas las dependencias."
    echo "     Intentá: sudo $PIP install -r requirements.txt"
    read -p "  Presioná Enter para intentar iniciar de todas formas..." _
  fi
fi

echo "  ✓  Dependencias listas."
echo ""
echo "  ═══════════════════════════════════════════════"
echo "    Dashify corriendo en: http://127.0.0.1:7841"
echo "    El navegador se abre automáticamente."
echo "    Presioná Ctrl+C para detener Dashify."
echo "  ═══════════════════════════════════════════════"
echo ""

# Iniciar la app
cd "$SCRIPT_DIR"
"$PYTHON" app.py

echo ""
echo "  Dashify cerrado. ¡Hasta pronto!"
