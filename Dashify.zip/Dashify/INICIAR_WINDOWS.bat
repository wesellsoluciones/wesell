@echo off
chcp 65001 >nul 2>&1
title Dashify — Dashboard de Ventas
color 0B

echo.
echo  ╔═══════════════════════════════════════════════╗
echo  ║                                               ║
echo  ║          DASHIFY — Dashboard de Ventas        ║
echo  ║                                               ║
echo  ╚═══════════════════════════════════════════════╝
echo.

:: ── Buscar Python ──────────────────────────────────────────────────────────
set PYTHON=

python --version >nul 2>&1
if not errorlevel 1 ( set PYTHON=python & goto :check_version )

py --version >nul 2>&1
if not errorlevel 1 ( set PYTHON=py & goto :check_version )

python3 --version >nul 2>&1
if not errorlevel 1 ( set PYTHON=python3 & goto :check_version )

:: Buscar en rutas comunes
for %%P in (
  "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
  "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
  "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
  "%LOCALAPPDATA%\Programs\Python\Python39\python.exe"
  "C:\Python313\python.exe"
  "C:\Python312\python.exe"
  "C:\Python311\python.exe"
  "C:\Python310\python.exe"
) do (
  if exist %%P ( set PYTHON=%%P & goto :check_version )
)

:: Python no encontrado
echo.
echo  ❌  Python no encontrado en tu sistema.
echo.
echo  Para instalarlo:
echo    1. Abrí tu navegador
echo    2. Entrá a: https://www.python.org/downloads/
echo    3. Descargá la versión más reciente
echo    4. Durante la instalación, TILDÁ la opción:
echo       "Add Python to PATH"
echo    5. Una vez instalado, cerrá esta ventana
echo       y volvé a ejecutar INICIAR_WINDOWS.bat
echo.
pause
exit /b 1

:check_version
:: Verificar que sea Python 3.8 o superior
for /f "tokens=2" %%V in ('%PYTHON% --version 2^>^&1') do set PYVER=%%V
echo  ✓  Python encontrado: %PYVER%

:: Extraer versión major.minor
for /f "tokens=1,2 delims=." %%A in ("%PYVER%") do (
  set PYMAJ=%%A
  set PYMIN=%%B
)
if %PYMAJ% LSS 3 goto :version_error
if %PYMAJ% EQU 3 if %PYMIN% LSS 8 goto :version_error
goto :install_deps

:version_error
echo.
echo  ❌  Necesitás Python 3.8 o superior.
echo      Versión detectada: %PYVER%
echo      Descargá la última versión en: https://www.python.org/downloads/
echo.
pause
exit /b 1

:install_deps
echo  ⏳  Verificando e instalando dependencias...
echo      (Solo la primera vez puede tardar 1-2 minutos)
echo.

:: Actualizar pip silenciosamente
%PYTHON% -m pip install --upgrade pip --quiet --disable-pip-version-check >nul 2>&1

:: Instalar dependencias
%PYTHON% -m pip install -r "%~dp0requirements.txt" --quiet --disable-pip-version-check 2>nul
if errorlevel 1 (
  :: Reintentar con --user si falla por permisos
  %PYTHON% -m pip install -r "%~dp0requirements.txt" --user --quiet --disable-pip-version-check 2>nul
  if errorlevel 1 (
    echo  ⚠️  Hubo un problema instalando dependencias.
    echo     Intentá ejecutar como Administrador.
    pause
    exit /b 1
  )
)

echo  ✓  Dependencias listas.
echo.
echo  ═══════════════════════════════════════════════
echo    Dashify corriendo en: http://127.0.0.1:7841
echo    El navegador se abre automáticamente.
echo    Cerrá esta ventana para detener Dashify.
echo  ═══════════════════════════════════════════════
echo.

cd /d "%~dp0"
%PYTHON% app.py

echo.
echo  Dashify cerrado. ¡Hasta pronto!
pause
